NostalgiaVX v11.15 - All of Create v22 Block-Entity Lantern Emission Fix

Built from the working v21 End-clarity build.

Why the previous wall-lantern mappings were not enough:
- Amendments 2.1.10 wall lanterns are EntityBlock / block-entity rendered geometry.
- Iris block.properties IDs are exposed as mc_Entity only for terrain geometry.
- Block entities use the blockEntityId uniform instead.
- NostalgiaVX's shared gbuffers_block + shadow voxel path was still reading mc_Entity,
  so the wall soul lantern never reached VX's Soul Light emission ID even though
  block.properties mapped the state correctly.

v22 changes only the ID source for mapped Amendments wall lantern block entities:
- gbuffers_block: blockEntityId 1020/1022 feeds the normal/soul emission ID.
- shadow voxelizer: blockEntityId 1020/1022 feeds the same torch-like voxel shape
  and hardcoded warm/cyan emission used by vanilla lanterns.

All v21 End clarity, image scaling, Create/Colorwheel, AVPBR/Create-LabPBR,
name-tag, adaptive GI and performance changes are preserved.
