NostalgiaVX 11.15 — All of Create: Aeronautics v2.6 compatibility patch

Built as a private modification of the user's supplied NostalgiaVX 11.15 archive.
Target pack: All of Create: Aeronautics v2.6 / Minecraft 1.21.1 / NeoForge 21.1.250.

WHAT THIS PATCH CHANGES
- Adds a conservative vanilla-lightmap fallback to VX deferred/path-traced terrain.
- Adds the same blocklight fallback to forward-rendered geometry in Overworld/End and Nether.
- Uses max(VX light, fallback light), not additive lighting, to avoid double-lighting scenes that VX already handles correctly.
- Adds automatic Iris tag mappings for modded flowers, crops, rails, signs, hanging signs, chains, and ropes.
- Adds Shader Options > Lighting > Modded Lighting Compatibility.

DEFAULTS
- Modded Lighting Fallback: ON
- Blocklight Fallback Strength: 0.35
- Skylight Fallback Strength: 0.10

If a modded lamp still leaves an area too dark, try Blocklight Fallback Strength 0.50 or 0.60.
If interiors become too bright/flat, lower it to 0.20-0.30. Keep Skylight Fallback low unless outdoor modded blocks are still abnormally dark.

IMPORTANT LIMITATION
This patch improves lighting for ordinary modded blocks and light sources that participate in Minecraft/Iris lightmaps.
For this All of Create v2.6 pack, Flywheel 1.x rendering is handled by Colorwheel + Colorwheel Patcher.
Do NOT stack Iris & Oculus Flywheel Compat with Colorwheel for this build. The v9 shader contains a native
clrwl_gbuffers path specifically for Colorwheel/Create. POM stays off Flywheel geometry, while the optional
Create-LabPBR mode decodes matching Create normal/AO/specular maps without animated-atlas MIP bias.

LICENSE NOTE
The original NostalgiaVX LICENSE is preserved unchanged. Its license allows private modifications but restricts redistribution of modified versions. Treat this build as a private personal-use patch unless you have permission from the original author to redistribute it.
