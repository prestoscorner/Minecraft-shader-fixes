#version 430 compatibility

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

/*
 * All-of-Create v19 End viewport fix:
 * composite3 writes the final fog/reflection-composited scene color, so the pass must cover
 * the entire render-scaled scene viewport. Using vertexSimplePT with SPEC incorrectly shrinks
 * this whole pass to reflectionResScale when reflectionResReduction > 1, leaving a visible
 * rectangular boundary in the End. Reflection sampling itself remains reduced-resolution in
 * composite3.fsh / reflection.glsl, so this does not force the reflection tracer to full res.
 */
#include "/program/deferred/vertexSimple.vsh"
