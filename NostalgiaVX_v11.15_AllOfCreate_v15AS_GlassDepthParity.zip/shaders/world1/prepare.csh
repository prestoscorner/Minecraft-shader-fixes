#version 430

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

layout (local_size_x = 8) in;
const ivec3 workGroups = ivec3(1, 1, 1);

#define RSSBO_ENABLE_COLOR
#include "/lib/head.glsl"
#include "/lib/util/colorspace.glsl"

#define END_AmbientRed 1.00          //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define END_AmbientGreen 0.40        //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define END_AmbientBlue 1.00         //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define END_AmbColor vec3(END_AmbientRed, END_AmbientGreen, END_AmbientBlue)

uniform int worldTime;
uniform float cloudLightFlip, lightFlip, sunAngle, wetness;

uniform vec3 fogColor, skyColor;
uniform vec4 daytime;

vec3 RDaytimeColor(vec3 rise, vec3 noon, vec3 set, vec3 night) {
    return rise * daytime.x + noon * daytime.y + set * daytime.z + night * daytime.w;
}
vec3 RDaytimeColor_SquaredBlend(vec3 rise, vec3 noon, vec3 set, vec3 night) {
    return rise * sqr(daytime.x) + noon * (1-sqr(1-daytime.y)) + set * sqr(daytime.z) + night * (1-sqr(1-daytime.w));
}

vec3 blackbody(float temperature){
    vec4 vx = vec4(-0.2661239e9, -0.2343580e6, 0.8776956e3, 0.179910);
    vec4 vy = vec4(-1.1063814, -1.34811020, 2.18555832, -0.20219683);
    float it = rcp(temperature);
    float it2= sqr(it);
    float x = dot(vx, vec4(it * it2, it2, it, 1.0));
    float x2 = sqr(x);
    float y = dot(vy,vec4(x * x2, x2, x, 1.0));
    float z = 1.0 - x - y;
    
    vec3 AP1 = vec3(x * rcp(y), 1.0, z * rcp(y)) * CT_XYZ_AP1;
    return max(AP1, 0.0);
}

vec3 RColor_GetSunlight() {
    return END_AmbColor * 0.3;
}

void main() {
    uint Index = uint(gl_GlobalInvocationID.x);

    switch (Index) {
        case 0:
            RColorTable.Sunlight = RColor_GetSunlight();
            RColorTable.DirectLight = RColorTable.Sunlight;

        case 2:
            RColorTable.Skylight = END_AmbColor * 0.1;

            RColorTable.Skylight *= skylightIllum * vec3(skylightRedMult, skylightGreenMult, skylightBlueMult);

        case 3:
            RColorTable.Blocklight = blackbody(float(blocklightBaseTemp)) * blocklightIllum * blocklightBaseMult * 1.5;
    }
            
}