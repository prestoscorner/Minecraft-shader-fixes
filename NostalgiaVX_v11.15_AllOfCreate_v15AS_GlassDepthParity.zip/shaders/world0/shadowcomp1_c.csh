#version 430

#define LAST
#include "/program/lpv/propagate.comp"