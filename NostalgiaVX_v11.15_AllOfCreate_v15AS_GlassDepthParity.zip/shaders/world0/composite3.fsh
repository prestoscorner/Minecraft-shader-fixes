#version 430 compatibility

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

/* RENDERTARGETS: 0,5 */
layout(location = 0) out vec3 sceneColor;
layout(location = 1) out vec4 bloomTiles;
//layout(location = 2) out vec4 clear7;

#define RSSBO_ENABLE_COLOR
#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"

const bool shadowHardwareFiltering = true;

in vec2 uv;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3, colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex7;
uniform sampler2D colortex8;
uniform sampler2D colortex9;
uniform sampler2D colortex10, colortex12;
uniform sampler2D colortex11;
uniform sampler2D colortex15;

uniform sampler2D depthtex0;
uniform sampler2D depthtex1;

uniform sampler2D noisetex, RSkybox;
uniform sampler3D depthtex2;

uniform sampler2DShadow shadowtex1HW;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;

uniform int frameCounter;
uniform int isEyeInWater;
uniform int worldTime;

uniform float eyeAltitude;
uniform float far, near;
uniform float frameTimeCounter;
uniform float cloudLightFlip;
uniform float sunAngle;
uniform float lightFlip;
uniform float worldAnimTime;

uniform ivec2 eyeBrightnessSmooth;

uniform vec2 taaOffset;
uniform vec2 viewSize, pixelSize;

uniform vec3 cameraPosition;
uniform vec3 lightDirView, lightDir;
uniform vec3 cloudLightDir, cloudLightDirView;

uniform vec4 daytime;

uniform mat4 gbufferProjectionInverse, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferModelView;
uniform mat4 shadowModelView, shadowModelViewInverse;
uniform mat4 shadowProjection, shadowProjectionInverse;

#define FUTIL_LINDEPTH
#include "/lib/fUtil.glsl"

#include "/lib/frag/bluenoise.glsl"
#include "/lib/frag/gradnoise.glsl"

#include "/lib/util/bicubic.glsl"
#include "/lib/util/transforms.glsl"
#include "/lib/atmos/project.glsl"
#include "/lib/atmos/phase.glsl"
#include "/lib/atmos/waterConst.glsl"

#ifdef DISTANT_HORIZONS
uniform mat4 dhProjectionInverse, dhProjection;
uniform sampler2D dhDepthTex0, dhDepthTex1;
uniform int dhRenderDistance;
#endif

vec3 getFog(vec3 color, float dist, vec3 skyColor, vec3 sceneDir) {
    #ifdef DISTANT_HORIZONS
        dist = dist / dhRenderDistance;
        dist *= pi;
        dist 	= max((dist - sqr(fogStart)), 0.0);
        dist   /= 1.0 - sqr(fogStart);
    #else
	    dist 	= dist / far;
        dist 	= max((dist - fogStart), 0.0);
        dist   /= 1.0 - fogStart;
    #endif
        
	float alpha = 1.0-exp(-dist * fogFalloff);
        alpha *= alpha;
        alpha  *= cube(1.0 - max0(sceneDir.y));

	color 	= mix(color, skyColor, saturate(alpha));

	return color;
}

vec3 getWaterFog(vec3 SceneColor, float dist, vec3 ScatterColor){
    float density   = max0(dist) * waterDensity;

    vec3 transmittance = expf(-waterAbsorbCoeff * density);

    const vec3 scatterCoeff = vec3(waterRed, waterGreen, waterBlue);

    #ifdef waterDepthColorEnabled
        // Phase 1: preserve the creator's water coefficients, but let physical path length
        // push deep water progressively toward that same configured hue.
        float depthColorMix = (1.0 - exp(-max0(dist) / max(waterDepthColorDistance, 1e-3))) * waterDepthColorStrength;
        vec3 depthHue = sqrt(max(scatterCoeff, vec3(1e-4)));
        depthHue /= max(maxOf(depthHue), 1e-4);
        vec3 sceneDepthTint = mix(vec3(1.0), mix(vec3(0.42), depthHue, 0.74), saturate(depthColorMix));
        vec3 scatterDepthTint = mix(vec3(1.0), mix(vec3(0.72), sqrt(depthHue), 0.65), saturate(depthColorMix * 0.60));
        SceneColor *= sceneDepthTint;
        ScatterColor *= scatterDepthTint;
    #endif

    vec3 scatter    = 1.0-exp(-density * scatterCoeff);
        scatter    *= max(expf(-waterAttenCoeff * density), expf(-waterAttenCoeff * pi));

    return SceneColor * transmittance + scatter * ScatterColor * rpi;
}

/* ------ FOG ------ */
#include "/lib/offset/gauss.glsl"

ivec2 clampTexelPos_FOG(ivec2 pos) {
    return clamp(pos, ivec2(0.0), ivec2(viewSize));
}

mat2x3 sampleFogSpatial(vec2 coord, const float LOD) {
    ivec2 pixelCoordUnscaled = ivec2(coord * viewSize);

    vec2 newCoord       = coord / LOD;
    ivec2 pixelCoord    = ivec2(newCoord * viewSize);

    ivec2 pos           = ivec2(coord * viewSize);

    vec3 centerScatter  = texelFetch(colortex5, pixelCoord, 0).rgb;
    vec3 centerTransmittance = texelFetch(colortex7, pixelCoord, 0).rgb;

    float centerDepth   = depthLinear(texelFetch(depthtex0, pixelCoordUnscaled, 0).x) * far;

    float totalWeight   = 1.0;
    vec3 totalScatter   = centerScatter * totalWeight;
    vec3 totalTrans     = centerTransmittance * totalWeight;

    for (int i = 0; i<9; i++) {
        ivec2 deltaPos      = kernelO_3x3[i] * 2;
        if (i == 4) continue;

        ivec2 samplePos     = pixelCoordUnscaled + deltaPos;
        ivec2 samplePosScaled = ivec2(vec2(samplePos) / LOD);

        bool valid          = all(greaterThanEqual(samplePos, ivec2(0))) && all(lessThan(samplePos, ivec2(viewSize)));

        if (!valid) continue;

        vec3 currentScatter = texelFetch(colortex5, clampTexelPos_FOG(samplePosScaled), 0).rgb;
        vec3 currentTrans   = texelFetch(colortex7, clampTexelPos_FOG(samplePosScaled), 0).rgb;
        float currentDepth  = depthLinear(texelFetch(depthtex0, samplePos, 0).x) * far;

        float depthDelta    = abs(currentDepth - centerDepth) * 48.0;

        float weight        = exp(-depthDelta);

        //accumulate stuff
        totalScatter   += currentScatter * weight;
        totalTrans     += currentTrans * weight;

        totalWeight    += weight;
    }

    totalScatter   /= max(totalWeight, 1e-16);
    totalTrans     /= max(totalWeight, 1e-16);

    return mat2x3(totalScatter, totalTrans);
}

void applyFogData(inout vec3 color, in mat2x3 data) {
    color = color * data[1] + data[0];
}


/* ------ Reflections ------ */
#include "/lib/frag/reflection.glsl"

vec4 FetchGbuffer(ivec2 UV) {
        UV          = ivec2(vec2(UV) / reflectionResScale);
    vec3 normals    = decodeNormal(texelFetch(colortex1, UV, 0).xy);
    float depth     = depthLinear(texelFetch(depthtex0, UV, 0).x) * far;
    return vec4(normals, depth);
}

float sphericalGaussian(vec3 dir1, vec3 dir2, float lambda) {
    float w = exp(lambda * (saturate(dot(dir1, dir2)) - 1.0));
    return w > 1e-8 ? w : exp(-saturate(1-dot(dir1, dir2)) * 16.0);
}

float lobeSharpness(float roughness) {
    return 2.0 / sqr(max(roughness, 1e-5));
}

float specularLobeWeight(vec3 centerNorm, vec3 norm, float centerRoughness, float roughness, float beta) {
    //if (maxOf(vec2(centerRoughness, roughness)) < 1e-2) return pow8(saturate(dot(centerNorm, norm) * 1.05));

    float lambaCenter = lobeSharpness(centerRoughness);
    float lambaSample = lobeSharpness(roughness);
    return pow(2.0 * sqrt(lambaCenter*lambaSample) / max(lambaCenter + lambaSample, 1e-5), beta) 
        * sphericalGaussian(centerNorm, norm, beta * lambaCenter * lambaSample / max(lambaCenter + lambaSample, 1e-5));
}

const float lobeFactor = 1.0;
const float sharpenWeight = 0.4;

vec4 modifySpecularColor(vec4 color) {
    return vec4(pow(length(color.rgb), sharpenWeight) * normalizeSafe(color.rgb), color.a);
}
vec4 inverseModifySpecularColor(vec4 color) {
    return vec4(pow(length(color.rgb), 1.0 / sharpenWeight) * normalizeSafe(color.rgb), saturate(color.a));
}

uniform sampler3D RBluenoise3D;
vec3 ditherBluenoiseF3() {
    ivec2 coord = ivec2(gl_FragCoord.xy);

    vec3 noise  = texelFetch(RBluenoise3D, ivec3(coord & 255, 0), 0).xyz;
        noise   = fract(noise + torroidalShift.xyz * frameCounter);

    return noise;
}

ivec2 clampTexelPos(ivec2 pos) {
    return clamp(pos, ivec2(0), ivec2(viewSize / REF_VIEWPORT - 1));
}

mat2x4 ReadReflectionResult(vec2 ViewUV) {
    ivec2 PixelIndex = ivec2((ViewUV / REF_VIEWPORT) * viewSize);

    return mat2x4(
        texelFetch(colortex12, PixelIndex, 0),
        texelFetch(colortex12, PixelIndex + ivec2(viewSize.x * 0.5, 0.0), 0)
    );
}

mat2x4 ReadReflectionData(ivec2 PixelIndex) {
    PixelIndex = clampTexelPos(PixelIndex);
    return mat2x4(
        texelFetch(colortex12, PixelIndex, 0),
        texelFetch(colortex12, PixelIndex + ivec2(viewSize.x * 0.5, 0.0), 0)
    );
}

vec4 FetchReflectionGbuffer(ivec2 UV) {
    vec4 Val  = texelFetch(colortex10, clampTexelPos(UV), 0);
    return vec4(Val.rgb * 2.0 - 1.0, sqr(Val.w) * far);
}
float ReadCurrentRoughness(ivec2 Position) {
    return texelFetch(colortex12, Position + ivec2(viewSize.x * 0.5, 0.0), 0).a;
}


mat2x4 ReadReflectionUpscaled(vec2 uv, vec4 centerData, float centerRoughness) {
    ivec2 UV    = ivec2((uv * viewSize / ResolutionScale)/ REF_VIEWPORT);

    //return ReadReflectionData(UV);

    mat2x4 totalColor = mat2x4(0);
    float totalWeight = 0.0;

    const float normalExp = 256.0;

    ivec2 jitter        = ivec2((ditherBluenoiseF3().xy - 0.5));

    float specularWaveletWeight = mix(0.3, 1.0, sqrt(centerRoughness));
    float specularKernel[3][3] = {
		{ 1.0,                        specularWaveletWeight,       sqr(specularWaveletWeight) },
		{ specularWaveletWeight,      sqr(specularWaveletWeight),  pow4(specularWaveletWeight) },
        { sqr(specularWaveletWeight), pow4(specularWaveletWeight), pow8(specularWaveletWeight) }
        };

    const int r = 2;
	for(int y = -r; y <= r; ++y) {
		for(int x = -r; x <= r; ++x) {
			ivec2 TapUV = UV + ivec2(x, y) + jitter;

            bool valid          = all(greaterThanEqual(TapUV, ivec2(0))) && all(lessThan(TapUV, ivec2(viewSize / REF_VIEWPORT)));

            if (!valid) continue;

            vec4 currentData    = FetchReflectionGbuffer(TapUV);

            mat2x4 CurrentColor = ReadReflectionData(TapUV);

            float weight         = specularKernel[abs(x)][abs(y)];

            float distDepth = abs(centerData.a - currentData.a) * 4.0;

                weight *= exp(-distDepth);
                weight *= max0(specularLobeWeight(centerData.xyz, currentData.xyz, centerRoughness, CurrentColor[1].a, lobeFactor));
                //weight = max(weight, 1e-16);
            

            totalColor[0] += modifySpecularColor(CurrentColor[0]) * weight;
            totalColor[1] += CurrentColor[1] * weight;
            totalWeight   += weight;
        }
    }
    totalWeight     = max(totalWeight, 1e-16);

    totalColor[0] /= totalWeight;
    totalColor[1] /= totalWeight;
    totalColor[0] = inverseModifySpecularColor(totalColor[0]);

    return totalColor;
}

vec3 lavaFog(vec3 scene, float d) {
    float density   = max(0.0, d);

    float transmittance = expf(-1.0 * density);

    return mix(vec3(1.0, 0.2, 0.02), scene, transmittance);
}

uniform float blindness;
uniform float darknessFactor;

vec3 blindnessFog(vec3 SceneColor, float SceneDistance) {
    if (blindness < 1e-2) return SceneColor;
    float maxDistance = mix(16.0 / saturate(1.0 - darknessFactor * 0.9), tau, saturate(blindness));

    return mix(SceneColor, minimumAmbientColor * minimumAmbientMult * rpi, saturate(sqrt(sstep(SceneDistance, 0.0, maxDistance)) * max(darknessFactor * rpi, blindness)));
}

vec3 stainedGlassSRGB(int idx) {
    if (idx == 1)  return vec3(0.976, 1.000, 0.996); // white
    if (idx == 2)  return vec3(0.976, 0.502, 0.114); // orange
    if (idx == 3)  return vec3(0.780, 0.306, 0.741); // magenta
    if (idx == 4)  return vec3(0.227, 0.702, 0.855); // light blue
    if (idx == 5)  return vec3(0.996, 0.847, 0.239); // yellow
    if (idx == 6)  return vec3(0.502, 0.780, 0.122); // lime
    if (idx == 7)  return vec3(0.953, 0.545, 0.667); // pink
    if (idx == 8)  return vec3(0.278, 0.310, 0.322); // gray
    if (idx == 9)  return vec3(0.616, 0.616, 0.592); // light gray
    if (idx == 10) return vec3(0.086, 0.612, 0.612); // cyan
    if (idx == 11) return vec3(0.537, 0.196, 0.722); // purple
    if (idx == 12) return vec3(0.235, 0.267, 0.667); // blue
    if (idx == 13) return vec3(0.514, 0.329, 0.196); // brown
    if (idx == 14) return vec3(0.369, 0.486, 0.086); // green
    if (idx == 15) return vec3(0.690, 0.180, 0.149); // red
    if (idx == 16) return vec3(0.114, 0.114, 0.129); // black
    return vec3(1.0);
}

#include "/lib/atmos/hiddenWater.glsl"

void main() {
    sceneColor  = texture(colortex0, uv).rgb;

    vec4 GBuffer0       = texture(colortex1, uv);

    vec4 GBuffer1       = texture(colortex2, uv);
    vec2 materialTag    = unpack2x8(GBuffer1.y);
    int matID           = int(materialTag.x * 255.0);
    vec2 stainedGlassMeta = unpack2x8(GBuffer1.z);
    int stainedGlassColorIndex = int(stainedGlassMeta.x * 255.0 + 0.5);
    bool stainedGlass   = (matID == 101) && (stainedGlassColorIndex > 0);
    float frontStainedAlpha = stainedGlass ? stainedGlassMeta.y : 0.0;
    vec3 frontStainedColor = stainedGlass ? unpackColor16(GBuffer1.w) : vec3(1.0);
    vec4 hiddenWaterAux = texture(colortex15, uv);
    float hiddenWaterCode = fract(max(hiddenWaterAux.a, 0.0));
    bool waterBehindTranslucent = hiddenWaterCode > (0.5 / 65535.0) && matID == 101;

#ifdef DISTANT_HORIZONS
    vec2 dhDepth = vec2(stex(dhDepthTex0).x, stex(dhDepthTex1).x);
    bvec2 isDH = bvec2(landMask(dhDepth.x), landMask(dhDepth.y));
#else
    const bvec2 isDH = bvec2(false, false);
#endif

    vec2 sceneDepth     = vec2(texture(depthtex0, uv).x, texture(depthtex1, uv).x);
    bvec2 isTerrain = bvec2(landMask(sceneDepth.x), landMask(sceneDepth.y));
    
    bool translucent    = sceneDepth.x < sceneDepth.y;
#ifdef DISTANT_HORIZONS
        if (!isTerrain.x) translucent = translucent || (dhDepth.x < dhDepth.y);
#endif

    vec3 position0      = vec3(uv / ResolutionScale, sceneDepth.x);
        position0       = screenToViewSpace(position0);
#ifdef DISTANT_HORIZONS
        if (!isTerrain.x) position0 = screenToViewSpace(vec3(uv / ResolutionScale, dhDepth.x), dhProjectionInverse);
#endif

    vec3 position1      = vec3(uv / ResolutionScale, sceneDepth.y);
        position1       = screenToViewSpace(position1);
#ifdef DISTANT_HORIZONS
        if (!isTerrain.y) position1 = screenToViewSpace(vec3(uv / ResolutionScale, dhDepth.y), dhProjectionInverse);
#endif

    float hiddenWaterDist = waterBehindTranslucent ? hiddenWaterDecodeDistance(hiddenWaterCode) : 0.0;
    vec3 hiddenWaterPos = position0;
    vec3 hiddenWaterSceneNormal = vec3(0.0, 1.0, 0.0);
    if (waterBehindTranslucent && hiddenWaterDist > 0.0) {
        hiddenWaterPos = normalize(position0) * hiddenWaterDist;
        vec3 hiddenScenePos = viewToSceneSpace(hiddenWaterPos);
        hiddenWaterSceneNormal = hiddenWaterNormal(hiddenScenePos + cameraPosition, hiddenWaterDist);
    }

    mat2x3 scenePos     = mat2x3(viewToSceneSpace(position0), viewToSceneSpace(position1));

    vec3 worldDir       = mat3(gbufferModelViewInverse) * normalize(position0);

    // V15AK: keep glass as the reflection surface but use the scene BEHIND it as
    // the atmosphere/fog endpoint, matching what clear glass naturally exposes.
    vec3 atmospherePosition = position0;
    vec3 atmosphereWorldDir = worldDir;
    bool atmosphereHasTerrain = (isTerrain.x || isDH.x);
    if (stainedGlass) {
        if (waterBehindTranslucent && hiddenWaterDist > 0.0) {
            atmospherePosition = hiddenWaterPos;
            atmosphereWorldDir = mat3(gbufferModelViewInverse) * normalize(hiddenWaterPos);
            atmosphereHasTerrain = true;
        } else {
            atmospherePosition = position1;
            atmosphereWorldDir = mat3(gbufferModelViewInverse) * normalize(position1);
            atmosphereHasTerrain = (isTerrain.y || isDH.y);
        }
    }

    vec3 skyColor       = texture(RSkybox, projectSky(worldDir, 0)).rgb;

    mat2x3 reflectionAux = unpackReflectionAux(texture(colortex3, uv));
        reflectionAux[1] = saturate(reflectionAux[1]);

    #ifdef reflectionsEnabled
    if ((isTerrain.x || isDH.x) && matID != 201) {
        // V15AP: reflection-domain parity. When water is hidden behind stained glass,
        // PTReflections generated the reflection from the hidden-water surface; upscale/read
        // it with that exact same water normal and depth. This removes the old fixed box while
        // restoring native distant/voxel/sky reflection information.
        vec3 sceneNormal = waterBehindTranslucent ? hiddenWaterSceneNormal : decodeNormal(GBuffer0.xy);
        vec3 viewNormal = mat3(gbufferModelView) * sceneNormal;

        if (!isTerrain.x && isDH.y && !translucent) reflectionAux[0] = RColorTable.DirectLight * cube(saturate(unpack2x8(GBuffer0.z)).y)
            * saturate(dot(sceneNormal, lightDir)) / pi;

        vec3 reflectionViewPos = waterBehindTranslucent ? hiddenWaterPos : position0;
        vec3 viewDir    = normalize(reflectionViewPos);

        // Direct and hidden water both consume the native water reflection result.
        bool water      = matID == 102 || waterBehindTranslucent;

            reflectionAux[0] *= pi;

            reflectionAux[0] = min(reflectionAux[0], RColorTable.DirectLight);

        materialProperties material = materialProperties(1.0, 0.02, false, false, mat2x3(0.0));
        if (water) material = materialProperties(0.0001, 0.02, false, false, mat2x3(0.0));
        else material   = decodeLabBasic(unpack2x8(GBuffer1.x));
        float groundWetness = matID == 101 ? 0.0 : unpack2x8(GBuffer1.z).y;

        // Hidden and directly visible water must use the same stored-depth convention
        // when weighting reflection taps across the edge of a glass pane.
        float reflectionSurfaceDepth = waterBehindTranslucent
            ? depthLinear(viewToScreenSpace(hiddenWaterPos).z) * far
            : depthLinear(sceneDepth.x) * far;
        mat2x4 ReflectionData = ReadReflectionUpscaled(uv, vec4(sceneNormal, reflectionSurfaceDepth), material.roughness);
        
        vec4 reflection = ReflectionData[0];
        vec3 fresnel    = ReflectionData[1].xyz;

        if (material.conductorComplex && material.conductor) fresnel *= sqrt(reflectionAux[1]) * pi;

        #ifdef resourcepackReflectionsEnabled
            if (material.conductor) sceneColor.rgb = mix(sceneColor.rgb, reflection.rgb * fresnel, reflection.a);
            else sceneColor.rgb = mix(sceneColor.rgb, reflection.rgb, fresnel * reflection.a);            
        #else
            // --- WATER REFLECTIONS --- //
            if (water || groundWetness > 1e-2) {
                sceneColor.rgb = mix(sceneColor.rgb, reflection.rgb, fresnel * reflection.a);
            }
        #endif

        //sceneColor.rgb = reflection.rgb;

        #ifdef specularHighlightsEnabled
        // First-person held blocks are view-relative. Feeding their PBR normal/material
        // data through the world-space GGX highlight causes angle-dependent mirror sheen,
        // grain and temporal smearing. Keep scene specular intact everywhere else.
        if (matID != 201)
            sceneColor.rgb += specularTrowbridgeReitzGGX(-viewDir, lightDirView, viewNormal, material, reflectionAux[1]) * reflectionAux[0];
        #endif
    }
    #endif
    

    #ifdef fogEnabled
        if (isEyeInWater == 0) {
            if (stainedGlass) {
                // V15AK: one continuous camera -> behind-pane air-fog resolve.
                // composite.fsh deliberately skips the glass->back analytic fog segment
                // for stained glass so this is not double-counted.
                if (atmosphereHasTerrain)
                    sceneColor = getFog(sceneColor, length(atmospherePosition), skyColor, atmosphereWorldDir);
            } else if (isTerrain.x || isDH.x) {
                sceneColor = getFog(sceneColor, length(position0), skyColor, worldDir);
            }
        }
    #endif

    #ifdef waterFogEnabled
    float vDotL     = clampDIR(dot(normalize(position1), lightDirView));
    float caveMult  = linStep(eyeBrightnessSmooth.y/240.0, 0.1, 0.9);

    if (isEyeInWater == 1) {
        vec3 underwaterScatterColor = RColorTable.Skylight * caveMult;
        #ifdef underwaterLightShaftsEnabled
        // Keep NostalgiaVX's water coefficients, but filter the atmospheric component through
        // the configured water color so sunsets do not turn the entire underwater scene orange.
        vec3 waterTint = sqrt(max(vec3(waterRed, waterGreen, waterBlue), vec3(1e-4)));
        waterTint /= max(maxOf(waterTint), 1e-4);
        float skyEnergy = max(avgOf(underwaterScatterColor), 0.0);
        vec3 filteredScatter = waterTint * skyEnergy * 0.85;
        underwaterScatterColor = mix(underwaterScatterColor, filteredScatter, underwaterBlueFilter);

        sceneColor = getWaterFog(sceneColor, length(position0) * underwaterFogDensityMult, underwaterScatterColor);
        #else
        sceneColor = getWaterFog(sceneColor, length(position0), underwaterScatterColor);
        #endif
    }
    #endif

    //clear7  = vec4(0);

    #ifdef fogVolumeEnabled
        mat2x3 fogData;
        if (stainedGlass) {
            // The spatial fog filter keys its weights from depthtex0. On stained glass that
            // depth is the nearby pane, not the hidden water/terrain endpoint used to generate
            // this pixel's fog. Sampling it directly avoids re-filtering against the wrong depth
            // domain at the pane boundary.
            fogData = mat2x3(texture(colortex5, uv).rgb, texture(colortex7, uv).rgb);
        } else {
            #ifdef fogSmoothingEnabled
                fogData = sampleFogSpatial(uv, 1.0);
            #else
                fogData = mat2x3(texture(colortex5, uv).rgb, texture(colortex7, uv).rgb);
            #endif
        }

        applyFogData(sceneColor, fogData);

    #endif

    vec4 Clouds_PostFog = texture(colortex4, uv);

    sceneColor  = sceneColor * Clouds_PostFog.a + Clouds_PostFog.rgb;

    if (isEyeInWater == 2) sceneColor.rgb = lavaFog(sceneColor.rgb, length(position0));
    sceneColor.rgb = blindnessFog(sceneColor.rgb, length(position0));

    // V15AL: restore NostalgiaVX's native stained-glass surface AFTER the corrected
    // behind-pane atmosphere has been resolved. V15AK's equal-luminance hue filter kept
    // the fog but made stained panes look pale/clear and unlike the artist's original glass.
    //
    // At this point sceneColor already contains the full behind-pane water, normal/distant
    // fog, volumetrics and clouds. Apply the same two pieces the native path used:
    //   1) colored transmission/absorption of the background
    //   2) the actual lit front-pane RGB at its original alpha
    // This keeps the V15AK depth fix while restoring the original glass identity.
    if (stainedGlass) {
        float paneA = clamp(frontStainedAlpha, 0.0, 0.96);
        vec3 nativeAbsorption = max(saturate(reflectionAux[1]), vec3(1e-4));
        vec3 transmittedScene = sceneColor.rgb * nativeAbsorption;
        sceneColor.rgb = transmittedScene * (1.0 - paneA) + frontStainedColor * paneA;
    }

    bloomTiles = vec4(0, 0, 0, 1);
    //clear7  = vec4(0);
}