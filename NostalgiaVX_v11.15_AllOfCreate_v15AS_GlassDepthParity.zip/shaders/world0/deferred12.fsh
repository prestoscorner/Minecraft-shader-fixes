#version 430 compatibility

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/


/* RENDERTARGETS: 0,3,5 */
layout(location = 0) out vec4 sceneColor;
layout(location = 1) out vec4 lightingData;
layout(location = 2) out vec4 translucentColor;

#define RSSBO_ENABLE_COLOR
#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"
#include "/lib/util/colorspace.glsl"

in vec2 uv;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex7, colortex10;
uniform sampler2D colortex12;
uniform sampler2D colortex13;

uniform sampler2D depthtex0;
uniform sampler2D depthtex2;

uniform sampler2D RAtlasSampler;

uniform float lightFlip;
uniform float sunAngle;
uniform float near, far;

uniform ivec2 atlasSize;

uniform vec2 pixelSize, viewSize;

#define FUTIL_LINDEPTH
#include "/lib/fUtil.glsl"

#include "/lib/light/SVGF_Upscaler.glsl"

vec4 packReflectionAux(vec3 directLight, vec3 albedo) {
    vec4 lightRGBE  = encodeRGBE8(directLight);
    vec4 albedoRGBE = encodeRGBE8(albedo);

    return vec4(pack2x8(lightRGBE.xy),
                pack2x8(lightRGBE.zw),
                pack2x8(albedoRGBE.xy),
                pack2x8(albedoRGBE.zw));
}

uniform sampler2DShadow shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;

uniform vec2 taaOffset;
uniform vec3 cameraPosition;
uniform usampler3D RVoxelMap0, RVoxelMap1, RVoxelOctree;
uniform sampler3D RVoxelColor, RLPV;

#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
#endif

uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferProjectionInverse;

#include "/lib/util/transforms.glsl"

#include "/lib/voxel/store.glsl"
#include "/lib/voxel/trace.glsl"

void unpackVoxeldata(in uint data, out uvec2 offset, out int textureRes) {
    offset = uvec2((data >> 11) & 0x000007FFu, data & 0x000007FFu);
    textureRes = int(pow(2.0, ((data >> 22) & 0x0000000Fu)));
    offset *= textureRes;
}

vec4 unpackTangent(vec3 normal) {
	vec4 tangent = vec4(0,0,0,1);
	tangent.xz = abs(normal.y) > 0.0 ? vec2(1,0): vec2(normal.z,-normal.x);
	return tangent;
}

uvec3 UnpackVoxelUV(uvec2 rawBF) {
    uint bf = (rawBF.x << 15u) | rawBF.y;
    uint textureRes = 1u << (bitfieldExtract(bf, 22, 4));
    return uvec3(
        bitfieldExtract(bf, 0, 11),
        bitfieldExtract(bf, 11, 11),
        1u
    ) * textureRes;
}

vec2 RVoxel_GetAtlasUV(ivec3 Index, vec3 Position, vec3 Normal, uvec2 VoxelData) {
    vec4 Tangent = unpackTangent(Normal);

    uvec2 AtlasData = uvec2(bitfieldExtract(VoxelData.x, 14, 15), bitfieldExtract(VoxelData.y, 0, 15));

    uvec3 VoxelUV = UnpackVoxelUV(AtlasData);    //offset.xy, res

    vec2 TileIndexFraction = unpack2x8(AtlasData.x);
    vec2 TileIndex = unpack2x8(AtlasData.y);
    vec2 tileIndexFloored = decode2x4Unorm(TileIndex.x);

    ivec2 atlasSize = textureSize(RAtlasSampler, 0);

    mat3 tbnMat = mat3(Tangent.xyz, cross(Tangent.xyz, Normal.xyz) * Tangent.w, Normal);
    vec2 uv = ((fract(Position)-0.5) * tbnMat).xy+0.5;

    uv = VoxelUV.xy + VoxelUV.z * uv;

    uv /= atlasSize;
/*
    vec2 uv;

	if (abs(Normal.y) > abs(Normal.x) && abs(Normal.y) > abs(Normal.z)) {
		uv = vec2(fract(Position.x), fract(Position.z * sign(Normal.y)));
	} else {
		uv = vec2(fract(Position.x * sign(Normal.z) - Position.z * sign(Normal.x)), fract(-Position.y));
	}

    uv += 256.0 * 15.0 * tileIndexFloored + 255.0 * TileIndexFraction;
    uv *= exp2(TileIndex.y * 15.0) / atlasSize;*/

    return uv;
}

vec3 RLPV_Read(ivec3 index) {
    return clamp16F(texelFetch(RLPV, index, 0).rgb);
}

uniform int heldItemId, heldItemId2;
uniform int heldBlockLightValue, heldBlockLightValue2;

#include "/lib/light/emission.glsl"

void main() {
    sceneColor          = stex(colortex0);
    float sceneDepth    = stex(depthtex0).x;
    vec3 albedo         = vec3(1.0);
    vec3 directLight    = vec3(1.0);
    //indirectLuma        = 0.0;

    if (landMask(sceneDepth)) {
        vec4 tex1       = stex(colortex1);
        vec3 sceneNormal = decodeNormal(tex1.xy);

        bool hand   = sceneDepth < stex(depthtex2).x;

            albedo          = sceneColor.rgb;
            directLight     = stex(colortex4).rgb * 2.0;

        float SSAO = ReadLightAux(colortex5, ivec2(gl_FragCoord.xy * 0.5 / ResolutionScale)).y;

        //vec3 indirectLight = ResolutionScale != 0.5 ? atrousSVGF(colortex5, colortex3, uv, sceneNormal, sceneDepth, SSAO) : ReadLight(colortex5, ivec2(gl_FragCoord.xy));
        vec3 indirectLight = atrousSVGF(colortex5, colortex3, uv, sceneNormal, sceneDepth, SSAO);
        

        vec4 tex2       = stex(colortex2);
        ivec2 matID     = unpack2x8I(tex2.y);
        bool stableHandMaterial = matID.x == 201;
        bool isSSS          = matID.x == 2 || matID.x == 4;

        //vec3 indirectLight = ProjectIrradiance(indirectLightSH, matID.x == 2 ? normalize(mix(sceneNormal, vec3(0,1,0), 0.5)) : sceneNormal) * SSAO;
        indirectLight *= SSAO;

        if (stableHandMaterial) {
            // The world GI buffer is Monte-Carlo/SVGF data and is intentionally unsuitable
            // for a camera-relative held object. Use deterministic lightmap ambient instead.
            vec2 handLightmap = saturate(unpack2x8(tex1.z));
            vec3 handBlockAmbient = pow5(handLightmap.x) * RColorTable.Blocklight;
            vec3 handSkyAmbient = cube(handLightmap.y) * RColorTable.Skylight * rpi;
            indirectLight = max(handBlockAmbient, handSkyAmbient);
            indirectLight = max(indirectLight, minimumAmbientColor * minimumAmbientMult * minimumAmbientIllum);
            SSAO = 1.0;
        }

        #ifdef textureAoEnabled
            indirectLight  *= saturate(stex(colortex2).w);
        #endif

            directLight    *= RColorTable.DirectLight * SSAO;

        vec3 emission       = sqr(normalizeSafe(albedo)) * sceneColor.a * sqrt2;
        if (stableHandMaterial || hand) {
            // Never infer emission from the rendered hand surface itself. Only explicitly
            // mapped held lights (item.properties) or a non-zero vanilla held-light value
            // are allowed to contribute. This makes ordinary blocks deterministic.
            bool primaryHandSide = uv.x > (0.5 * ResolutionScale);
            int selectedHeldID = primaryHandSide ? heldItemId : heldItemId2;
            int selectedHeldLight = primaryHandSide ? heldBlockLightValue : heldBlockLightValue2;
            emission = vec3(0.0);
            if (selectedHeldID > 0 || selectedHeldLight > 0) {
                bool AnyEmitterMain = false;
                vec3 EmissionColorMain = GetEmission_Handheld(selectedHeldID, float(selectedHeldLight) / 15.0, AnyEmitterMain);
                emission = EmissionColorMain * rpi / euler;
            }
        }

        // Entity name tags are screen-facing UI-like text. Keep their albedo intact and
        // bypass scene irradiance so VX/PBR lighting cannot randomly black them out.
        #ifdef nameTagFullbright
            if (matID.x == 200) {
                directLight = vec3(0.0);
                indirectLight = vec3(1.0);
                emission = vec3(0.0);
            }
        #endif

        sceneColor.rgb     *= directLight + indirectLight.rgb + emission;
        //sceneColor.rgb      = directLight + indirectLight;

        #if DEBUG_VIEW == 2
            sceneColor.rgb      = indirectLight.rgb;
        #endif

        //sceneColor.rgb = stex(colortex5).rgb;

        //sceneColor.rgb = vec3(indirectLight.a);
        //indirectLuma        = avgOf(indirectLight);
    }
#ifdef DISTANT_HORIZONS
    else if (landMask(stex(dhDepthTex0).x)) {
        sceneColor.rgb *= ReadLightAux(colortex5, ivec2(gl_FragCoord.xy * 0.5 / ResolutionScale)).y;
    }
#endif
/*
    vec3 ScenePos = vec3(uv / ResolutionScale, sceneDepth);
        ScenePos = screenToViewSpace(ScenePos, true);
        ScenePos = viewToSceneSpace(ScenePos);   
    vec3 StartPos = RVoxel_SceneToVoxelSpace(vec3(0));
    ivec3 StartVoxel = RVoxel_GetIndex(StartPos);
    vec3 HitPos = StartPos;
    ivec3 HitVoxel = StartVoxel;
    vec3 HitNormal = vec3(0,1,0);

    vec3 Absorption = vec3(1);
    uvec2 VoxelData = uvec2(0);

    #if 1
    bool Hit = RVoxel_MarchBVH(StartPos, StartVoxel, normalize(ScenePos), HitPos, HitNormal, HitVoxel, VoxelData, Absorption, false);
    #else
    bool Hit = RVoxel_March(StartPos, StartVoxel, normalize(ScenePos), 256, HitPos, HitNormal, HitVoxel, VoxelData, Absorption);
    #endif

    sceneColor.rgb = sqr(fract(vec3(length(RVoxel_ToSceneSpace(HitPos)) / 32.0))) * 2.0 + 2.0;
    if (Hit) sceneColor.rgb *= srgbToPipelineColor(texture(RAtlasSampler, RVoxel_GetAtlasUV(HitVoxel, HitPos, HitNormal, VoxelData)).rgb * RVoxel_GetTint(VoxelData));
    sceneColor.rgb *= Absorption;
    //sceneColor.rgb *= RLPV_Read(ivec3(HitPos + HitNormal / 64.0));
    //if (Hit) sceneColor.rgb = texelFetch(RVoxelColor, HitVoxel, 0).rgb;
    //if (Hit) sceneColor.rgb = HitNormal * 0.5 + 0.5;
    //sceneColor.rgb += OctreeVis * 2.0;
*/
    //sceneColor.rgb = texture(colortex10, uv / 2 / ResolutionScale).rgb;

    sceneColor          = drawbufferClamp(sceneColor);
    translucentColor    = vec4(0.0);
    lightingData        = packReflectionAux(directLight, albedo);
}