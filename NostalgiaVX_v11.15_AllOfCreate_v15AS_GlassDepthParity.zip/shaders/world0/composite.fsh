#version 430 compatibility

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

/* RENDERTARGETS: 0,5,7,4 */
layout(location = 0) out vec3 sceneColor;
layout(location = 1) out vec4 fogScattering;
layout(location = 2) out vec3 fogTransmittance;
layout(location = 3) out vec4 cloudPostFog;

#define RSSBO_ENABLE_COLOR
#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"

const bool shadowHardwareFiltering = true;

in vec2 uv;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex7;
uniform sampler2D colortex8;
uniform sampler2D colortex10;
uniform sampler2D colortex11;
uniform sampler2D colortex15;

uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D depthtex2;

uniform sampler2D noisetex, RCloudTexture, RSkybox;

uniform sampler2DShadow shadowtex0HW;
uniform sampler2DShadow shadowtex1HW;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;

uniform usampler3D RVoxelMap0, RVoxelMap1, RVoxelOctree;
uniform sampler3D RVoxelColor, RLPV, RBluenoise3D;

uniform int frameCounter;
uniform int isEyeInWater;
uniform int worldTime;

uniform float eyeAltitude;
uniform float far, near;
uniform float frameTimeCounter;
uniform float cloudLightFlip, wetness;
uniform float sunAngle;
uniform float lightFlip;
uniform float worldAnimTime;

uniform ivec2 eyeBrightnessSmooth;

uniform vec2 taaOffset;
uniform vec2 viewSize, pixelSize;

uniform vec3 cameraPosition;
uniform vec3 lightDirView, lightDir;
uniform vec3 cloudLightDir, cloudLightDirView;

uniform vec4 daytime;

uniform mat4 gbufferProjectionInverse, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferModelView;
uniform mat4 shadowModelView, shadowModelViewInverse;
uniform mat4 shadowProjection, shadowProjectionInverse;

#define FUTIL_LINDEPTH
#include "/lib/fUtil.glsl"

#include "/lib/frag/bluenoise.glsl"
#include "/lib/frag/gradnoise.glsl"

#include "/lib/util/bicubic.glsl"
#include "/lib/util/transforms.glsl"
#include "/lib/atmos/project.glsl"
#include "/lib/atmos/phase.glsl"
#include "/lib/atmos/waterConst.glsl"

vec3 getFog(vec3 color, float dist, vec3 skyColor, vec3 sceneDir) {
	    dist 	= dist / far;
		dist 	= max((dist - fogStart), 0.0);
        dist   /= 1.0 - fogStart;
        
	float alpha = 1.0-exp(-dist * fogFalloff);
        alpha *= alpha;
        alpha  *= cube(1.0 - max0(sceneDir.y));

	color 	= mix(color, skyColor, saturate(alpha));

	return color;
}

vec3 getWaterFog(vec3 SceneColor, float dist, vec3 ScatterColor){
    float density   = max0(dist) * waterDensity;

    vec3 transmittance = expf(-waterAttenCoeff * density);

    const vec3 scatterCoeff = vec3(waterRed, waterGreen, waterBlue);

    #ifdef waterDepthColorEnabled
        // Phase 1: preserve the creator's water coefficients, but let physical path length
        // push deep water progressively toward that same configured hue.
        float depthColorMix = (1.0 - exp(-max0(dist) / max(waterDepthColorDistance, 1e-3))) * waterDepthColorStrength;
        vec3 depthHue = sqrt(max(scatterCoeff, vec3(1e-4)));
        depthHue /= max(maxOf(depthHue), 1e-4);
        vec3 sceneDepthTint = mix(vec3(1.0), mix(vec3(0.42), depthHue, 0.74), saturate(depthColorMix));
        vec3 scatterDepthTint = mix(vec3(1.0), mix(vec3(0.72), sqrt(depthHue), 0.65), saturate(depthColorMix * 0.60));
        SceneColor *= sceneDepthTint;
        ScatterColor *= scatterDepthTint;
    #endif

    vec3 scatter    = 1.0-exp(-density * scatterCoeff);
        scatter    *= max(expf(-waterAttenCoeff * density), expf(-waterAttenCoeff * tau));

    return SceneColor * transmittance + scatter * ScatterColor * rpi;
}

#include "/lib/light/warp.glsl"
#include "/lib/frag/noise.glsl"

vec3 getShadowmapPos(vec3 scenePos, const float bias) {  //shadow 2d
    vec3 pos    = scenePos + vec3(bias) * lightDir;
    float a     = length(pos);
        pos     = transMAD(shadowModelView, pos);
        pos     = projMAD(shadowProjection, pos);
        pos.z  *= 0.2;
        pos.xy  = shadowmapWarp(pos.xy);

    return pos*0.5+0.5;
}
vec3 toShadowmapTexturePos(vec3 shadowPos) {
    //shadowPos.z    *= 0.2;
    shadowPos.xy    = shadowmapWarp(shadowPos.xy) * 0.5 + 0.5;

    return shadowPos;
}

float readCloudShadowmap(sampler2D shadowmap, vec3 position) {
    position    = mat3(shadowModelView) * position;
    position   /= cloudShadowmapRenderDistance;
    position.xy = position.xy * 0.5 + 0.5;

    return texture(shadowmap, position.xy).a;
}

vec3 getShadowcol(sampler2D tex, vec2 coord) {
    vec4 x  = texture(tex, coord);
        x.rgb = sqr(x.rgb);

    if (x.a < 0.97 && x.a > 0.93) {
        x.rgb = vec3(0.1, 0.2, 1.0);
    }

    return mix(vec3(1.0), x.rgb, x.a);
}

#ifdef underwaterLightShaftsEnabled
/*
 * V24.16 underwater shaft definition pass:
 * - remains in the existing composite pass: no new targets/bindings/passes
 * - preserves NostalgiaVX water absorption, colored shadow and caustic data
 * - projected modulation is constant along the sun ray, producing coherent 3D columns
 * - definition control increases light/shadow separation instead of simply adding more fog
 */
vec3 underwaterWaterTint() {
    vec3 tint = sqrt(max(vec3(waterRed, waterGreen, waterBlue), vec3(1e-4)));
    return tint / max(maxOf(tint), 1e-4);
}

vec3 underwaterShadowTransmission(vec3 rayPos, vec3 shadowCoord) {
    float translucentVisibility = texture(shadowtex0HW, shadowCoord);
    float solidVisibility       = texture(shadowtex1HW, shadowCoord);

    vec3 transmission = vec3(1.0);
    if (abs(solidVisibility - translucentVisibility) > 1e-3) {
        vec4 shadowSample = texture(shadowcolor0, shadowCoord.xy);

        // Reconstruct NostalgiaVX's existing colored/water shadow result.
        vec3 waterShadow = max0(shadowSample.rgb * 4.0);
        transmission = mix(vec3(1.0), waterShadow, saturate(shadowSample.a));

        // Preserve the creator's caustic shape, increasing only volumetric contrast.
        float lane = smoothstep(0.16, 1.02, avgOf(transmission));
        float darkGain = mix(0.52, 0.22, underwaterShaftDefinition);
        float lightGain = mix(1.28, 1.72, underwaterShaftDefinition);
        transmission *= mix(darkGain, lightGain, lane);
    }

    // A sun-projected pattern is constant along the light vector. Unlike a screen-space
    // overlay this therefore forms actual columns which remain attached to the world.
    float lightY = lightDir.y;
    if (abs(lightY) < 0.12) lightY = lightY < 0.0 ? -0.12 : 0.12;

    vec3 worldPos = rayPos + cameraPosition;
    vec2 beamPlane = worldPos.xz - lightDir.xz * (worldPos.y / lightY);
    vec2 wind = vec2(frameTimeCounter * 0.0018, -frameTimeCounter * 0.0011);

    float beamNoise0 = texture(noisetex, beamPlane * 0.0065 + wind).g;
    float beamNoise1 = texture(noisetex, beamPlane * 0.0180 - wind * 1.7).b;
    float beamNoise2 = texture(noisetex, beamPlane * 0.0360 + wind * 2.35).r;
    float beamNoise = beamNoise0 * 0.52 + beamNoise1 * 0.33 + beamNoise2 * 0.15;

    // Higher definition narrows the bright lanes and deepens the water between them.
    float laneLo = mix(0.27, 0.39, underwaterShaftDefinition);
    float laneHi = mix(0.80, 0.67, underwaterShaftDefinition);
    float beamLane = smoothstep(laneLo, laneHi, beamNoise);
    float beamDark = mix(0.72, 0.30, underwaterShaftDefinition);
    float beamBright = mix(1.22, 1.72, underwaterShaftDefinition);
    transmission *= mix(beamDark, beamBright, beamLane);

    // Contrast values below one without clipping the caustic peaks above one.
    float contrastPower = mix(1.0, 1.62, underwaterShaftDefinition);
    transmission = pow(max(transmission, vec3(1e-4)), vec3(contrastPower));
    transmission = min(transmission, vec3(3.25));

    return transmission * solidVisibility;
}

vec3 getUnderwaterLightShafts(vec3 sceneDir, float rayDistance, float dither, float cave) {
    float endDist = min(max0(rayDistance), underwaterShaftDistance);
    if (endDist <= 0.25 || cave <= 1e-3) return vec3(0.0);

    vec3 rayDir = normalize(sceneDir);
    float vDotL = clamp(dot(rayDir, lightDir), -1.0, 1.0);

    // V24.16: less broad fill, more directional energy. This keeps bright beams bright
    // without washing every underwater pixel in the same blue glow.
    float phaseFocused = mieHG(vDotL, underwaterShaftFocus) * tau;
    float phaseBroad   = mieHG(vDotL, 0.30) * tau;
    float phase = clamp(phaseFocused * 0.92 + phaseBroad * 0.08, 0.020, 3.15);

    vec3 accum = vec3(0.0);
    float previousWeight = 0.0;

    for (int i = 0; i < underwaterShaftSamples; ++i) {
        float t = (float(i) + 0.20 + 0.80 * dither) / float(underwaterShaftSamples);
        float sampleDistance = pow(t, 1.50) * endDist;
        vec3 rayPos = rayDir * sampleDistance;

        vec3 shadowCoord = getShadowmapPos(rayPos, 0.035);
        bool validShadow = all(greaterThanEqual(shadowCoord, vec3(0.001))) &&
                           all(lessThanEqual(shadowCoord, vec3(0.999)));
        if (!validShadow) continue;

        vec3 visibility = underwaterShadowTransmission(rayPos, shadowCoord);

        // Full water fog still performs the creator's normal attenuation afterward. Keep
        // shaft extinction gentler so coherent bright lanes survive into the middle distance.
        vec3 waterTransmission = expf(-waterExtinctionCoeff * (sampleDistance * waterDensity * 0.105));

        float weight = 1.0 - exp(-sqr(sampleDistance / 46.0));
        float sliceWeight = max0(weight - previousWeight);
        previousWeight = weight;

        accum += visibility * waterTransmission * sliceWeight;
    }

    vec3 waterTint = underwaterWaterTint();
    vec3 directHue = RColorTable.DirectLight / max(maxOf(RColorTable.DirectLight), 1e-4);
    vec3 shaftTint = mix(directHue, waterTint, underwaterBlueFilter);

    float directEnergy = sqrt(max(avgOf(RColorTable.DirectLight), 0.0));
    vec3 shaftColor = shaftTint * directEnergy * 0.31;

    return accum * shaftColor * phase * underwaterShaftStrength * sqrt(max0(cave));
}
#endif

/* --- LPV --- */
#include "/lib/voxel/store.glsl"

#include "/lib/voxel/lpvSampling.glsl"

vec3 lpvGetLightSmooth(vec3 scenePos) {
    vec3 VoxelPos = RVoxel_SceneToVoxelSpace(scenePos);
    if (RVoxel_OutsideVolume(ivec3(VoxelPos))) return vec3(0.0);
    return texture(RLPV, VoxelPos / 256.0).rgb;


    //ivec3 voxelIndex = RVoxel_GetIndexFromScene(scenePos /*- vec3(1,0,1)*/);
/*
    vec3 alpha  = fract(scenePos + cameraPosition - 0.5);
        alpha   = linStep(alpha, 0.001, 0.999);

    vec3 direction = fract(scenePos + cameraPosition) - 0.5;
    bvec3 isPositive = greaterThan(direction, vec3(0));


    //
    //  |    | Y+ |    |
    //
    //  | X- | M  | X+ |
    //
    //  |    | Y- |    |
    

    ivec3 mid   = voxelIndex;
    ivec3 edge  = voxelIndex + ivec3(isPositive.x ? 1 : -1, isPositive.y ? 1 : -1, isPositive.z ? 1 : -1);

    alpha.x         = isPositive.x ? alpha.x : 1.0 - alpha.x;
    alpha.y         = isPositive.y ? alpha.y : 1.0 - alpha.y;
    alpha.z         = isPositive.z ? alpha.z : 1.0 - alpha.z;

    vec3 tap_LY_LZ  = mix(readLPVOffset(mid, ivec3(mid.x, mid.y, mid.z)), 
                          readLPVOffset(mid, ivec3(edge.x, mid.y, mid.z)), alpha.x);
    vec3 tap_LY_HZ  = mix(readLPVOffset(mid, ivec3(mid.x, mid.y, edge.z)), 
                          readLPVOffset(mid, ivec3(edge.x, mid.y, edge.z)), alpha.x);

    vec3 tap_HY_LZ  = mix(readLPVOffset(mid, ivec3(mid.x, edge.y, mid.z)), 
                          readLPVOffset(mid, ivec3(edge.x, edge.y, mid.z)), alpha.x);
    vec3 tap_HY_HZ  = mix(readLPVOffset(mid, ivec3(mid.x, edge.y, edge.z)), 
                          readLPVOffset(mid, ivec3(edge.x, edge.y, edge.z)), alpha.x);

    vec3 tap_LZ     = mix(tap_LY_LZ, tap_HY_LZ, alpha.y);
    vec3 tap_HZ     = mix(tap_LY_HZ, tap_HY_HZ, alpha.y);

    return mix(tap_LZ, tap_HZ, alpha.z);*/
}

/* ------ volumetric fog ------ */

const float airMieG   = 0.7;

const vec3 airRayleighCoeff     = vec3(3.54e-6, 5.47e-6, 7.62e-6);
const vec3 airMieCoeff          = vec3(9e-6);    //19e-5 for rain

const mat2x3 airScatterMat      = mat2x3(airRayleighCoeff, airMieCoeff);
const mat2x3 airExtinctMat      = mat2x3(airRayleighCoeff, airMieCoeff);

const vec3 fogMistCoeff         = vec3(4e-3);
const mat3x3 fogScatterMat      = mat3x3(airRayleighCoeff, airMieCoeff, fogMistCoeff);
const mat3x3 fogExtinctMat      = mat3x3(airRayleighCoeff, airMieCoeff * 1.1, fogMistCoeff);

const vec2 fogFalloffScale  = 1.0 / vec2(4e1, 25e1);
const vec2 fogAirScale      = vec2(100.0, 1e2);

vec2 airPhaseFunction(float cosTheta) {
    return vec2(rayleighPhase(cosTheta), mieCS(cosTheta, airMieG));
}
float airMieBackscatter(float cosTheta) {
    return mieHG(cosTheta, -airMieG * rcp(pi));
}
float fogMistPhase(float cosTheta, float density) {
    return mix(mieCS(cosTheta, pow(airMieG, 1.0 + density)), airMieBackscatter(cosTheta), 0.19);
}

uniform vec3 fogDensityCoeff;

#define fogMistAltitude 100.0
#define airDensity 1.0

#ifdef volumeWorldTimeAnim
    float fogTime     = worldAnimTime * 3.6;
#else
    float fogTime     = frameTimeCounter * 0.006;
#endif

float mistDensity(vec3 rPos, float altitude) {
    vec3 wind   = vec3(fogTime, 0.0, fogTime * 0.5);
    float noise = value3D(rPos * 0.037 + wind) + value3D(rPos * 0.08 + wind * 3.0) * 0.5;

    float mist  = expf(-max0((altitude - 64.0) * 0.01));
        mist    = sstep(noise * rcp(1.5) - (1.0 - mist) * 0.5, 0.33, 0.6);
        mist   *= sqr(1.0 - linStep(altitude, 85.0, fogMistAltitude));

    return mist * fogDensityCoeff.z;
}

vec3 fogAirDensity(vec3 rPos, float altitude, bool terrain) {
    //float dist  = length(rPos);
    rPos   += cameraPosition;

    float maxFade = sqr(1.0 - linStep(altitude, 144.0, 256.0));

    vec2 rm     = expf(-max0((altitude - 66.0) * fogFalloffScale));
    //rm.y *= 0;
    float mist  = 0.0;
    if (fogDensityCoeff.z > 1e-5) mist = mistDensity(rPos, altitude);
    //if (terrain) rm *= 1.0 + sstep(dist, far * 0.6, far) * pi * 50.0;

    return vec3(rm * fogAirScale * fogDensityCoeff.xy * maxFade * fogDensityMult, mist);
}

float fogMistLightOD(vec3 pos) {
    float stepsize = 12.0;

    const int steps = 2;

    float od = 0.0;

    for(uint i = 0; i < steps; ++i, pos += lightDir * stepsize) {

        if(pos.y > fogMistAltitude || pos.y < 0.0) continue;
        
        float density = mistDensity(pos, pos.y);
        if (density <= 0.0) continue;

            od += density * stepsize;
    }

    return od;
}

#ifdef DISTANT_HORIZONS
uniform int dhRenderDistance;
#endif

#ifdef aboveWaterGodRaysEnabled
float resolveGodRayFoliageShadow(vec3 shadowCoord, float baseShadow, out float edgeAmount) {
    // textureGather gives four independent comparison results from the same shadow map
    // already used by the volumetric pass. Mixed 0/1 neighborhoods are characteristic of
    // leaf holes, needles, branches and other fine silhouettes.
    vec4 taps = textureGather(shadowtex1HW, shadowCoord.xy, shadowCoord.z);
    float coverage = dot(taps, vec4(0.25));
    float variance = max0(coverage - coverage * coverage); // binary taps: E[x^2] == E[x]
    edgeAmount = saturate(variance * 4.0);

    float detail = aboveWaterGodRayFoliageDetail;
    float lo = mix(0.10, 0.31, detail);
    float hi = mix(0.90, 0.69, detail);
    float resolved = smoothstep(lo, hi, coverage);

    // Mostly leave broad terrain shadows alone; focus the additional contrast where the
    // shadow map itself says the texel neighborhood contains a fine silhouette.
    float blend = detail * (0.18 + 0.82 * edgeAmount);
    return mix(baseShadow, resolved, blend);
}
#endif

mat2x3 volumetricFog(vec3 scenePos, vec3 sceneDir, bool isSky, float vDotL, float dither, float cave, vec3 skyColor) {
    float topDist    = length(sceneDir * ((256.0 - eyeAltitude) * rcp(sceneDir.y)));
    float bottomDist = length(sceneDir * ((-32.0 - eyeAltitude) * rcp(sceneDir.y)));

    float volumeHull = sceneDir.y > 0.0 ? topDist : bottomDist;

    float endDist   = isSky ? min(volumeHull, min(fogClipDist, far)) : min(fogClipDist, length(scenePos));
    float startDist = eyeAltitude > 256.0 ? topDist : 1.0;

    vec3 startPos   = eyeAltitude > 256.0 ? sceneDir * startDist : vec3(0.0);
        startPos   += gbufferModelViewInverse[3].xyz;
    vec3 endPos     = isSky ? sceneDir * endDist : sceneDir * endDist;

    float baseStep  = length(endPos - startPos);
    float stepCoeff = saturate(baseStep * rcp(clamp(far, 256.0, 512.0)));

    uint steps      = fogMinSteps + uint(stepCoeff * fogAdaptiveSteps);

    vec3 rStep      = (endPos - startPos) / float(steps);
    vec3 rPos       = startPos + rStep * dither;
    float rLength   = length(rStep);

    vec3 shadowStartPos = transMAD(shadowModelView, (startPos));
        shadowStartPos  = projMAD(shadowProjection, shadowStartPos);
        shadowStartPos.z *= 0.2;
    vec3 shadowEndPos   = transMAD(shadowModelView, (endPos));
        shadowEndPos    = projMAD(shadowProjection, shadowEndPos);
        shadowEndPos.z *= 0.2;

    vec3 shadowStep = (shadowEndPos - shadowStartPos) / float(steps);
    vec3 shadowPos  = shadowStartPos + shadowStep * dither;

    mat2x3 scattering = mat2x3(0.0);
    vec3 transmittance = vec3(1.0);

    vec3 phase;
        phase.xy    = airPhaseFunction(vDotL);
        phase.z     = mix(mieCS(vDotL, airMieG * mistMieAnisotropy), airMieBackscatter(vDotL), mistMieAnisotropy / 4.0);
    float phaseIso  = 0.25;

    vec3 sunlight       = RColorTable.DirectLight * sqrt2;
    vec3 skylight       = RColorTable.Skylight * cave;
        skylight       += vec3(0.05, 0.4, 1.0) * 0.12 * (1-cave);

    #ifdef lightleakWorkaroundToggle
        sunlight       *= cave;
    #endif

    float pFade         = saturate(mieHG(vDotL, 0.65));

    uint i = 0;
    do {
        rPos += rStep; shadowPos += shadowStep;
        if ((length(rPos) > length(fogClipDist) || length(rPos) > endDist) && !isSky) break;
    //for (uint i = 0; i < steps; ++i, rPos += rStep, shadowPos += shadowStep) {
        if (maxOf(transmittance) < 0.01) break;

        float altitude  = rPos.y + eyeAltitude;

        if (altitude > 256.0) continue;

        vec3 density    = fogAirDensity(rPos, altitude, !isSky);
            density.x   = mix(density.x, 250.0, (1-cave) * expf(-max0((altitude - 50.0) * 0.01)));

        //if (maxOf(density) < 1e-32) continue;

        vec3 stepRho    = density * rLength;
        vec3 od         = fogExtinctMat * stepRho;

        vec3 stepT      = expf(-od);
        vec3 scatterInt = saturate((stepT - 1.0) * rcp(-max(od, 1e-16)));
        vec3 visScatter = transmittance * scatterInt;

        #ifdef fogMistAdvanced
            if (density.z > 0.0) {
                float mistLightOD = fogMistLightOD(rPos + cameraPosition);

                float mistLighting  = expf(-stepRho.z) * pow(1.0 + 1.0 * 0.7 * mistLightOD, -1.0 / 0.7);
                    mistLighting    = mix(pi * (1.0 - 0.6 * expf(-density.z * 28.0)), 1.0, pFade);
                    mistLighting    = fogMistPhase(vDotL, mistLightOD);
                phase.z     = mistLighting;
            }
        #else
            if (density.z > 0.0) {
                phase.z     = fogMistPhase(vDotL, density.z) * (2.0 - pFade);
            }
        #endif

        vec3 sunScatter = fogScatterMat * (stepRho * phase) * visScatter;
        vec3 IsoScatter = fogScatterMat * (stepRho) * visScatter;

        #ifdef USE_FOG_LPV
        vec3 lightScatter   = lpvGetLightSmooth(rPos) * FOG_LPV_CONTRIBUTION;
        #else
        const vec3 lightScatter = vec3(0);
        #endif

        vec3 shadowCoord = vec3(shadowmapWarp(shadowPos.xy), shadowPos.z) * 0.5 + 0.5;

        float shadow0   = texture(shadowtex0HW, shadowCoord);

        float shadow    = 1.0;
        vec3 shadowCol  = vec3(1.0);
        
        if (shadow0 < 1.0) {
            shadow      = texture(shadowtex1HW, shadowCoord);

            if (abs(shadow - shadow0) > 0.1) {
                shadowCol   = getShadowcol(shadowcolor0, shadowCoord.xy);
            }
        }

        float volumetricShadow = shadow;
        float godRayFoliageEdge = 0.0;
        #ifdef aboveWaterGodRaysEnabled
            // Resolve the local 2x2 shadow coverage before cloud modulation. This allows gaps
            // inside leaf textures and between small branches to split the volume into finer rays.
            volumetricShadow = resolveGodRayFoliageShadow(shadowCoord, shadow, godRayFoliageEdge);
        #endif

        #ifdef cloudShadowsEnabled
        float cloudShadowFactor = mix(readCloudShadowmap(RSkybox, rPos), 1.0, sstep(altitude, cloudVolume0Alt, cloudVolume0Alt + cloudVolume0Depth * euler));
        shadow             *= cloudShadowFactor;
        volumetricShadow   *= cloudShadowFactor;
        #endif

#ifdef DISTANT_HORIZONS
        float skyFade = sstep((length(rPos) * sqrPi) / dhRenderDistance, sqr(fogStart), 1.0);
        stepT = mix(stepT, vec3(1.0), skyFade * 0.78);
#else
        const float skyFade = 0.0;
#endif

        float directVolumetricBoost = 1.0;
        #ifdef aboveWaterGodRaysEnabled
            float godRayView = saturate(vDotL * 0.5 + 0.5);
            float godRayExponent = mix(2.0, 11.0, aboveWaterGodRayFocus);
            float godRayDirectional = pow(godRayView, godRayExponent);
            float godRayHorizon = 0.72 + 0.28 * (1.0 - saturate(abs(lightDir.y)));

            // Mixed canopy texels receive a small extra highlight on their *lit* portion only.
            // Shadows stay dark; sunlit holes/leaf gaps become more readable as individual shafts.
            float foliageBeamLift = 1.0 + godRayFoliageEdge * aboveWaterGodRayFoliageDetail * 0.32 * volumetricShadow;
            directVolumetricBoost += aboveWaterGodRayStrength * mix(0.08, 1.0, godRayDirectional) * godRayHorizon;
            directVolumetricBoost *= foliageBeamLift;
        #endif

        scattering[0]  += (sunScatter * shadowCol * transmittance) * volumetricShadow * (1.0 - skyFade) * directVolumetricBoost;
        scattering[1]  += mix((skylight * phaseIso + lightScatter) * IsoScatter, skyColor * IsoScatter * phaseIso, skyFade) * transmittance;

        transmittance  *= stepT;
    } while (++i < steps);

    vec3 color  = scattering[0] * sunlight + scattering[1];

    if (color != color) {   //because NaNs on nVidia don't need a logic cause to happen
        color = vec3(0.0);
        transmittance = vec3(1.0);
    }

    return mat2x3(color, transmittance);
}

void applyFogData(inout vec3 color, in mat2x3 data) {
    color = color * data[1] + data[0];
}

/* --- TEMPORAL CHECKERBOARD --- */

#define checkerboardDivider 4
#define ditherPass
#include "/lib/frag/checkerboard.glsl"


flat in vec3 cloudSunlight;
flat in vec3 cloudSkylight;

#define CloudTexture RCloudTexture

#include "/lib/atmos/clouds.glsl"

vec4 RSKY_VanillaClouds(vec3 WorldDirection, vec3 WorldPosition, float Dither, bool IsTerrain, vec3 SkyColor, out float HitDistance) {
    vec4 Result = vec4(0,0,0,1);

    vec3 DirectColor    = RColorTable.CloudDirectLight / sqrt2;
    vec3 AmbientColor   = RColorTable.CloudSkylight * euler;
    float vDotL         = dot(WorldDirection, cloudLightDir);

    float IsWithin      = sstep(eyeAltitude, float(RSKY_Volume0_Limits.x) - 15.0, float(RSKY_Volume0_Limits.x)) * (1.0 - sstep(eyeAltitude, RSKY_Volume0_Limits.y, RSKY_Volume0_Limits.y + 15.0));
    bool IsBelow        = eyeAltitude < cloudVol0MidY;
    bool IsVisible      = WorldDirection.y > 0.0 && IsBelow || WorldDirection.y < 0.0 && !IsBelow;

    #ifdef cloudVolumeStoryMode
        const float SigmaA  = 0.5;
            AmbientColor       /= sqrt2;
        const float SigmaT  = 0.15;
    #else
        const float SigmaA  = 0.5;
        const float SigmaT  = 0.41;
    #endif

    const float Albedo = 0.93;
    const float ScatterMult = 1.0;

    HitDistance     = far * 2.0;

    if (IsVisible || IsWithin > 0.0) {
        mat2x3 VolumeBounds = mat2x3(GetPlane(RSKY_Volume0_Limits.x, WorldDirection),
                                     GetPlane(RSKY_Volume0_Limits.y, WorldDirection));

        if (WorldDirection.y < 0.0 && IsBelow ||
            WorldDirection.y > 0.0 && !IsBelow) VolumeBounds = mat2x3(0.0);

        vec3 StartPos      = IsBelow ? VolumeBounds[0] : VolumeBounds[1];
        vec3 EndPos        = IsBelow ? VolumeBounds[1] : VolumeBounds[0];
            StartPos       = mix(StartPos, gbufferModelViewInverse[3].xyz, IsWithin);
            EndPos         = mix(EndPos, WorldDirection * cloudVolume0Clip / pi, IsWithin);

        if (IsTerrain) {
            if (length(EndPos) > length(WorldPosition)) EndPos = WorldPosition;
        }

        const float BaseStep = cloudVolume0Depth / (float(cloudVolume0Samples));
        float StepLength = abs(distance(StartPos, EndPos) / float(cloudVolume0Samples));

        float StepCoeff = 0.5 + clamp(((StepLength / BaseStep) - 1.0) / sqrt2, 0.0, 1.0);
        uint StepCount  = uint(max(cloudVolume0Samples * StepCoeff, cloudVolume0Depth / euler));

        vec3 RStep          = (EndPos - StartPos) / float(StepCount);
        vec3 RPosition      = RStep * Dither + StartPos + cameraPosition;
        float RLength       = length(RStep);

        for (uint I = 0; I < StepCount; ++I, RPosition += RStep) {
            if (Result.a < 0.01) break;
            if (RPosition.y < RSKY_Volume0_Limits.x || RPosition.y > RSKY_Volume0_Limits.y) continue;

            float SampleDistance  = distance(RPosition, cameraPosition);
            if (SampleDistance > cloudVolume0Clip) continue;

            float Density = cloudVolume0Shape(RPosition);
            if (Density <= 0.0) continue;

            HitDistance = min(HitDistance, SampleDistance);

            float StepOpticalDepth = Density * SigmaT * RLength;
            float StepTransmittance = exp(-StepOpticalDepth);

            vec3 StepScattering = vec3(0);

            vec2 LightExtinction = vec2(cloudVolume0LightOD(RPosition, 5, cloudLightDir),
                                        cloudVolume0LightOD(RPosition, 4, vec3(0.0, 1.0, 0.0))
                                       ) * SigmaA;

            #ifdef cloudLayerShadowing
            #ifdef cloudVolume1Enabled
                LightExtinction += vec2(cloudVolume0_SecondLayerOcclusion(RPosition, 3, cloudLightDir) / euler,
                                        cloudVolume0_SecondLayerOcclusion(RPosition, 3, vec3(0.0, 1.0, 0.0)) / tau
                                       ) * SigmaA;
            #endif
            #endif

            float AvgTransmittance = exp(-((tau / SigmaT) * Density));
            float BounceEstimate = EstimateEnergy(Albedo * (1.0 - AvgTransmittance));
            float BaseScatter = Albedo * (1.0 - StepTransmittance);
            vec3 PhaseG = pow(vec3(0.5, 0.35, 0.9), vec3((1.0 + (LightExtinction.x + Density * RLength) * SigmaT)));

            float DirScatterScale = pow(1.0 + 1.0 * LightExtinction.x * SigmaT, -1.0 / 1.0) * BounceEstimate;
            float AmbScatterScale = pow(1.0 + 1.0 * LightExtinction.y * SigmaT, -1.0 / 1.0) * BounceEstimate;

                StepScattering.xy = BaseScatter * vec2(cloudPhase(vDotL, PhaseG) * DirScatterScale,
                                                    cloudPhaseSky(WorldDirection.y, PhaseG * vec3(1,1,0.5)) * AmbScatterScale);

            vec3 SkyFade = exp(-SampleDistance * 2.8e-3 * vec3(1.0, 0.96, 0.85));
                SkyFade = mix(SkyFade, vec3(0), sstep(SampleDistance, float(cloudVolume0Clip) * 0.75, float(cloudVolume0Clip)));
                StepScattering = DirectColor * StepScattering.x + AmbientColor * StepScattering.y;
                StepScattering = mix(SkyColor * (1.0 - StepTransmittance), StepScattering, SkyFade);

            Result = vec4((StepScattering * Result.a) + Result.rgb, Result.a * StepTransmittance);
        }

        Result.a = linStep(Result.a, 0.01, 1.0) * 0.99 + 0.01;

        Result      = mix(Result, vec4(0,0,0,1), exp(-max0(WorldDirection.y * pi4)) * (1.0 - sstep(eyeAltitude, RSKY_Volume0_Limits.x - 16.0, RSKY_Volume0_Limits.x)));
    }


    #ifdef cloudVolume1Enabled
    IsWithin    = sstep(eyeAltitude, float(cloudVolume1Alt) - 15.0, float(cloudVolume1Alt)) * (1.0 - sstep(eyeAltitude, cloudVol1MaxY, cloudVol1MaxY + 15.0));
    IsBelow     = eyeAltitude < cloudVol1MidY;
    IsVisible   = WorldDirection.y > 0.0 && IsBelow || WorldDirection.y < 0.0 && !IsBelow;

    if (IsVisible || IsWithin > 0.0) {
        mat2x3 VolumeBounds = mat2x3(GetPlane(RSKY_Volume1_Limits.x, WorldDirection),
                                     GetPlane(RSKY_Volume1_Limits.y, WorldDirection));

        if (WorldDirection.y < 0.0 && IsBelow ||
            WorldDirection.y > 0.0 && !IsBelow) VolumeBounds = mat2x3(0.0);

        vec3 StartPos      = IsBelow ? VolumeBounds[0] : VolumeBounds[1];
        vec3 EndPos        = IsBelow ? VolumeBounds[1] : VolumeBounds[0];
            StartPos       = mix(StartPos, gbufferModelViewInverse[3].xyz, IsWithin);
            EndPos         = mix(EndPos, WorldDirection * cloudVolume1Clip / pi, IsWithin);

        if (IsTerrain) {
            if (length(EndPos) > length(WorldPosition)) EndPos = WorldPosition;
        }

        const float BaseStep = cloudVolume1Depth / (float(cloudVolume1Samples));
        float StepLength = abs(distance(StartPos, EndPos) / float(cloudVolume1Samples));

        float StepCoeff = 0.5 + clamp(((StepLength / BaseStep) - 1.0) / sqrt2, 0.0, 1.0);
        uint StepCount  = uint(max(cloudVolume1Samples * StepCoeff, cloudVolume1Depth / euler));

        vec3 RStep          = (EndPos - StartPos) / float(StepCount);
        vec3 RPosition      = RStep * Dither + StartPos + cameraPosition;
        float RLength       = length(RStep);

        vec4 LayerResult    = vec4(0,0,0,1);

        for (uint I = 0; I < StepCount; ++I, RPosition += RStep) {
            if (LayerResult.a < 0.01) break;
            if (RPosition.y < RSKY_Volume1_Limits.x || RPosition.y > RSKY_Volume1_Limits.y) continue;

            float SampleDistance  = distance(RPosition, cameraPosition);
            if (SampleDistance > cloudVolume1Clip) continue;

            float Density = cloudVolume1Shape(RPosition);
            if (Density <= 0.0) continue;

            HitDistance = min(HitDistance, SampleDistance);

            float StepOpticalDepth = Density * SigmaT * RLength;
            float StepTransmittance = exp(-StepOpticalDepth);

            vec3 StepScattering = vec3(0);

            vec2 LightExtinction = vec2(cloudVolume1LightOD(RPosition, 5, cloudLightDir),
                                        cloudVolume1LightOD(RPosition, 4, vec3(0.0, 1.0, 0.0))
                                       ) * SigmaA;

            float AvgTransmittance = exp(-((tau / SigmaT) * Density));
            float BounceEstimate = EstimateEnergy(Albedo * (1.0 - AvgTransmittance));
            float BaseScatter = Albedo * (1.0 - StepTransmittance);
            vec3 PhaseG = pow(vec3(0.5, 0.35, 0.9), vec3((1.0 + (LightExtinction.x + Density * RLength) * SigmaT)));

            float DirScatterScale = pow(1.0 + 1.0 * LightExtinction.x * SigmaT, -1.0 / 1.0) * BounceEstimate;
            float AmbScatterScale = pow(1.0 + 1.0 * LightExtinction.y * SigmaT, -1.0 / 1.0) * BounceEstimate;

                StepScattering.xy = BaseScatter * vec2(cloudPhase(vDotL, PhaseG) * DirScatterScale,
                                                    cloudPhaseSky(WorldDirection.y, PhaseG * vec3(1,1,0.5)) * AmbScatterScale);

            vec3 SkyFade = exp(-SampleDistance * (2.8e-3 * vec3(1.0) * 0.9));
                SkyFade = mix(SkyFade, vec3(0), sstep(SampleDistance, float(cloudVolume1Clip) * 0.75, float(cloudVolume1Clip)));
                StepScattering = DirectColor * StepScattering.x + AmbientColor * StepScattering.y;
                StepScattering = mix(SkyColor * (1.0 - StepTransmittance), StepScattering, SkyFade);

            LayerResult = vec4((StepScattering * LayerResult.a) + LayerResult.rgb, LayerResult.a * StepTransmittance);
        }

        LayerResult.a       = linStep(LayerResult.a, 0.01, 1.0) * 0.99 + 0.01;

        LayerResult      = mix(LayerResult, vec4(0,0,0,1), exp(-max0(WorldDirection.y * pi4)) * (1.0 - sstep(eyeAltitude, RSKY_Volume1_Limits.x - 16.0, RSKY_Volume1_Limits.x)));


        if (eyeAltitude < cloudVolume1Alt) {
            Result.rgb    += LayerResult.rgb * Result.a;
        } else {
            Result.rgb     = Result.rgb * LayerResult.a + LayerResult.rgb;
        }

        Result.a *= LayerResult.a;
    }
    #endif
    return Result;
}

/* ------ Reflections ------ */
#define RTRACE
#include "/lib/frag/reflection.glsl"

vec3 ditherBluenoiseStaticF3() {
    ivec2 coord = ivec2(gl_FragCoord.xy);

    #ifdef SPF_TEMPORAL_BLUENOISE
    vec3 noise  = texelFetch(RBluenoise3D, ivec3(coord & 255, frameCounter & 7), 0).xyz;
    #else
    vec3 noise  = texelFetch(RBluenoise3D, ivec3(coord & 255, 0), 0).xyz;
    #endif
        //noise.xyz  = fract(noise.xyz + torroidalShift.xyz * frameCounter);

    return noise;
}

uniform vec3 previousCameraPosition;
uniform mat4 gbufferPreviousProjection, gbufferPreviousModelView;

vec3 reproject(vec3 sceneSpace, bool hand) {
    vec3 prevScreenPos = hand ? vec3(0.0) : cameraPosition - previousCameraPosition;
    prevScreenPos = sceneSpace + prevScreenPos;
    prevScreenPos = transMAD(gbufferPreviousModelView, prevScreenPos);
    prevScreenPos = transMAD(gbufferPreviousProjection, prevScreenPos) * (0.5 / -prevScreenPos.z) + 0.5;
    //prevScreenPos.xy += previousTaaOffset * 0.5 * pixelSize;

    return prevScreenPos;
}

/* ------ Refraction ------ */

#include "/lib/atmos/hiddenWater.glsl"

vec3 refract2(vec3 I, vec3 N, vec3 NF, float eta) {     //from spectrum by zombye
    float NoI = dot(N, I);
    float k = 1.0 - eta * eta * (1.0 - NoI * NoI);
    if (k < 0.0) {
        return vec3(0.0); // Total Internal Reflection
    } else {
        float sqrtk = sqrt(k);
        vec3 R = (eta * dot(NF, I) + sqrtk) * NF - (eta * NoI + sqrtk) * N;
        return normalize(R * sqrt(abs(NoI)) + eta * I);
    }
}


#ifdef DISTANT_HORIZONS
uniform mat4 dhProjectionInverse, dhProjection;
uniform sampler2D dhDepthTex0, dhDepthTex1;
#endif

void main() {
    sceneColor  = texture(colortex0, uv).rgb;

    vec4 GBuffer0       = texture(colortex1, uv);

    vec4 GBuffer1       = texture(colortex2, uv);
    vec2 materialTag    = unpack2x8(GBuffer1.y);
    int matID           = int(materialTag.x * 255.0);
    vec2 stainedGlassMeta = unpack2x8(GBuffer1.z);
    int stainedGlassColorIndex = int(stainedGlassMeta.x * 255.0 + 0.5);
    bool stainedGlass   = (matID == 101) && (stainedGlassColorIndex > 0);
    float frontStainedAlpha = stainedGlass ? stainedGlassMeta.y : 0.0;
    vec3 frontStainedColor = stainedGlass ? unpackColor16(GBuffer1.w) : vec3(0.0);

    vec4 translucencyColor  = texture(colortex5, uv);

#ifdef DISTANT_HORIZONS
    vec2 dhDepth = vec2(stex(dhDepthTex0).x, stex(dhDepthTex1).x);
    bvec2 isDH = bvec2(landMask(dhDepth.x), landMask(dhDepth.y));
#else
    const bvec2 isDH = bvec2(false, false);
#endif

    vec2 sceneDepth = vec2(stex(depthtex0).x, stex(depthtex1).x);
    bvec2 isTerrain = bvec2(landMask(sceneDepth.x), landMask(sceneDepth.y));
    bool water = matID == 102;
    vec4 hiddenWaterAux = stex(colortex15);
    float hiddenWaterCode = fract(max(hiddenWaterAux.a, 0.0));
    vec3 hiddenWaterNativeColor = max(hiddenWaterAux.rgb, vec3(0.0));
    bool waterLayerPresent = hiddenWaterCode > (0.5 / 65535.0);
    bool waterBehindTranslucent = waterLayerPresent && !water && (matID == 101 || matID == 103);
    
    bool translucent    = sceneDepth.x < sceneDepth.y;
#ifdef DISTANT_HORIZONS
        if (!isTerrain.x) translucent = translucent || (dhDepth.x < dhDepth.y);
#endif

    vec3 position0      = vec3(uv / ResolutionScale, sceneDepth.x);
        position0       = screenToViewSpace(position0);
#ifdef DISTANT_HORIZONS
        if (!isTerrain.x) position0 = screenToViewSpace(vec3(uv / ResolutionScale, dhDepth.x), dhProjectionInverse);
#endif

    vec3 position1      = vec3(uv / ResolutionScale, sceneDepth.y);
        position1       = screenToViewSpace(position1);
#ifdef DISTANT_HORIZONS
    #ifdef waterDistantTerrainGuardEnabled
        // V24.23: only guard *near vanilla water*.  The previous test used `water` alone,
        // which also matched DH water pixels.  That prevented distant water from using its
        // own DH back-depth and made the water-fog thickness jump to the vanilla far plane,
        // exposing the Distant Horizons LOD tiles as large gray/blocky shapes.
        //
        // Vanilla water keeps the cave/x-ray protection; DH water gets its proper paired
        // front/back depth so its absorption matches the nearby water instead of outlining
        // the LOD transition.
        // V15AI: extend the DH cave/x-ray guard to water that is hidden behind
        // a translucent front layer.  V24.23 only protected directly visible water
        // (`water && isTerrain.x`).  Once stained glass became the front material,
        // that test became false and the shader was free to substitute dhDepthTex1
        // as the opaque back surface.  With DH cave culling disabled, dhDepthTex1
        // can legitimately contain underground cave LOD geometry, so those cave
        // silhouettes leaked through the stained glass before refraction validation.
        bool protectedWaterColumn = (water && isTerrain.x) || waterBehindTranslucent;
        if (!isTerrain.y && !protectedWaterColumn)
            position1 = screenToViewSpace(vec3(uv / ResolutionScale, dhDepth.y), dhProjectionInverse);
    #else
        if (!isTerrain.y) position1 = screenToViewSpace(vec3(uv / ResolutionScale, dhDepth.y), dhProjectionInverse);
    #endif
#endif

    float hiddenWaterDist = waterBehindTranslucent ? hiddenWaterDecodeDistance(hiddenWaterCode) : 0.0;
    vec3 hiddenWaterPos = position0;
    if (waterBehindTranslucent && hiddenWaterDist > 0.0) hiddenWaterPos = normalize(position0) * hiddenWaterDist;

    // V15AB: keep the recovered hidden-water normal available after refraction.
    // The water surface will get a small world-space environment reflection *inside* the
    // transmitted scene, before the front glass is composited.  This restores visible wave
    // motion through tinted panes without allowing hidden water to take ownership of the
    // screen-space/PT reflection buffer again (the source of the boxed/sliding artifact).
    vec3 hiddenWaterSurfaceNormal = vec3(0.0, 1.0, 0.0);

    mat2x3 scenePos     = mat2x3(viewToSceneSpace(position0), viewToSceneSpace(position1));

    vec3 worldDir       = mat3(gbufferModelViewInverse) * normalize(position0);
    vec3 worldDir1       = worldDir;

    if ((water || waterBehindTranslucent) && !isDH.x && sceneDepth.y < 0.999999){
        vec3 waterSurfacePos = waterBehindTranslucent ? hiddenWaterPos : position0;
        vec3 sceneNormal;
        vec3 flatNormal;
        if (waterBehindTranslucent) {
            vec3 hiddenScenePos = viewToSceneSpace(waterSurfacePos);
            sceneNormal = hiddenWaterNormal(hiddenScenePos + cameraPosition, hiddenWaterDist);
            hiddenWaterSurfaceNormal = sceneNormal;
            flatNormal = vec3(0.0, 1.0, 0.0);
        } else {
            sceneNormal = decodeNormal(GBuffer0.xy);
            flatNormal = clampDIR(normalize(cross(dFdx(scenePos[0]), dFdy(scenePos[0]))));
        }
        vec3 viewNormal     = mat3(gbufferModelView) * sceneNormal;
        vec3 flatViewNormal = normalize(mat3(gbufferModelView) * flatNormal);

        vec3 normalCorrected = dot(viewNormal, normalize(position1)) > 0.0 ? -viewNormal : viewNormal;

        vec3 refractedDir   = clampDIR(refract2(normalize(position1), normalCorrected, flatViewNormal, rcp(1.33)));
        float refractedDist = distance(waterSurfacePos, position1);
        vec3 refractedPos   = position1 + refractedDir * refractedDist;
        vec3 screenPos      = viewToScreenSpace(refractedPos);

        vec2 baseScreen = uv / ResolutionScale;
        vec2 refractionDelta = screenPos.xy - baseScreen;

        #ifdef waterRefractionXrayGuardEnabled
        // Keep the creator's normal-driven refraction, but constrain it to the small, depth-aware
        // screen-space offsets that are safe around shorelines, caves and translucent/DH boundaries.
        float maxRefractionOffset = (0.0045 + 0.0035 * saturate(refractedDist * 0.5)) * min(gbufferProjection[1][1], 2.0);
        maxRefractionOffset /= max(1.0, length(position0) * 0.015);

        float deltaLength = length(refractionDelta);
        if (deltaLength > maxRefractionOffset)
            refractionDelta *= maxRefractionOffset / max(deltaLength, 1e-6);

        // Thin water receives little refraction. This avoids dragging shoreline/cave pixels into
        // the water when the opaque layer is only a fraction of a block behind the surface.
        float sourceGap = waterBehindTranslucent ? max0(distance(waterSurfacePos, position1)) : max0((depthLinear(sceneDepth.y) - depthLinear(sceneDepth.x)) * far);
        refractionDelta *= saturate(sourceGap);
        #endif

        screenPos.xy = baseScreen + refractionDelta;

        float distToEdge = maxOf(abs(screenPos.xy * 2.0 - 1.0));
        distToEdge = sqr(sstep(distToEdge, 0.7, 1.0));
        screenPos.xy = mix(screenPos.xy, baseScreen, distToEdge);

        vec2 refrUV = screenPos.xy * ResolutionScale;
        float refractedFrontDepth = texture(depthtex0, refrUV).x;
        float refractedBackDepth  = texture(depthtex1, refrUV).x;
        bool validRefraction = refractedBackDepth > refractedFrontDepth && refractedBackDepth < 0.999999;

        #ifdef waterRefractionXrayGuardEnabled
        vec4 refrGBuffer1 = texture(colortex2, refrUV);
        int refrMatID = int(unpack2x8(refrGBuffer1.y).x * 255.0);

        // V15AH: hidden-water refraction must be validated in the HIDDEN WATER depth domain,
        // not against the front glass depth.  The old path used:
        //   depthtex1 - depthtex0
        // which measures glass -> opaque terrain when water is behind glass, then bypassed the
        // material test entirely with `waterBehindTranslucent || ...`.  A displaced ripple could
        // therefore cross a shoreline/cave opening, sample unrelated underground geometry, and
        // still be accepted as water.  Besides the x-ray outlines this also poisoned water-fog
        // thickness and made the stained-glass water lose its real surface structure.
        float candidateGap;
        float candidateSurfaceDepth;
        bool candidateHiddenWater = false;
        float candidateHiddenDist = 0.0;

        if (waterBehindTranslucent) {
            float candidateHiddenCode = fract(max(texture(colortex15, refrUV).a, 0.0));
            candidateHiddenWater = candidateHiddenCode > (0.5 / 65535.0);
            candidateHiddenDist = candidateHiddenWater ? hiddenWaterDecodeDistance(candidateHiddenCode) : 0.0;

            vec3 candidateFrontPos = screenToViewSpace(vec3(screenPos.xy, refractedFrontDepth));
            vec3 candidateBackPos  = screenToViewSpace(vec3(screenPos.xy, refractedBackDepth));
            vec3 candidateWaterPos = normalize(candidateFrontPos) * candidateHiddenDist;

            candidateGap = candidateHiddenWater ? max0(distance(candidateWaterPos, candidateBackPos)) : 0.0;
            candidateSurfaceDepth = candidateHiddenDist;

            // Refraction offsets are tiny, so the same physical water surface should remain close
            // in radial distance.  Reject jumps onto another layer/body even if both pixels happen
            // to contain some water somewhere in their translucent stack.
            float hiddenSurfaceTolerance = max(1.5, hiddenWaterDist * 0.08);
            validRefraction = validRefraction && candidateHiddenWater;
            validRefraction = validRefraction && abs(candidateHiddenDist - hiddenWaterDist) <= hiddenSurfaceTolerance;

            // A neighboring sample should not suddenly become a vastly deeper column.  This is a
            // conservative discontinuity guard for cave mouths/shore edges, not a depth clamp.
            float maxLocalWaterGap = max(8.0, sourceGap * 3.0 + 2.0);
            validRefraction = validRefraction && candidateGap <= maxLocalWaterGap;
        } else {
            candidateGap = max0((depthLinear(refractedBackDepth) - depthLinear(refractedFrontDepth)) * far);
            candidateSurfaceDepth = depthLinear(refractedFrontDepth) * far;
            float currentSurfaceDepth = depthLinear(sceneDepth.x) * far;
            float surfaceTolerance = max(1.5, sourceGap * 0.75 + 0.5);

            validRefraction = validRefraction && refrMatID == 102;
            validRefraction = validRefraction && abs(candidateSurfaceDepth - currentSurfaceDepth) <= surfaceTolerance;
        }

        validRefraction = validRefraction && candidateGap > 0.02;

        // Complementary-style second depth check: fade the displacement back toward the original
        // pixel if the displaced water column is shallow, then validate the FINAL coordinate again.
        // Hidden water repeats its marker/distance test here; the old code dropped that validation
        // on the second sample, which could re-introduce the exact cave edge we rejected above.
        if (validRefraction) {
            refractionDelta *= saturate(candidateGap);
            screenPos.xy = baseScreen + refractionDelta;
            refrUV = screenPos.xy * ResolutionScale;

            refrGBuffer1 = texture(colortex2, refrUV);
            refrMatID = int(unpack2x8(refrGBuffer1.y).x * 255.0);
            refractedFrontDepth = texture(depthtex0, refrUV).x;
            refractedBackDepth  = texture(depthtex1, refrUV).x;

            validRefraction = refractedBackDepth > refractedFrontDepth &&
                              refractedBackDepth < 0.999999;

            if (waterBehindTranslucent) {
                float candidateHiddenCode2 = fract(max(texture(colortex15, refrUV).a, 0.0));
                bool candidateHiddenWater2 = candidateHiddenCode2 > (0.5 / 65535.0);
                float candidateHiddenDist2 = candidateHiddenWater2 ? hiddenWaterDecodeDistance(candidateHiddenCode2) : 0.0;

                vec3 candidateFrontPos2 = screenToViewSpace(vec3(screenPos.xy, refractedFrontDepth));
                vec3 candidateBackPos2  = screenToViewSpace(vec3(screenPos.xy, refractedBackDepth));
                vec3 candidateWaterPos2 = normalize(candidateFrontPos2) * candidateHiddenDist2;
                candidateGap = candidateHiddenWater2 ? max0(distance(candidateWaterPos2, candidateBackPos2)) : 0.0;

                float hiddenSurfaceTolerance2 = max(1.5, hiddenWaterDist * 0.08);
                float maxLocalWaterGap2 = max(8.0, sourceGap * 3.0 + 2.0);
                validRefraction = validRefraction && candidateHiddenWater2 &&
                                  abs(candidateHiddenDist2 - hiddenWaterDist) <= hiddenSurfaceTolerance2 &&
                                  candidateGap > 0.02 && candidateGap <= maxLocalWaterGap2;
            } else {
                candidateGap = max0((depthLinear(refractedBackDepth) - depthLinear(refractedFrontDepth)) * far);
                validRefraction = validRefraction && refrMatID == 102 && candidateGap > 0.02;
            }
        }
        #endif

        if (validRefraction) {
            sceneDepth.y = refractedBackDepth;
            position1   = screenToViewSpace(vec3(screenPos.xy, sceneDepth.y));
            scenePos[1] = viewToSceneSpace(position1);

            sceneColor.rgb = texture(colortex0, refrUV).rgb;
            worldDir1 = clampDIR(normalize(scenePos[1]));
        }
    }

    vec3 skyColor       = texture(RSkybox, projectSky(worldDir, 0)).rgb;

//TODO: DH handling on terrain masks
    #ifdef cloudVolumeEnabled
        float cloudDistance = far * 2.0;
        vec4 cloudData  = RSKY_VanillaClouds(worldDir, scenePos[0], ditherBluenoise(), (isTerrain.y || isDH.y), skyColor, cloudDistance);

        bool Clouds_PreFog = (!(isTerrain.x || isDH.x) && eyeAltitude < RSKY_Volume0_Limits.x) || (length(scenePos[0]) <= cloudDistance);

        if (Clouds_PreFog) {
            sceneColor  = sceneColor * cloudData.a + cloudData.rgb;
        }
    #endif

    mat2x3 reflectionAux = unpackReflectionAux(texture(colortex3, uv));

    vec3 translucencyAbsorption = reflectionAux[1];

    float vDotL     = dot(normalize(position1), lightDirView);

    float caveMult  = linStep(eyeBrightnessSmooth.y/240.0, 0.1, 0.9);
    vec3 fogScatterColor = RColorTable.DirectLight * mieHG(vDotL, 0.68) * sqrt(caveMult);
        fogScatterColor *= mix(0.33, 0.66, sqrt(abs(lightDir.y)));
        fogScatterColor += RColorTable.Skylight * rpi * caveMult;
    
    if ((water || waterBehindTranslucent) && isEyeInWater == 0) {
        #ifdef waterFogEnabled
        // For glass-over-water, use the same visible segment to the opaque back layer. This preserves
        // water attenuation instead of falling through to the ordinary-air fog branch (X-ray water).
        vec3 waterFogStart = waterBehindTranslucent ? hiddenWaterPos : position0;
        sceneColor = getWaterFog(sceneColor, max0(distance(waterFogStart, position1)), RColorTable.Skylight * caveMult);
        if (water) translucencyAbsorption = vec3(1);
        #endif
    } else if (landMask(sceneDepth.y)) {
        #ifdef fogEnabled
        // V15AK: stained glass must not split ordinary air fog at the pane depth.
        // Clear glass usually leaves the scene behind it as the effective front surface,
        // while stained glass writes a full translucent depth layer. Applying glass->back
        // fog here and camera->glass fog later makes the pane itself part of the atmosphere
        // resolve and then the pane blend can erase the far-field gradient. For stained
        // glass, composite3 resolves camera->effective-behind depth in one continuous pass.
        if (!stainedGlass)
            sceneColor = getFog(sceneColor, distance(position0, position1), skyColor, worldDir1);
        #endif
    }

    // V15AP: use the exact native water surface captured before glass blending.
    // This avoids deblending colortex5, whose accumulated background/translucency
    // can carry shoreline/cave structure into the reconstructed water layer.
    // Reflections are applied later by NostalgiaVX's native PT reflection pipeline.
    if (waterBehindTranslucent) {
        float nativeWaterAlpha = clamp(waterAlpha, 0.0, 1.0);
        sceneColor = sceneColor * (1.0 - nativeWaterAlpha) + hiddenWaterNativeColor * nativeWaterAlpha;
    }

    if (translucent) {
        if (stainedGlass) {
            // V15AK TRUE CLEAR-PATH STAINED GLASS:
            // Do NOT composite the stained fragment into sceneColor here. The stained pane
            // has already written a near depth, but clear glass usually leaves the water/terrain
            // behind it as the effective front surface across the transparent part of the pane.
            // Feeding the stained RGB/alpha stack here is what flattened water ripples and
            // destroyed distant fog even after later luminance-recovery attempts.
            //
            // Keep the reconstructed scene behind the pane untouched (including hidden-water
            // refraction, water fog and world-space ripple reflection). The front pane still
            // owns G-buffer normal/material data, so its reflection/specular surface survives
            // in composite3. The native stained hue is applied only AFTER all atmosphere/fog
            // stages there, with luminance preserved.
        } else {
            // Native NostalgiaVX path for clear glass, ice and directly visible water.
            sceneColor = sceneColor * saturate(translucencyAbsorption) * (1.0 - translucencyColor.a) + translucencyColor.rgb;
        }
    }

    fogScattering   = vec4(0.0);
    fogTransmittance = vec3(1.0);

    #ifdef fogVolumeEnabled
        {
            // V15AK: atmosphere depth parity with clear glass. Stained glass is a visible
            // optical surface, but it must not truncate the atmospheric integration at the pane.
            // Use hidden water as the endpoint when present; otherwise use the opaque/DH scene
            // behind the pane. Reflections still use the actual front glass position elsewhere.
            vec3 atmospherePosition = position0;
            vec3 atmosphereScenePos = scenePos[0];
            bool atmosphereIsSky = !(isTerrain.x || isDH.x);

            if (stainedGlass) {
                if (waterBehindTranslucent && hiddenWaterDist > 0.0) {
                    atmospherePosition = hiddenWaterPos;
                    atmosphereScenePos = viewToSceneSpace(hiddenWaterPos);
                    atmosphereIsSky = false;
                } else {
                    atmospherePosition = position1;
                    atmosphereScenePos = scenePos[1];
                    atmosphereIsSky = !(isTerrain.y || isDH.y);
                }
            }

            float atmosphereVDotL = dot(normalize(atmospherePosition), lightDirView);
            mat2x3 fogData  = mat2x3(vec3(0.0), vec3(1.0));

            if (isEyeInWater == 0) {
                fogData = volumetricFog(atmosphereScenePos, worldDir, atmosphereIsSky, atmosphereVDotL, ditherBluenoise(), caveMult, skyColor);
            }
            #ifdef underwaterLightShaftsEnabled
            else if (isEyeInWater == 1) {
                float shaftDistance = atmosphereIsSky ? underwaterShaftDistance : length(atmosphereScenePos);
                fogData[0] = getUnderwaterLightShafts(worldDir, shaftDistance, ditherBluenoiseStaticF3().x, caveMult);
                fogData[1] = vec3(1.0);
            }
            #endif

            fogScattering.rgb = fogData[0];
            fogScattering.a = saturate(max0(-atmospherePosition.z) / max(far, 1e-4));
            fogTransmittance = fogData[1];
        }

        fogScattering       = clamp16F(fogScattering);
    #endif  
    
    cloudPostFog = vec4(0,0,0,1);

    #ifdef cloudVolumeEnabled
    if (!Clouds_PreFog) {
        //sceneColor  = sceneColor * cloudData.a + cloudData.rgb;
        cloudPostFog = cloudData;
    }
    #endif

    //sceneColor.rgb = stex(colortex10).rgb;
}