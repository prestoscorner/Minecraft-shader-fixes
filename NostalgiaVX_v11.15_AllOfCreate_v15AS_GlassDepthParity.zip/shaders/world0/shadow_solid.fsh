#version 430 compatibility

#define gSOLID

#include "/program/shadow/fragment.fsh"