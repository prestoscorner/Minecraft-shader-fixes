#version 430

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

layout (local_size_x = 8) in;
const ivec3 workGroups = ivec3(1, 1, 1);

#define RSSBO_ENABLE_COLOR
#include "/lib/head.glsl"
#include "/lib/util/colorspace.glsl"

uniform int worldTime;
uniform float cloudLightFlip, lightFlip, sunAngle, wetness;

uniform vec3 fogColor, skyColor;
uniform vec4 daytime;

vec3 RDaytimeColor(vec3 rise, vec3 noon, vec3 set, vec3 night) {
    return rise * daytime.x + noon * daytime.y + set * daytime.z + night * daytime.w;
}
vec3 RDaytimeColor_SquaredBlend(vec3 rise, vec3 noon, vec3 set, vec3 night) {
    return rise * sqr(daytime.x) + noon * (1-sqr(1-daytime.y)) + set * sqr(daytime.z) + night * (1-sqr(1-daytime.w));
}

vec3 blackbody(float temperature){
    vec4 vx = vec4(-0.2661239e9, -0.2343580e6, 0.8776956e3, 0.179910);
    vec4 vy = vec4(-1.1063814, -1.34811020, 2.18555832, -0.20219683);
    float it = rcp(temperature);
    float it2= sqr(it);
    float x = dot(vx, vec4(it * it2, it2, it, 1.0));
    float x2 = sqr(x);
    float y = dot(vy,vec4(x * x2, x2, x, 1.0));
    float z = 1.0 - x - y;
    
    vec3 AP1 = vec3(x * rcp(y), 1.0, z * rcp(y)) * CT_XYZ_AP1;
    return max(AP1, 0.0);
}

vec3 RColor_GetSunlight() {
    vec3 RColor = RDaytimeColor(
                    vec3(0.79, 0.306, 0.03) * 0.70,
                    vec3(1.00, 0.93, 0.72) * 1.00,
                    vec3(0.79, 0.29, 0.04) * 0.70,
                    vec3(0.69, 0.27, 0.04) * 0.10
                    ) * 16.0;

    RColor *= sunlightIllum * vec3(sunlightRedMult, sunlightGreenMult, sunlightBlueMult);
    RColor = colorSaturation(RColor, 1.0 - wetness * 0.75) * (1.0 - wetness * 0.75);

    return RColor;
}
vec3 RColor_GetMoonlight() {
    vec3 RColor = vec3(0.22, 0.33, 1.0) * 0.17;

    RColor *= moonlightIllum * vec3(moonlightRedMult, moonlightGreenMult, moonlightBlueMult);
    RColor = colorSaturation(RColor, 1.0 - wetness * 0.25);

    return RColor;
}

void main() {
    uint Index = uint(gl_GlobalInvocationID.x);

    switch (Index) {
        case 0:
            RColorTable.Sunlight = RColor_GetSunlight();

        case 1:
            RColorTable.Moonlight = RColor_GetMoonlight();

        case 2:
            RColorTable.Skylight = RDaytimeColor(
                vec3(0.81, 0.80, 0.97) * 0.30,
                vec3(0.75, 0.84, 0.98) * 0.50,
                vec3(0.81, 0.80, 0.97) * 0.31,
                vec3(0.33, 0.49, 0.94) * 0.01
                ) * 1.0;

            RColorTable.Skylight *= skylightIllum * vec3(skylightRedMult, skylightGreenMult, skylightBlueMult);

        case 3:
            RColorTable.Blocklight = blackbody(float(blocklightBaseTemp)) * blocklightIllum * blocklightBaseMult * 1.5;

        case 4:
            if ((worldTime>23000 || worldTime<12900)) {
                RColorTable.CloudDirectLight = RDaytimeColor_SquaredBlend(
                    vec3(0.67, 0.20, 0.05) * 0.45,
                    vec3(0.95, 0.90, 0.76) * 0.90,
                    vec3(0.65, 0.18, 0.04) * 0.45,
                    vec3(0.65, 0.14, 0.03) * 0.25
                    ) * 16.0;

                RColorTable.CloudDirectLight *= sunlightIllum * vec3(sunlightRedMult, sunlightGreenMult, sunlightBlueMult);
                RColorTable.CloudDirectLight = colorSaturation(RColorTable.CloudDirectLight, 1.0 - wetness * 0.65) * (1.0 - wetness * 0.5);
            } else {
                RColorTable.CloudDirectLight = vec3(0.22, 0.33, 1.0) * 0.17;

                RColorTable.CloudDirectLight *= moonlightIllum * vec3(moonlightRedMult, moonlightGreenMult, moonlightBlueMult);
                RColorTable.CloudDirectLight = colorSaturation(RColorTable.CloudDirectLight, 1.0 - wetness * 0.25);
            }
            RColorTable.CloudDirectLight *= cloudLightFlip;

        case 5:
            vec3 linearSky  = srgbToPipelineColor(skyColor) * sqrt2;

            RColorTable.CloudSkylight = RDaytimeColor(
                linearSky * 0.70,
                linearSky * vec3(0.97, 1.18, 1.04) * 1.05,
                linearSky * 0.9,
                vec3(0.22, 0.44, 1.00) * 0.006
                ) * 1.0;

            RColorTable.CloudSkylight *= skylightIllum * vec3(skylightRedMult, skylightGreenMult, skylightBlueMult);
            RColorTable.CloudSkylight = colorSaturation(RColorTable.CloudSkylight, 1.0 - wetness * 0.9) * (1.0 + wetness * 1.75);

        case 6:
            RColorTable.DirectLight = sunAngle < 0.5 ? RColor_GetSunlight() : RColor_GetMoonlight();
            RColorTable.DirectLight *= lightFlip;
    }
            
}