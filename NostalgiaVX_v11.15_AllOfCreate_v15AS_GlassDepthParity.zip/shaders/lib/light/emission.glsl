/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/


#define LIGHTLUM_BRIGHT 10      //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LIGHTLUM_MEDIUM 5       //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LIGHTLUM_DIM 2          //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LIGHTLUM_VDIM 1         //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LIGHTLUM_LAB 5          //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]

#define LIGHTLUM_TORCH 4      //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LTorch_Red 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LTorch_Green 0.55       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LTorch_Blue 0.20       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define LIGHTLUM_REDTORCH 1    //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LRedtorch_Red 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LRedtorch_Green 0.30       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LRedtorch_Blue 0.10       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define LIGHTLUM_SOULLIGHT 2   //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LSoul_Red 0.25       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LSoul_Green 0.45       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LSoul_Blue 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define LIGHTLUM_COPPER 4      //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LCopper_Red 0.40       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LCopper_Green 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LCopper_Blue 0.50       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define LIGHTLUM_FIRE 6        //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LFire_Red 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LFire_Green 0.45       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LFire_Blue 0.10       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define LIGHTLUM_LAVA 5        //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LLava_Red 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LLava_Green 0.40       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LLava_Blue 0.05       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define LIGHTLUM_ENDROD 5      //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LEndrod_Red 0.75       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LEndrod_Green 0.35       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LEndrod_Blue 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define LIGHTLUM_AMETHYST 2    //[0 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20]
#define LAmethyst_Red 0.55       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LAmethyst_Green 0.25       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define LAmethyst_Blue 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

const vec3 LIGHT_TORCH = vec3(LTorch_Red, LTorch_Green, LTorch_Blue) * LIGHTLUM_TORCH;
const vec3 LIGHT_REDTORCH = vec3(LRedtorch_Red, LRedtorch_Green, LRedtorch_Blue) * LIGHTLUM_REDTORCH;
const vec3 LIGHT_SOUL = vec3(LSoul_Red, LSoul_Green, LSoul_Blue) * LIGHTLUM_SOULLIGHT;
const vec3 LIGHT_FIRE = vec3(LFire_Red, LFire_Green, LFire_Blue) * LIGHTLUM_FIRE;
const vec3 LIGHT_LAVA = vec3(LLava_Red, LLava_Green, LLava_Blue) * LIGHTLUM_LAVA;
const vec3 LIGHT_ENDROD = vec3(LEndrod_Red, LEndrod_Green, LEndrod_Blue) * LIGHTLUM_ENDROD;
const vec3 LIGHT_AMETHYST = vec3(LAmethyst_Red, LAmethyst_Green, LAmethyst_Blue) * LIGHTLUM_AMETHYST;
const vec3 LIGHT_COPPER = vec3(LCopper_Red, LCopper_Green, LCopper_Blue) * LIGHTLUM_COPPER;

// Dedicated sea-lantern spectrum. Keep it bright like the original generic ID,
// but explicitly cyan/blue so it cannot be mistaken for 2600 K lantern light.
const vec3 LIGHT_SEALANTERN = vec3(0.30, 0.65, 1.00) * LIGHTLUM_BRIGHT;

#define LIGHT_SCULK vec3(0.45, 1.0, 0.75)

vec3 getEmissionVoxel(int ID, vec3 albedo, float textureEmission) {
    albedo  = max(albedo, 1e-8);
    vec3 albedoIn   = albedo;

    #if labEmissionMode != 2
        /*
        float lum   = getLuma(albedo);

        float albedoLum = mix(avgOf(albedo), maxOf(albedo), 0.71);
            albedoLum   = saturate(albedoLum * sqrt2);

        float emitterLum = saturate(mix(sqr(albedoLum), sqrt(maxOf(albedo)), albedoLum) * sqrt2);

        #if labEmissionMode == 1
            emitterLum  = max(emitterLum, textureEmission);
        #endif

        albedo  = albedo;*/
    #else
        albedo   *= textureEmission;
    #endif

    switch (ID) {
        case 1: return albedo * LIGHTLUM_BRIGHT;
        case 2: return albedo * LIGHTLUM_MEDIUM;
        case 3: return albedo * LIGHTLUM_DIM;
        case 4: return albedo * LIGHTLUM_VDIM;
        case 5: return albedo * LIGHTLUM_VDIM * 0.5;
        case 10: return LIGHT_TORCH;
        case 11: return LIGHT_REDTORCH;
        case 12: return LIGHT_SOUL;
        case 13: return LIGHT_FIRE;
        case 14: return LIGHT_LAVA;
        case 15: return LIGHT_COPPER;
        case 20: return LIGHT_ENDROD;
        case 21: return LIGHT_AMETHYST;
        case 22: return LIGHT_AMETHYST * 0.5;
        case 23: return LIGHT_SCULK * 1;
        case 24: return LIGHT_SEALANTERN;
    }

    #if labEmissionMode == 0
        return vec3(0);
    #elif labEmissionMode == 1
        return albedoIn * textureEmission * LIGHTLUM_LAB;
    #elif labEmissionMode == 2
        return albedo * LIGHTLUM_LAB;
    #endif
}

vec3 getEmissionScreenSpace(int ID, vec3 albedo, float textureEmission, inout float luma) {
    albedo  = max(albedo, 1e-8);
    vec3 albedoIn   = albedo;

    #if labEmissionMode != 2
        float lum   = getLuma(albedo);

        float albedoLum = mix(avgOf(albedo), maxOf(albedo), 0.71);
            albedoLum   = saturate(albedoLum * sqrt2);

        float emitterLum = saturate(mix(sqr(albedoLum), sqrt(maxOf(albedo)), albedoLum) * sqrt2);

        #if labEmissionMode == 1
            emitterLum  = max(emitterLum, textureEmission);
        #endif

        albedo  = mix(sqr(normalize(albedo)), normalize(albedo), sqrt(emitterLum)) * emitterLum;
    #else
        albedo   *= textureEmission;
        float emitterLum = textureEmission;
    #endif

        luma     = emitterLum;

    switch (ID) {
        case 1: return albedo * LIGHTLUM_BRIGHT;
        case 2: return albedo * LIGHTLUM_MEDIUM;
        case 3: return albedo * LIGHTLUM_DIM;
        case 4: return albedo * LIGHTLUM_VDIM;
        case 5: return albedo * LIGHTLUM_VDIM * 0.5;
        case 10: return LIGHT_TORCH * emitterLum;
        case 11: return LIGHT_REDTORCH * emitterLum;
        case 12: return LIGHT_SOUL * emitterLum;
        case 13: return LIGHT_FIRE * emitterLum;
        case 14: return LIGHT_LAVA * emitterLum;
        case 15: return LIGHT_COPPER * emitterLum;
        case 20: return LIGHT_ENDROD * emitterLum;
        case 21: return LIGHT_AMETHYST * emitterLum;
        case 22: return LIGHT_AMETHYST * emitterLum * 0.5;
        case 23: return LIGHT_SCULK * emitterLum;
        case 24: return LIGHT_SEALANTERN * emitterLum;
    }

    #if labEmissionMode == 0
        return vec3(0);
    #elif labEmissionMode == 1
        return albedoIn * textureEmission * LIGHTLUM_LAB;
    #elif labEmissionMode == 2
        return albedo * LIGHTLUM_LAB;
    #endif
}

vec3 GetEmission_Handheld(int ID, float VanillaEmission, inout bool AnyEmitter) {
    AnyEmitter = ID > 0 || VanillaEmission > 0.01;

    const vec3 GenericEmissionColor = vec3(0.85, 0.8, 0.76);
    const vec3 GenericWarmColor = vec3(1.0, 0.5, 0.1);
    const vec3 GenericColdColor = vec3(0.35, 0.5, 1.0);

    switch (ID) {
        case 1: return GenericWarmColor * LIGHTLUM_BRIGHT;
        case 2: return GenericWarmColor * LIGHTLUM_MEDIUM;
        case 3: return GenericWarmColor * LIGHTLUM_DIM;
        case 4: return GenericEmissionColor * LIGHTLUM_BRIGHT;
        case 5: return GenericEmissionColor * LIGHTLUM_MEDIUM;
        case 6: return GenericEmissionColor * LIGHTLUM_DIM;
        case 7: return LIGHT_SEALANTERN;
        case 8: return GenericColdColor * LIGHTLUM_MEDIUM;
        case 9: return GenericColdColor * LIGHTLUM_DIM;
        case 10: return vec3(0.6, 0.1, 1.0) * LIGHTLUM_MEDIUM;
        case 11: return LIGHT_REDTORCH;
        case 12: return LIGHT_TORCH;
        case 13: return LIGHT_SOUL;
        case 14: return LIGHT_ENDROD;
        case 15: return LIGHT_FIRE;
        case 16: return LIGHT_COPPER;
    }

    return GenericEmissionColor * VanillaEmission * LIGHTLUM_MEDIUM;
}