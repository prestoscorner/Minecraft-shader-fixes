/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/


#include "/lib/light/sh.glsl"

ivec2 clampTexelPosLR(ivec2 pos) {
    return clamp(pos, ivec2(0.0), ivec2(viewSize * 0.5 - 1));
}

SphericalHarmonics ReadLightSH(sampler2D InImage, ivec2 Position) {
    SphericalHarmonics OutSH = InitSH();
    OutSH.Y = texelFetch(InImage, Position, 0);
    OutSH.CoCg = texelFetch(InImage, Position + ivec2((viewSize.x * 0.5), 0.0), 0).xy;

    return OutSH;
}
vec3 ReadLight(sampler2D InImage, ivec2 Position) {
    return texelFetch(InImage, Position, 0).rgb;
}
float ReadLightLuma(sampler2D InImage, ivec2 Position) {
    return texelFetch(InImage, Position, 0).w / 0.282095;
}

vec4 ReadLightAux(sampler2D InImage, ivec2 Position) {
    return texelFetch(InImage, Position + ivec2(0.0, viewSize.y * 0.5), 0);
}

/* ------ ATROUS ------ */

#include "/lib/offset/gauss.glsl"

#define atrousDepthTreshold 0.001
#define atrousDepthOffset 0.25
#define atrousDepthExp 2.0

#define atrousNormalExponent 16

/*
luma exp: big = sharper     now smol = sharp
luma offset: big = moar min blur
*/

#define atrousLumaExp 4.0
#define atrousLumaOffset 8.0

ivec2 clampTexelPos(ivec2 pos) {
    return clamp(pos, ivec2(0.0), ivec2(viewSize));
}

vec2 computeVariance(sampler2D tex, ivec2 pos) {
    float sumMsqr   = 0.0;
    float sumMean   = 0.0;

    for (int i = 0; i<9; i++) {
        ivec2 deltaPos     = kernelO_3x3[i];

        vec3 col    = texelFetch(tex, clampTexelPos(pos + deltaPos), 0).rgb;
        float lum   = getLuma(col);

        sumMsqr    += sqr(lum);
        sumMean    += lum;
    }
    sumMsqr  /= 9.0;
    sumMean  /= 9.0;

    return vec2(abs(sumMsqr - sqr(sumMean)) * rcp(max(sumMean, 1e-20)), sumMean);
}

const float gaussKernel[2][2] = {
	{ 1.0 / 4.0, 1.0 / 8.0  },
	{ 1.0 / 8.0, 1.0 / 16.0 }
};

float computeSigmaL(ivec2 pixelUV, float center) {
	float sum = center * gaussKernel[0][0];

    const int r = 1;
	for(int y = -r; y <= r; y++) {
		for(int x = -r; x <= r; x++) {
			if(x != 0 || y != 0) {
				ivec2 UV    = clampTexelPos(pixelUV + ivec2(x, y));
				float variance = ReadLightAux(colortex5, UV).x;
				float w     = gaussKernel[abs(x)][abs(y)];
				sum        += variance * w;
			}
		}
	}

	return sqrt(max(sum, 1e-8));
}

vec3 atrousSVGF(sampler2D tex, sampler2D gData, vec2 uv, vec3 sceneNormal, float centerDepth, out float SSAO) {
    ivec2 pos           = ivec2(uv * viewSize * (0.5 / ResolutionScale));
    
    vec4 centerData     = vec4(sceneNormal, sqrt(depthLinear(centerDepth)) * far);

    vec4 centerColor    = texelFetch(tex, clampTexelPosLR(pos), 0);
    float centerLuma    = getLuma(centerColor.rgb);
    vec2 CenterAux = ReadLightAux(tex, clampTexelPosLR(pos)).xy;

    //return centerColor.rgb;

    vec2 variance       = computeVariance(tex, pos);

    //float sigmaL        = rcp(1.0 + atrousLumaExp * variance.x);
    float sigmaL = 1.0 / (0.012 * computeSigmaL(pos, centerData.x) + 0.05);
    float maxLumDelta   = pi;

    float totalWeight   = 1e-2;
    vec4 total          = centerColor * totalWeight;
    SSAO = CenterAux.y * totalWeight;

    for (int i = 0; i<9; i++) {
        ivec2 deltaPos      = kernelO_3x3[i];
        //if (deltaPos.x == 0 && deltaPos.y == 0) continue;

        ivec2 samplePos     = pos + deltaPos;

        bool valid          = all(greaterThanEqual(samplePos, ivec2(0))) && all(lessThan(samplePos, ivec2(viewSize * 0.5)));

        if (!valid) continue;

        vec2 viewportPos = vec2(samplePos) / (0.5 / ResolutionScale);

        vec4 currentData    = texelFetch(gData, clampTexelPosLR(samplePos), 0);
            currentData.xyz = currentData.xyz * 2.0 - 1.0;
            currentData.w   = (currentData.w) * far;

        float depthDelta    = abs(currentData.w - centerData.w) * atrousDepthExp;

        float weight        = pow(max(0.0, dot(currentData.xyz, centerData.xyz)), atrousNormalExponent);

        //if (weight < 1e-20) continue;

        vec4 currentColor   = texelFetch(tex, clampTexelPosLR(samplePos), 0);
        float currentLuma   = getLuma(currentColor.rgb);

        float lumaDelta     = abs(centerLuma - currentLuma) / clamp(variance.y, 1e-2, 2e4);

            weight         *= exp(-depthDelta - sqrt(sigmaL * lumaDelta));
            weight         *= exp(-distance(uv * viewSize, viewportPos));

        //accumulate stuff
        total       += currentColor * weight;
        totalWeight += weight;
        SSAO += ReadLightAux(tex, clampTexelPosLR(samplePos)).y * weight;
    }

    //compensate for total sampling weight
    total /= max(totalWeight, 1e-25);
    SSAO /= max(totalWeight, 1e-25);

    return total.rgb;
}

#if 0
SphericalHarmonics atrousSVGF(sampler2D tex, sampler2D gData, vec2 uv, vec3 sceneNormal, float centerDepth, out float SSAO) {
    ivec2 pos           = ivec2(uv * viewSize * (0.5 / ResolutionScale));

    vec4 centerData     = vec4(sceneNormal, sqrt(depthLinear(centerDepth)) * far);

    SphericalHarmonics centerColor = ReadLightSH(tex, pos);
    float CenterAux = ReadLightAux(tex, pos).y;

    //vec4 centerColor    = texelFetch(tex, pos, 0);
    float centerLuma    = IrradianceLuma(centerColor);

    //return centerColor;

    vec2 variance       = computeVariance(tex, pos);

    float sigmaL        = rcp(1.0 + atrousLumaExp * variance.x);
    float maxLumDelta   = pi;


    float totalWeight   = 1e-2;
    SphericalHarmonics totalColor = centerColor;
        scaleSH(totalColor, totalWeight);

    SSAO = CenterAux * totalWeight;

    for (int i = 0; i<9; i++) {
        ivec2 deltaPos      = kernelO_3x3[i];
        //if (deltaPos.x == 0 && deltaPos.y == 0) continue;

        ivec2 samplePos     = pos + deltaPos;

        bool valid          = all(greaterThanEqual(samplePos, ivec2(0))) && all(lessThan(samplePos, ivec2(viewSize)));

        if (!valid) continue;

        vec4 currentData    = texelFetch(gData, clampTexelPos(samplePos), 0);
            currentData.xyz = currentData.xyz * 2.0 - 1.0;
            currentData.w   = (currentData.w) * far;

        float depthDelta    = abs(currentData.w - centerData.w) * atrousDepthExp;

        float weight        = pow(max(0.0, dot(currentData.xyz, centerData.xyz)), atrousNormalExponent);

        //if (weight < 1e-20) continue;

        //vec4 currentColor   = texelFetch(tex, clampTexelPos(samplePos), 0);
        //float currentLuma   = getLuma(currentColor.rgb);
        SphericalHarmonics currentColor = ReadLightSH(tex, clampTexelPos(samplePos));
        float currentLuma   = IrradianceLuma(currentColor);

        //float lumaDelta     = abs(centerLuma - currentLuma) / clamp(variance.y, 1e-2, 2e4);

            weight         *= exp(-depthDelta);

        //accumulate stuff
        //total       += currentColor * weight;
        accumulateSH(totalColor, currentColor, weight);
        SSAO += ReadLightAux(tex, clampTexelPos(samplePos)).y * weight;

        totalWeight += weight;
    }

    //compensate for total sampling weight
    //total *= rcp(max(totalWeight, 1e-25));
    divideSH(totalColor, max(totalWeight, 1e-25));
    SSAO /= max(totalWeight, 1e-25);

    return totalColor;
}
#endif