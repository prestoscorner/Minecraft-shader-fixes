/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/


/*

    New Voxel storage based on 3D images

*/

ivec3 RVoxel_GetIndexFromScene(vec3 scenePos) {
    return ivec3(floor(scenePos + fract(cameraPosition))) + ivec3(256) / 2;
}
ivec3 RVoxel_GetIndexFromScene_NoOffset(vec3 scenePos) {
    return ivec3(floor(scenePos)) + ivec3(256) / 2;
}
vec3 RVoxel_GetSceneFromIndex(ivec3 Index) {
    return vec3(Index) - vec3(256) / 2.0;
}

vec3 RVoxel_SceneToVoxelSpace(vec3 scenePos) {
    return (scenePos + fract(cameraPosition)) + vec3(256) / 2.0;
}
ivec3 RVoxel_GetIndex(vec3 voxelPos) {
    return ivec3(floor(voxelPos));
}

vec3 RVoxel_ToSceneSpace(vec3 voxelPos) {
    return vec3(voxelPos) - vec3(256) / 2.0 - fract(cameraPosition);
}

bool RVoxel_OutsideVolume(ivec3 pos) {
    return pos.x < 0 || pos.x >= 256 || pos.y < 0 || pos.y >= 256 || pos.z < 0 || pos.z >= 256;
}

#ifndef NO_OCCUPANCY
bool RVoxel_IsOccupied(vec3 scenePos) {
    ivec2 voxelID = unpack2x8I(texelFetch(RVoxelMap0, RVoxel_GetIndexFromScene(scenePos), 0).x);

    return voxelID.x > 0;
}
bool RVoxel_IsOccupied(ivec3 Index) {
    ivec2 voxelID = unpack2x8I(texelFetch(RVoxelMap0, Index, 0).x);

    return voxelID.x > 0;
}
bool RVoxel_IsOccupied(ivec3 Index, out int VoxelType) {
    ivec2 VoxelData = unpack2x8I(texelFetch(RVoxelMap0, Index, 0).x);
    VoxelType = VoxelData.x;

    return VoxelData.x > 0;
}
bool RVoxel_IsOccupied(ivec3 Index, out uint VoxelType, out uint VoxelData0) {
    VoxelData0 = texelFetch(RVoxelMap0, Index, 0).x;
    VoxelType = bitfieldExtract(VoxelData0, 0, 8);

    return VoxelType > 0;
}
bool RVoxel_BVHIsOccupied(ivec3 Index, uint Level) {
    if (Level == 0) {
        return RVoxel_IsOccupied(Index);
    } else {
        Index >>= Level;

        return ((texelFetch(RVoxelOctree, Index, 0).x >> (Level - 1)) & 1u) != 0u;
    }
}
bool RVoxel_BVHIsOccupied(ivec3 Index, uint Level, inout uint VoxelType, inout uint VoxelData0) {
    if (Level == 0) {
        return RVoxel_IsOccupied(Index, VoxelType, VoxelData0);
    } else {
        Index >>= Level;

        return ((texelFetch(RVoxelOctree, Index, 0).x >> (Level - 1)) & 1u) != 0u;
    }
}
vec3 RVoxel_GetTint(ivec3 Index) {
    uint Data = texelFetch(RVoxelMap1, Index, 0).x;

    return unpackColor14(bitfieldExtract(Data, 15, 14));
}
vec3 RVoxel_GetTint(uvec2 VoxelData) {
    return unpackColor14(bitfieldExtract(VoxelData.y, 15, 14));
}
#endif