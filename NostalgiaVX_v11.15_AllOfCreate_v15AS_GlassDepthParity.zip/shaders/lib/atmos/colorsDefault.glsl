/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

#include "/lib/util/colorspace.glsl"

uniform float wetness;

uniform vec3 skyColor;
uniform vec3 fogColor;

uniform vec4 daytime;

flat out mat4x3 colorPalette;     //Sunlight, Moonlight, Skylight, Blocklight

vec3 daytimeColor(vec3 rise, vec3 noon, vec3 set, vec3 night) {
    return rise * daytime.x + noon * daytime.y + set * daytime.z + night * daytime.w;
}
vec3 daytimeColorSquared(vec3 rise, vec3 noon, vec3 set, vec3 night) {
    return rise * sqr(daytime.x) + noon * (1-sqr(1-daytime.y)) + set * sqr(daytime.z) + night * (1-sqr(1-daytime.w));
}

void getColorPalette() {
    vec3 linearSky  = toLinear(skyColor);
    vec3 linearFog  = toLinear(fogColor);

    colorPalette[0]   = daytimeColor(
        vec3(0.79, 0.306, 0.03) * 0.70,
        vec3(1.00, 0.93, 0.72) * 1.00,
        vec3(0.79, 0.29, 0.04) * 0.70,
        vec3(0.69, 0.27, 0.04) * 0.10
        ) * 16.0;

    colorPalette[0]  *= sunlightIllum * vec3(sunlightRedMult, sunlightGreenMult, sunlightBlueMult);
    colorPalette[0]   = colorSaturation(colorPalette[0], 1.0 - wetness * 0.75) * (1.0 - wetness * 0.75);

    colorPalette[1]   = vec3(0.22, 0.33, 1.0) * 0.17;
    colorPalette[1]  *= moonlightIllum * vec3(moonlightRedMult, moonlightGreenMult, moonlightBlueMult);
    colorPalette[1]   = colorSaturation(colorPalette[1], 1.0 - wetness * 0.25);
    
    //vec3 skylightColor = mix(linearSky, colorPalette[0] / euler, 0.3);

    colorPalette[2]   = daytimeColor(
        vec3(0.81, 0.80, 0.97) * 0.30,
        vec3(0.75, 0.84, 0.98) * 0.50,
        vec3(0.81, 0.80, 0.97) * 0.31,
        vec3(0.33, 0.49, 0.94) * 0.01
        ) * 1.0;

    colorPalette[2]  *= vec3(skylightRedMult, skylightGreenMult, skylightBlueMult) * skylightIllum;

    colorPalette[3]   = blackbody(float(blocklightBaseTemp)) * blocklightIllum * blocklightBaseMult * 1.5;
}