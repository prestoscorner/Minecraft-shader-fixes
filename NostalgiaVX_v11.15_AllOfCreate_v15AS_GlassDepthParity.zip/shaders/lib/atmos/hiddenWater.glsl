#ifndef HIDDEN_WATER_HELPERS
#define HIDDEN_WATER_HELPERS

// Helpers for water hidden behind a translucent front layer.
float hiddenWaterViewDist = 0.0;
#define viewDist hiddenWaterViewDist
#include "/lib/atmos/waterWaves.glsl"
#undef viewDist

float hiddenWaterDecodeDistance(float code) {
    float f = max(far, 1.0);
    return max(exp2(clamp(code, 0.0, 1.0) * log2(1.0 + f)) - 1.0, 0.0);
}

vec3 hiddenWaterNormal(vec3 worldPos, float dist) {
    hiddenWaterViewDist = dist;
    float dstep = 0.005 + (1.0 - exp(-dist * rcp(32.0))) * 0.035;
    vec2 delta;
    delta.x  = waterWaves(worldPos + vec3( dstep, 0.0, -dstep), 102);
    delta.y  = waterWaves(worldPos + vec3(-dstep, 0.0,  dstep), 102);
    delta   -= waterWaves(worldPos + vec3(-dstep, 0.0, -dstep), 102);
    return normalize(vec3(-delta.x, 2.0 * dstep, -delta.y));
}

#endif
