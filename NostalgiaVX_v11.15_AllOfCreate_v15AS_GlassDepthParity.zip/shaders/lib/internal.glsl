/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

const float indirectResScale = sqrt(1.0 / float(indirectResReduction));
const float reflectionResScale = sqrt(1.0 / float(reflectionResReduction));

const int shadowMapResolution = 1024; 	//[512 1024 2048 4096 8192]

#define cloudShadowmapRenderDistance 512.0
#define cloudShadowmapResolution 256

const int noiseTextureResolution = 256;

const int voxelMapRes = int(shadowMapResolution * MC_SHADOW_QUALITY);
const int shadowMapRes = int(shadowMapResolution * MC_SHADOW_QUALITY);

#ifndef DIM
    #define generateShadowmap
#endif

#define blocklightBaseMult pi

#define minimumAmbientColor vec3(0.5, 0.7, 1.0)
#define minimumAmbientMult (0.005)

#define maxTraversalDistance 64     //[16 24 32 48 64 96 128

#define DEBUG_VIEW 0    //[0 1 2 3 4 5 6] 0-off, 1-whiteworld, 2-indirect light, 3-albedo/unlit, 4-irradiance cache, 5-hdr

#define ResolutionScale 0.67     //[0.25 0.5 0.6 0.67 0.75 1.0]

#define VX_MAX_WIDTH 256

#define REF_VIEWPORT vec2(2.0, 1.0)


const float shadowDistance = 160.0;     // Does not change the actual render distance
const float shadowDistanceRenderMul = 3.2;      // Cull geometry thats so far away that the shadowmap precision wouldnt be enough anyways
const float voxelDistance = 256.0;