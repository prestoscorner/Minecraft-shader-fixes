/*
    Dedicated first-person held-item vertex path.
    Keeps held geometry camera-relative and deliberately avoids TAA jitter/TBN/POM setup.
*/

#include "/lib/head.glsl"

uniform vec2 viewSize;
#define VERTEX_STAGE
#include "/lib/downscaleTransform.glsl"

out mat2x2 coord;
out vec4 tint;
flat out vec3 normal;

uniform mat4 gbufferModelViewInverse;

void main() {
    coord[0] = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    coord[1] = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;

    coord[1].x = linStep(coord[1].x, rcp(24.0), 1.0);
    coord[1].y = linStep(coord[1].y, rcp(16.0), 1.0);

    vec4 pos = gl_Vertex;
    pos = transMAD(gl_ModelViewMatrix, pos.xyz).xyzz;

    vec3 viewNormal = normalize(gl_NormalMatrix * gl_Normal);
    normal = normalize(mat3(gbufferModelViewInverse) * viewNormal);
    tint = gl_Color;

    pos = pos.xyzz * diag4(gl_ProjectionMatrix)
        + vec4(0.0, 0.0, gl_ProjectionMatrix[3].z, 0.0);

    // Intentionally NO temporal jitter here. Held geometry has no reliable world-space
    // motion vector and is handled as a current-frame surface in temporal.fsh.
    gl_Position = pos;
    VertexDownscaling(gl_Position);
}
