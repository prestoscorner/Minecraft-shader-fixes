/*
    Dedicated first-person held-item fragment path.
    The hand/object keeps its base texture, tint, lightmap and emission, but does not
    inherit world PBR normal/specular/POM/wetness data. Material ID 201 is reserved
    for this stable first-person path.
*/

/* RENDERTARGETS: 0,1,2,3 */
layout(location = 0) out vec4 sceneAlbedo;
layout(location = 1) out vec4 sceneDataA;
layout(location = 2) out vec4 sceneDataB;
layout(location = 3) out vec3 flatNormal;

#include "/lib/head.glsl"
#include "/lib/util/colorspace.glsl"
#include "/lib/util/encoders.glsl"

uniform vec2 viewSize;
#include "/lib/downscaleTransform.glsl"

in mat2x2 coord;
in vec4 tint;
flat in vec3 normal;

uniform sampler2D gcolor;

#if MC_VERSION >= 11700
uniform float alphaTestRef;
#else
#define alphaTestRef 0.1
#endif

void main() {
    if (OutsideDownscaleViewport()) discard;

    const float MipBias = -(1.0 / ResolutionScale) * 0.5;
    vec4 sceneColor = texture(gcolor, coord[0], MipBias) * tint;
    if (sceneColor.a < alphaTestRef) discard;

    // The held object is opaque in the deferred hand pass. Preserve the texture/tint,
    // but use the real polygon normal and a deliberately neutral non-metal material.
    sceneColor.a = 1.0;
    convertToPipelineAlbedo(sceneColor.rgb);

    vec2 lightmap = coord[1];
    vec2 stableSpecular = vec2(0.0); // decodeLabBasic -> roughness 1.0, minimum F0
    vec2 stableMaterialAux = vec2(0.0);

    const int matID = 201;
    const int emissionID = 0; // Handheld light emission is resolved from heldItemId, never the lightmap.

    sceneAlbedo = drawbufferClamp(sceneColor);

    sceneDataA.xy = encodeNormal(normalize(normal));
    sceneDataA.z  = pack2x8(lightmap);
    sceneDataA.w  = pack2x8(stableMaterialAux);

    sceneDataB.x  = pack2x8(stableSpecular);
    sceneDataB.y  = pack2x8(ivec2(matID, emissionID));
    sceneDataB.z  = pack2x8(1.0, 0.0); // no parallax shadow attenuation, no wetness
    sceneDataB.w  = 1.0;               // neutral AO

    flatNormal = normalize(normal) * 0.5 + 0.5;
}
