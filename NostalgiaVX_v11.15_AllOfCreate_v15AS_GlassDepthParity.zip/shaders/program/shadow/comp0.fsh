/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

layout(location = 0) out vec4 data0;

#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"
#include "/lib/util/colorspace.glsl"
#include "/lib/shadowconst.glsl"

#define gSHADOW

in vec2 uv;

uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;

//uniform sampler2D colortex5;

uniform sampler2D noisetex;

uniform float frameTimeCounter;

uniform vec3 cameraPosition;
uniform vec3 lightDir;

uniform mat4 shadowModelView, shadowProjection;
uniform mat4 shadowModelViewInverse, shadowProjectionInverse;

#define FUTIL_MAT16
#include "/lib/fUtil.glsl"
#include "/lib/light/warp.glsl"


/* ------ caustics ------ */

#include "/lib/util/bicubic.glsl"

const float viewDist = 0.0;

#include "/lib/atmos/waterConst.glsl"

vec3 shadowScreenToView(vec3 position, float warp) {
    position    = position * 2.0 - 1.0;
    position.z /= 0.2;
    position.xy *= warp;
    position    = projMAD(inverse(shadowProjection), position);

    return position;
}
vec3 shadowViewToScene(vec3 position) {
    position     = transMAD(inverse(shadowModelView), position);

    return position;
}
/*
// ------ ATLAS ------ //

struct atlasData {
    vec2 tileIndexFraction; //2x8 bits
    vec2 tileIndexFloored;  //2x4 bits
    float tileRes;          //4 bits
};

atlasData unpackAtlasData(vec2 packedData) {
    vec2 a = unpack2x8(packedData.y);
    return atlasData(unpack2x8(packedData.x), decode2x4Unorm(a.x), a.y);
}

// ------ VOXELS ------ //

#define atlasSampler colortex5

//#include "/lib/voxel/store.glsl"

vec4 emissionColor(vec3 albedo, float alpha, int voxelEmission) {
    if (voxelEmission == 0) return vec4(albedo, alpha);

    float lum   = getLuma(albedo);

    float albedoLum = mix(avgOf(albedo), maxOf(albedo), 0.71);
        albedoLum   = saturate(albedoLum * sqrt2);

    float emitterLum = saturate(mix(sqr(albedoLum), sqrt(maxOf(albedo)), albedoLum) * sqrt2);

    return vec4(mix(sqr(normalize(albedo)), normalize(albedo), sqrt(emitterLum)) * emitterLum, alpha * emitterLum);
}
vec2 getVoxelAtlasUV(vec2 localPos, atlasData atlas) {
    vec2 uv     = vec2(fract(localPos.x), fract(localPos.y));

    uv += 256.0 * 15.0 * atlas.tileIndexFloored + 255.0 * atlas.tileIndexFraction;
    uv *= exp2(atlas.tileRes * 15.0) / textureSize(atlasSampler, 0);

    return uv;
}
vec2 voxelUV(vec3 pos, vec3 normal, atlasData voxel) {
    vec2 uv;

	if (abs(normal.y) > abs(normal.x) && abs(normal.y) > abs(normal.z)) {
		uv = vec2(fract(pos.x), fract(pos.z * sign(normal.y)));
	} else {
		uv = vec2(fract(pos.x * sign(normal.z) - pos.z * sign(normal.x)), fract(-pos.y));
	}

    uv += 256.0 * 15.0 * voxel.tileIndexFloored + 255.0 * voxel.tileIndexFraction;
    uv *= exp2(voxel.tileRes * 15.0) / textureSize(atlasSampler, 0);

    return uv;
}
vec3 getAlbedoAverage(atlasData atlasUV, vec3 tint, int voxelEmission) {
    ivec3 index = uvToVoxelIndex(ivec2(floor(gl_FragCoord.xy)));

    vec4 totalAlbedo    = texture(atlasSampler, voxelUV(vec3(0), vec3(0,1,0), atlasUV));
    totalAlbedo.rgb     = srgbToPipelineAlbedo(totalAlbedo.rgb * tint);
    totalAlbedo         = emissionColor(totalAlbedo.rgb, totalAlbedo.a, voxelEmission);

    int atlasMipmapLevel = textureQueryLevels(atlasSampler)-1;

    return totalAlbedo.rgb;
    
    for (uint x = 0; x <= VOXEL_COLOR_SAMPLES; ++x) {
        for (uint y = 0; y <= VOXEL_COLOR_SAMPLES; ++y) {
            float Xlerp     = saturate(float(x) / VOXEL_COLOR_SAMPLES);
            float Ylerp     = saturate(float(y) / VOXEL_COLOR_SAMPLES);
            vec2 uv         = getVoxelAtlasUV(vec2(Xlerp, Ylerp), atlasUV);

            vec4 tapSample  = textureLod(atlasSampler, uv, 0);
            tapSample.rgb   = srgbToPipelineAlbedo(tapSample.rgb * tint);
            tapSample       = emissionColor(tapSample.rgb, tapSample.a, voxelEmission);
            totalAlbedo    += tapSample;
        }
    }
    totalAlbedo.rgb /= max(totalAlbedo.a, 1e-8);

    return saturate(totalAlbedo.rgb);
}
*/
void main() {
    data0           = clamp16F(texture(shadowcolor0, uv));

    #ifndef DISABLE_SHADOWMAP
    float caustic   = data0.x;
    vec4 albedo     = data0;
    albedo.rgb      = srgbToPipelineAlbedo(vec3(unpack2x8(data0.x), unpack2x8(data0.y).x));
    
    int matID       = decodeMatID16(data0.z);

    vec2 depth      = vec2(texture(shadowtex0, uv).x, texture(shadowtex1, uv).x);

    float warp      = calculateWarp(uv * 2.0 - 1.0);

    vec3 viewPos0   = shadowScreenToView(vec3(uv, depth.x), warp);
    vec3 scenePos0  = shadowViewToScene(viewPos0);
    vec3 viewPos1   = shadowScreenToView(vec3(uv, depth.y), warp);
    vec3 scenePos1  = shadowViewToScene(viewPos1);

    data0           = vec4(vec3(0.25), 0.0);
    if (depth.x < depth.y) data0 = albedo * vec4(vec3(0.25), 1.0);
    
    if (matID == 102 || matID == 103) {     //Water
        //float caustic   = data0.r * 4.0;

        float surfaceDist = distance(scenePos0, scenePos1);
        surfaceDist = min(surfaceDist, 8.0);

        vec3 absorb     = exp(-max0(surfaceDist * waterDensity) * waterAbsorbCoeff);
        float causticSignal = max0(caustic * 4.0);
        #ifdef enhancedWaterCausticsEnabled
            // Neutral at 1.0, brighter crests and darker troughs as strength rises. The signal
            // itself still comes from NostalgiaVX's animated water-wave Jacobian.
            causticSignal = clamp(1.0 + (causticSignal - 1.0) * waterCausticStrength, 0.12, 3.5);
        #endif
            absorb     *= mix(causticSignal, 1.0, exp(-max0(surfaceDist) * sqrt2));

        data0           = vec4(absorb * 0.25, 1.0);
    }
    #endif
}