//          
#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"

attribute vec3 at_midBlock;
attribute vec4 at_tangent;
attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;
attribute vec4 mc_spriteBounds;

//uniform ivec2 atlasSize;

uniform vec3 cameraPosition;

// block.properties ID for block entities rendered in the shadow pass.
// Needed for Amendments wall lanterns, which are EntityBlock/BER geometry.
uniform int blockEntityId;

uniform mat4 shadowModelViewInverse;

uniform sampler2D RAtlasSampler;

layout(r32ui) restrict uniform uimage3D RVoxelImage0;
layout(r32ui) restrict uniform uimage3D RVoxelImage1;
layout(r32ui) restrict uniform uimage3D RVoxelOctreeImage_Temp;

out vertexOut {
    flat int BlockID;

    float ShadowmapWarp;

    vec2 UV;

    vec3 Tint;
    vec3 SceneLocation;
    flat vec3 Normal;

    flat vec4 Tangent;
};

#ifdef pomEnabled
    #if (defined normalmapEnabled || defined pomEnabled)
        flat out mat3 tbn;
    #endif

    #if (MC_VERSION >= 11500 && defined vertexAttributeFix)
        #define tbnFix
    #endif

    uniform mat4 gbufferModelView;

    out float vertexDist;
    out vec2 vCoord;
    out vec4 vCoordAM;
    out vec3 viewVec;

    #ifdef tbnFix
        out vec3 vertexPos;
    #endif
#endif

#include "/lib/light/warp.glsl"

#include "/lib/light/idTable.glsl"

#define NO_OCCUPANCY

#include "/lib/voxel/store.glsl"

struct atlasData {
    vec2 tileIndexFraction; //2x8 bits
    vec2 tileIndexFloored;  //2x4 bits
    float tileRes;          //4 bits
};

uvec2 packAtlasData(atlasData data) {
    return uvec2(pack2x8UI(data.tileIndexFraction),
                 pack2x8UI(vec2(encode2x4Unorm(data.tileIndexFloored), data.tileRes)));
}

uvec2 PackVoxelForAtomic(int VoxelType, int Emission, uvec2 PackedAtlasData, vec3 VoxelTint, float FaceWeight) {
    uint VoxelWeight = VoxelType > 0 ? uint(FaceWeight * 7) : 0;

    uint PackedTint = packColor14UI(VoxelTint);

    uint bf0 = uint(VoxelType);
    bf0 = bitfieldInsert(bf0, uint(Emission), 8, 6);
    bf0 = bitfieldInsert(bf0, PackedAtlasData.x, 14, 15);
    bf0 = bitfieldInsert(bf0, VoxelWeight, 29, 3);

    uint bf1 = PackedAtlasData.y;
    bf1 = bitfieldInsert(bf1, PackedTint, 15, 14);
    bf1 = bitfieldInsert(bf1, VoxelWeight, 29, 3);

    return uvec2(bf0, bf1);
}

uint PackVoxelForAtomicCondition(int VoxelType, float FaceWeight) {
    uint VoxelWeight = VoxelType > 0 ? uint(saturate(FaceWeight) * 15) : 0;

    uint bf0 = uint(VoxelType);
    bf0 = bitfieldInsert(bf0, VoxelWeight, 8, 8);

    return bf0;
}

uvec4 PackVoxelInfo(int VoxelType, int Emission, uvec2 PackedAtlasData, vec3 VoxelTint) {
    uint PackedTint = packColor16UI(VoxelTint);

    uint bf0 = uint(VoxelType);
    bf0 = bitfieldInsert(bf0, uint(Emission), 8, 8);

    uint bf1 = PackedAtlasData.x;
    bf1 = bitfieldInsert(bf1, PackedAtlasData.y, 8, 8);

    uint bf2 = PackedTint;

    return uvec4(bf0, bf1, bf2, 0);
}

uint packVoxeldata(uvec2 offset, int textureRes) {
    uint size = uint(log2(textureRes));
    offset = offset/uint(textureRes);
    return (size << 22) | (offset.x << 11) | offset.y;
}

uvec2 PackVoxelUV(uvec2 offset, int textureRes) {
    uint size = uint(log2(textureRes));
    offset = offset/uint(textureRes);
    
    uint bf = offset.x;
    bf = bitfieldInsert(bf, offset.y, 11, 11);
    bf = bitfieldInsert(bf, size, 22, 4);
    return uvec2(bf >> 15, bf & 32767u);
}

#ifdef windEffectsEnabled
    uniform mat4 shadowModelView;

    #include "/lib/vertex/wind.glsl"
#endif

#define WIND_NEW_TOPVERT

bool getFoliageTopVertex(float worldY) {
    #ifdef WIND_NEW_TOPVERT
    float bottomY = (worldY + (at_midBlock.y / 64.0)) - 0.45;

    return worldY > bottomY;
    #else
    return (gl_MultiTexCoord0.t < mc_midTexCoord.t);
    #endif
}


void main() {
    UV              = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec2 MidUV      = (gl_TextureMatrix[0] * mc_midTexCoord).xy;

    Tint            = gl_Color.rgb;

    vec4 position   = gl_Vertex;

    vec3 LocalLocation   = position.xyz;

        position    = gl_ModelViewMatrix * position;
        position    = shadowModelViewInverse * position;

    SceneLocation   = position.xyz;

    vec3 CenteredSceneLocation = position.xyz + (at_midBlock / 64.0) * 0.9;

    ivec3 VoxelIndex     = RVoxel_GetIndexFromScene(CenteredSceneLocation);

    ivec2 atlasSize = textureSize(RAtlasSampler, 0);

    Normal          = gl_Normal;
    Tangent         = at_tangent;

    vec4 SpriteBounds = vec4(
        (gl_TextureMatrix[0] * vec4(mc_spriteBounds.xy, 1,1)).xy,
        (gl_TextureMatrix[0] * vec4(mc_spriteBounds.zw, 1,1)).xy
    );

    //vec2 MaxUV = vec2(max(SpriteBounds.x, SpriteBounds.z), max(SpriteBounds.y, SpriteBounds.w));
    //vec2 MinUV = vec2(min(SpriteBounds.x, SpriteBounds.z), min(SpriteBounds.y, SpriteBounds.w));

    vec2 midcoordPix = MidUV * atlasSize;
    // V15V mod-stack safety: Ocuwheel/Flywheel compatibility geometry may not always carry
    // vanilla sprite bounds exactly like chunk terrain. Never allow a zero/invalid texture
    // extent to feed log2/mod into the VX atlas packer.
    vec2 textureSize = max(round(abs(UV - MidUV) * 2 * atlasSize), vec2(1.0));
    int textureRes = int(pow(2.0, ceil(log2(max(max(textureSize.x,textureSize.y), 1.0)))));
    textureRes = clamp(textureRes, 1, 1024);
    uvec2 texelOffset = uvec2(midcoordPix - mod(midcoordPix, float(textureRes)));
/*
    vec2 atlasAspectCorrect = vec2(1.0, float(atlasSize.x) / float(atlasSize.y));

    vec3 Bitangent = cross(at_tangent.xyz, gl_Normal.xyz) * (at_tangent.w < 0.0 ? -1.0 : 1.0);

    vec2 SpriteAspect = (MaxUV - MinUV) * atlasAspectCorrect;
        SpriteAspect /= maxOf(SpriteAspect);

    vec3 VertPosU = LocalLocation + Tangent.xyz * SpriteAspect.x;
    vec3 VertPosV = LocalLocation + Bitangent * SpriteAspect.y;

    vec2 FaceSize = vec2(maxOf(VertPosU) - minOf(VertPosU), maxOf(VertPosV) - minOf(VertPosV));
        FaceSize /= maxOf(FaceSize);
        FaceSize /= vec2(length(Tangent.xyz), length(Bitangent));

    vec2 tileSize   = (abs(MaxUV - MinUV));
    vec2 tileRes    = round(tileSize * atlasSize);

    ivec2 tileIndex = ivec2((MidUV) / tileSize);

    atlasData atlasUV   = atlasData(fract(tileIndex / 256.0) * 256.0 / 255.0,
                                        floor(tileIndex / 256.0) / 15.0,
                                        log2(maxOf(tileRes)) / 15.0);*/

    //uvec2 atlasTemp     = packAtlasData(atlasUV);
    uvec2 atlasTemp = PackVoxelUV(texelOffset, textureRes);

    int mcEntity    = int(mc_Entity.x);

    // mc_Entity is terrain-only. For the Amendments wall lantern BER, use
    // blockEntityId so it gets the same voxel shape + hardcoded emission as
    // the corresponding vanilla lantern/soul-lantern. This bypasses the
    // Amendments 1.21.1 wall-light-level bug for VX's PT lighting.
    bool KnownVXBlockEntity = (blockEntityId == 1020 || blockEntityId == 1022);
    if (KnownVXBlockEntity) mcEntity = blockEntityId;

    // V15W compatibility correction: keep all valid shadow-pass geometry eligible for VX
    // voxelization. Ocuwheel/Create Shader Fixes may render legitimate enclosed-space geometry
    // as block entities; excluding it made the VX visibility/light volume incomplete in third person.

    int voxelMode       = remapShapeID(mcEntity);

    bool weightSideFaces =(
        mcEntity == 1100
     || (mcEntity >= 1110 && mcEntity <= 1125)
     //|| mcEntity == 1004
     //|| mcEntity == 1005
     //|| mcEntity == 1006
     //|| mcEntity == 1007
     );

    BlockID         = 0;
    if (mcEntity == 10001) BlockID = 102;

    int emissionID      = remapEmissionID(mcEntity);

    float faceWeight = saturate(0.5 + sign(Normal.y) * 0.5);
    if (weightSideFaces) {
        float InvNormalSign = (1.0 - abs(Normal.y));
        faceWeight = saturate(0.5 + InvNormalSign * 0.5);
    }
    faceWeight *= 0.5 + (SceneLocation - CenteredSceneLocation).y * 0.5;

    if (!RVoxel_OutsideVolume(VoxelIndex)) {
        uvec2 PackedVoxel = PackVoxelForAtomic(voxelMode, emissionID, atlasTemp, saturate(Tint), saturate(faceWeight));

        if (voxelMode > 0) {
            // V15V: use NostalgiaVX's original deterministic hierarchy construction.
            // The old first-writer shortcut depended on which vertex won the atomic race; with
            // Flywheel GPU instancing that ordering can vary as the camera moves. Rebuilding the
            // occupancy chain for every valid voxel write costs a little more, but guarantees the
            // same octree coverage regardless of instance/vertex submission order.
            imageAtomicMax(RVoxelImage0, VoxelIndex, PackedVoxel.x);
            imageAtomicMax(RVoxelImage1, VoxelIndex, PackedVoxel.y);

            uint bit = 1u;
            ivec3 OctreeIndex = VoxelIndex;
            for (int i = 0; i < 8; i++) {
                OctreeIndex >>= 1;
                imageAtomicOr(RVoxelOctreeImage_Temp, OctreeIndex, bit);
                bit <<= 1u;
            }
        }
    }

    #ifdef NO_SHADOWMAP
    gl_Position = vec4(-1);
    #else
    vec4 pos = (gl_ModelViewMatrix * gl_Vertex);

    #ifdef windEffectsEnabled
        pos.xyz = transMAD(shadowModelViewInverse, pos.xyz);

        bool windLod    = length(pos.xz) < 96.0;

        if (windLod) {
            bool topVertex  = getFoliageTopVertex(pos.y);

            float occlude   = sqr((gl_TextureMatrix[1] * gl_MultiTexCoord1).y)*0.9+0.1;

            if ((mc_Entity.x >= 10021 && mc_Entity.x <=10024) || mc_Entity.x == 10027) {
                vec2 windOffset = vertexWindEffect(pos.xyz + cameraPosition, 0.18, 1.0);

                if (mc_Entity.x == 10027) pos.xz += windOffset.xy * (1.0 + length(windOffset));
                    windOffset*= occlude;

                if (mc_Entity.x == 10021) pos.xyz += windOffset.xyy*0.4;

                if (mc_Entity.x == 10022 && topVertex)
                    pos.xz += windOffset;

                if ((mc_Entity.x == 10023 && topVertex) || (mc_Entity.x == 10024)) pos.xz += windOffset * 0.5;
                if ((mc_Entity.x == 10024 && topVertex)) pos.xz += windOffset * 0.5;
            }
        }

        pos.xyz = transMAD(shadowModelView, pos.xyz);
    #endif


    gl_Position     = gl_ProjectionMatrix * pos;
    gl_Position.xy  = shadowmapWarp(gl_Position.xy, ShadowmapWarp);
    gl_Position.z  *= 0.2;

    #ifdef pomEnabled
        //vec3 viewNormal = normalize(gl_NormalMatrix*gl_Normal);
        vec3 viewTangent = normalize(gl_NormalMatrix*at_tangent.xyz);
        vec3 viewBinormal = normalize(gl_NormalMatrix*cross(at_tangent.xyz, gl_Normal.xyz) * at_tangent.w);

        mat3 viewtbn = mat3(
            viewTangent.x, viewBinormal.x, Normal.x,
            viewTangent.y, viewBinormal.y, Normal.y,
            viewTangent.z, viewBinormal.z, Normal.z);

        vec2 coordMid   = (gl_TextureMatrix[0] * mc_midTexCoord).xy;
        vec2 coordNMid  = UV - coordMid;

        vCoordAM.zw     = abs(coordNMid) * 2.0;
        vCoordAM.xy     = min(UV, coordMid - coordNMid);

        vCoord          = sign(coordNMid) * 0.5 + 0.5;
        viewVec         = viewtbn * (gl_ModelViewMatrix * gl_Vertex).xyz;

        vec3 viewPos = transMAD(gbufferModelView, SceneLocation);
        vertexDist   = length(viewPos);
    #endif
    #endif
}