/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 data0;

#define shadowmapTextureMipBias 0   //[1 2 3 4]

#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"
#include "/lib/util/colorspace.glsl"
#include "/lib/shadowconst.glsl"
/*
in voxelOut {
    flat int isVoxel;
    flat int emission;
    flat int voxelType;

    vec2 midUV;
    vec2 minUV;
    vec2 maxUV;
    flat uvec2 packedAtlasData;
} voxelIn;*/
/*
in geoOut {
    flat int BlockID;

    float ShadowmapWarp;

    vec2 UV;

    vec3 Tint;
    vec3 SceneLocation;
} VertexIn;*/

in vertexOut {
    flat int BlockID;

    float ShadowmapWarp;

    vec2 UV;

    vec3 Tint;
    vec3 SceneLocation;
    flat vec3 Normal;

    flat vec4 Tangent;
} VertexIn;

#define gSHADOW

uniform sampler2D gtexture;

uniform sampler2D noisetex;

uniform sampler2D shadowcolor1;

uniform int blockEntityId;
uniform int entityId;

uniform float frameTimeCounter;

uniform ivec2 atlasSize;

uniform vec3 cameraPosition;
uniform vec3 lightDir;

#if (defined pomEnabled && defined pomDepthEnabled)
    uniform float near;
    uniform float far;
    uniform sampler2D normals;

    in float vertexDist;
    in vec2 vCoord;
    in vec4 vCoordAM;
    in vec3 viewVec;

    flat in mat3 tbn;

    #include "/lib/frag/parallax.glsl"

    float linearizeOrthoDepth(float depth) {
        return (depth * 2.0 - 1.0) * (far - near) + near;
    }

    float delinearizeOrthoDepth(float depth) {
        return ((depth - near) / (far - near)) * 0.5 + 0.5;
    }
#endif

#if MC_VERSION >= 11700
uniform float alphaTestRef;
#else
#define alphaTestRef 0.1
#endif



/* ------ CAUSTICS ------ */

#define FUTIL_ROT2
#include "/lib/fUtil.glsl"

#include "/lib/util/bicubic.glsl"

const float viewDist = 0.0;

#include "/lib/atmos/waterWaves.glsl"

vec3 waterNormal(vec3 position, float dstep, int matID) {
        dstep       = max(dstep, 0.015);

    vec2 delta;
        delta.x     = waterWaves(position + vec3( dstep, 0.0, -dstep), matID);
        delta.y     = waterWaves(position + vec3(-dstep, 0.0,  dstep), matID);
        delta      -= waterWaves(position + vec3(-dstep, 0.0, -dstep), matID);

    return normalize(vec3(-delta.x, 2.0 * dstep, -delta.y));
}

float projectedCaustic(vec3 pos, vec3 normal, vec3 lightDir) {
    vec3 dPdx   = dFdx(pos);
    vec3 dPdy   = dFdy(pos);

    float num   = dotSelf(dPdx) * dotSelf(dPdy);

    vec3 refractLight = refract(-lightDir, normal, rcp(1.33));
        dPdx   += 2.0 * dFdx(refractLight);
        dPdy   += 2.0 * dFdy(refractLight);

    float denom = dotSelf(dPdx) * dotSelf(dPdy);

    return sqrt(num * rcp(denom));
}


/* ------ VOXELS ------ */
/*
vec4 emissionColor(vec3 albedo, float alpha) {
    if (voxelIn.emission == 0) return vec4(albedo, alpha);

    float lum   = getLuma(albedo);

    float albedoLum = mix(avgOf(albedo), maxOf(albedo), 0.71);
        albedoLum   = saturate(albedoLum * sqrt2);

    float emitterLum = saturate(mix(sqr(albedoLum), sqrt(maxOf(albedo)), albedoLum) * sqrt2);

    return vec4(mix(sqr(normalizeSafe(albedo)), normalizeSafe(albedo), (emitterLum)) * emitterLum, alpha);
}

vec4 getAlbedoAverage(vec3 tint) {
    vec4 totalAlbedo    = vec4(0);

    bool smallEmitter   = voxelIn.voxelType == 2 && voxelIn.emission > 0;

    int atlasMipmapLevel = smallEmitter ? 0 : textureQueryLevels(gtexture)-1;
    //atlasMipmapLevel = 0;
    
    totalAlbedo         = textureLod(gtexture, smallEmitter ? voxelIn.minUV : voxelIn.midUV, atlasMipmapLevel);
    totalAlbedo.rgb     = srgbToPipelineAlbedo(totalAlbedo.rgb * tint);

    float alpha         = totalAlbedo.a;

    totalAlbedo         = emissionColor(totalAlbedo.rgb, totalAlbedo.a);

    //const vec2 edgeOffset = vec2(1.0 / 16.0, 1.0 - (2.0 / 16.0));

    if (totalAlbedo.a < 0.1) {        
        for (uint x = 0; x <= VOXEL_COLOR_SAMPLES; ++x) {
            for (uint y = 0; y <= VOXEL_COLOR_SAMPLES; ++y) {
                float Xlerp     = saturate(float(x) / VOXEL_COLOR_SAMPLES) * 0.8 + 0.1;
                float Ylerp     = saturate(float(y) / VOXEL_COLOR_SAMPLES) * 0.8 + 0.1;
                vec2 uv     = vec2(mix(voxelIn.minUV.x, voxelIn.maxUV.x, Xlerp), mix(voxelIn.minUV.y, voxelIn.maxUV.y, Ylerp));

                vec4 tapSample  = textureLod(gtexture, uv, atlasMipmapLevel);
                alpha          += tapSample.a;
                tapSample.rgb   = srgbToPipelineAlbedo(tapSample.rgb * tint);
                tapSample       = emissionColor(tapSample.rgb, tapSample.a);
                totalAlbedo    += tapSample;
            }
        }
        //totalAlbedo = vec4(1.0, 0.0, 0.0, 1.0);
    }
    
    totalAlbedo /= max(totalAlbedo.a, 1e-8);

    if (alpha < 0.1) return vec4(1,1,1,0);

    if (voxelIn.voxelType == 3) totalAlbedo.rgb = normalizeSafe(totalAlbedo.rgb);

    return saturate(vec4(totalAlbedo.rgb, alpha));
    
}*/

void main() {
    #ifdef NO_SHADOWMAP
        discard;
    #else

    // Vanilla blob/entity shadows are already a shadow effect, not geometry.
    // Never feed them back into VX's physical shadow/voxel path.
    if (entityId == 999) discard;

    // Name tags are screen-facing UI text, not physical shadow-casting geometry.
    // When Iris exposes the hardcoded name-tag ID, remove it from the shadow/voxel path.
    #ifdef nameTagFullbright
    if (entityId == 1301) discard;
    #endif
    
    #ifndef gSOLID
    if (blockEntityId == 10201) discard;
    #endif

    #if (defined pomEnabled && defined pomDepthEnabled)
        gl_FragDepth = gl_FragCoord.z;
    #endif

    if (VertexIn.BlockID == 102) {
        vec3 waves      = waterNormal(VertexIn.SceneLocation + cameraPosition, rcp(shadowMapResolution) * VertexIn.ShadowmapWarp, VertexIn.BlockID);
        vec3 refractLight = refract(lightDir, waves, rcp(1.33));
        float caustic   = projectedCaustic(VertexIn.SceneLocation, waves, lightDir);
        data0           = vec4(caustic * 0.25, 1.0, encodeMatID16(VertexIn.BlockID), 1.0);
    } else {
        #if (defined pomEnabled && defined pomDepthEnabled)
            mat2 dCoord = mat2(dFdx(VertexIn.UV), dFdy(VertexIn.UV));

            float TexDepth = 1.0, TraceDepth = 1.0;
            vec4 parallaxCoord  = getParallaxCoord(VertexIn.UV, dCoord, TexDepth, TraceDepth);

            // TODO: Apply shadowmapTextureMipBias!
            data0 = textureParallax(gtexture, parallaxCoord.xy, dCoord);
        #else
            data0 = texture(gtexture, VertexIn.UV, -shadowmapTextureMipBias);
        #endif
        
        #ifndef gSOLID
        if (data0.a<alphaTestRef) discard;
        #endif
            data0.rgb *= VertexIn.Tint;

        #if (defined pomEnabled && defined pomDepthEnabled)
            float pomDist = (1.0 - TraceDepth) * rcp(normalize(-viewVec).z);
            float depth = linearizeOrthoDepth(gl_FragCoord.z);
            gl_FragDepth = delinearizeOrthoDepth(depth + pomDist * pomDepth);
        #endif

        data0.x     = pack2x8(data0.rg);
        data0.y     = pack2x8(data0.b, 1.0);
        data0.z     = encodeMatID16(VertexIn.BlockID);
        data0.a     = sqrt(data0.a);

        //data0.rgb  = srgbToPipelineAlbedo(data0.rgb);
        //data0.rgb  = sqrt(data0.rgb);
    }
    #endif
}