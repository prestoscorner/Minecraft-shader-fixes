    #define volumeWorldTimeAnim

    /* --- COEFFICIENTS --- */
    #define rayleighRedMult 1.00    //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define rayleighGreenMult 1.00  //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define rayleighBlueMult 1.00   //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    #define mieRedMult 1.00         //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define mieGreenMult 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define mieBlueMult 1.00        //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    #define ozoneRedMult 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define ozoneGreenMult 1.00     //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define ozoneBlueMult 1.00      //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    #define mistRedMult 1.00        //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define mistGreenMult 1.00      //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define mistBlueMult 1.00       //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    #define skyRedMult 1.00    //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define skyGreenMult 1.00  //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define skyBlueMult 1.00   //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    #define skyHorRedMult 1.00    //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define skyHorGreenMult 1.00  //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define skyHorBlueMult 1.00   //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    /* --- clouds --- */
    #define cloudVolumeEnabled
    //#define cloudDynamicLight
    //#define cloudVolumeStoryMode
    #define cloudVolumeFastMultiscatter
    #define cloudVolumeRounding 4   //[1 2 3 4 5 6 8 10 12 16 20 24 28 32]
    //#define cloudShadowsEnabled
    //#define cloudLayerShadowing

    #define cloudVolume0Samples 8  //[6 8 10 12 14 16 18 20 22 24 26 28 30]
    #define cloudVolume0Alt 160     //[100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]
    #define cloudVolume0Depth 14    //[2 4 6 8 10 12 14 16 18 20 22 24 26 28 30]
    #define cloudVolume0Clip 1200   //[800 1000 1200 1400 1600 1800 2000 2200 2400 2600 2800 3000]

    //#define cloudVolume1Enabled
    #define cloudVolume1Samples 6  //[6 8 10 12 14 16 18 20 22 24 26 28 30]
    #define cloudVolume1Alt 300     //[240 260 280 300 320 340 360 380 400]
    #define cloudVolume1Depth 12    //[2 4 6 8 10 12 14 16 18 20 22 24 26 28 30]
    #define cloudVolume1Clip 1600   //[800 1000 1200 1400 1600 1800 2000 2200 2400 2600 2800 3000]

    //#define RSKY_CloudReflections
    
    /* --- FOG --- */
    #define fogVolumeEnabled
    //#define fogSmoothingEnabled
    //#define fogMistAdvanced
    #define fogDensityMult 1.0      //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    #define mistMieAnisotropy 0.8   //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]
    #define fogMinSteps 4          //[4 6 8]
    #define fogAdaptiveSteps 4     //[4 6 8 10 12 14 16 18]
    #define fogClipDist 384.0       //[256.0 384.0 448.0 512.0 768.0 1024.0]
    #define fogDensityMult 1.0      //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    
    #define fogEnabled
    #define fogStart 0.3    //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]
    #define fogFalloff 2.0  //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0]

    /* --- PHASE 1: OVERWORLD GOD RAYS --- */
    #define aboveWaterGodRaysEnabled
    #define aboveWaterGodRayStrength 1.25 //[0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
    #define aboveWaterGodRayFocus 0.78     //[0.50 0.60 0.68 0.72 0.75 0.78 0.82 0.86 0.90 0.94]
    #define aboveWaterGodRayFoliageDetail 0.85 //[0.0 0.25 0.5 0.65 0.75 0.85 0.9 1.0]

    /* --- WATER --- */
    #define waterFogEnabled
    #define underwaterLightShaftsEnabled
    #define underwaterShaftSamples 10      //[4 6 8 10 12 16]
    #define underwaterShaftStrength 3.0    //[0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0]
    #define underwaterShaftDistance 96.0   //[24.0 32.0 48.0 64.0 80.0 96.0 112.0 128.0]
    #define underwaterShaftFocus 0.80      //[0.60 0.65 0.70 0.75 0.80 0.84 0.86 0.88 0.90 0.92]
    #define underwaterShaftDefinition 0.85 //[0.0 0.25 0.5 0.65 0.75 0.85 0.9 1.0]
    #define underwaterBlueFilter 1.0       //[0.0 0.25 0.5 0.65 0.75 0.85 0.9 1.0]
    #define underwaterFogDensityMult 0.65  //[0.35 0.45 0.55 0.65 0.75 0.85 1.0]
    #define waterRefractionXrayGuardEnabled
    #define waterDistantTerrainGuardEnabled

    /* --- PHASE 1: WATER POLISH --- */
    #define enhancedWaterCausticsEnabled
    #define waterCausticStrength 1.60     //[1.0 1.15 1.3 1.45 1.6 1.8 2.0 2.25 2.5]
    #define waterSunGlitterEnabled
    #define waterSunGlitterStrength 1.35  //[0.0 0.25 0.5 0.75 1.0 1.15 1.35 1.5 1.75 2.0 2.5]
    #define waterSunGlitterSharpness 96.0 //[32.0 48.0 64.0 80.0 96.0 128.0 160.0 192.0 256.0]
    #define waterDepthColorEnabled
    #define waterDepthColorStrength 0.75  //[0.0 0.25 0.5 0.65 0.75 0.85 1.0]
    #define waterDepthColorDistance 18.0  //[6.0 8.0 12.0 16.0 18.0 24.0 32.0 48.0]

    #define customWaterNormals
    #define customWaterColor
    //#define waterParallaxEnabled
    #define waterRed 0.02           //[0.0 0.01 0.02 0.04 0.06 0.08 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
    #define waterGreen 0.15          //[0.0 0.01 0.02 0.04 0.06 0.08 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
    #define waterBlue 0.3           //[0.0 0.01 0.02 0.04 0.06 0.08 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
    #define waterAlpha 0.15         //[0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
    #define waterTextureBlend 0.3   //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8]
    #define waterDensity 1.0        //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

/* --- LIGHTING --- */

    /* --- COLORS --- */
    #define sunlightIllum 1.0       //[0.1 0.2 0.3 0.4 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0]
    #define sunlightRedMult 1.00    //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define sunlightGreenMult 1.00  //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define sunlightBlueMult 1.00   //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    #define moonlightIllum 1.0      //[0.1 0.2 0.3 0.4 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0]
    #define moonlightRedMult 1.00   //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define moonlightGreenMult 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define moonlightBlueMult 1.00  //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    #define skylightIllum 1.0       //[0.1 0.2 0.3 0.4 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0]
    #define skylightRedMult 1.00    //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define skylightGreenMult 1.00  //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]
    #define skylightBlueMult 1.00   //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00]

    #define blocklightIllum 1.0     //[0.1 0.2 0.3 0.4 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0]
    #define blocklightBaseTemp 2600 //[1000 1200 1400 1600 1800 2000 2200 2400 2600 2800 3000 3200 3400 3600 3800 4000 4200 4400 4600 4800 5000]
    #define minimumAmbientIllum 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 3.5 4.0]
    
    /* --- DIRECT LIGHT --- */
    #define shadowVPSEnabled
    #define shadowPenumbraScale 1.0         //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.2 2.4 2.6 2.8 3.0]
    //#define contactShadowsEnabled
    #define shadowFilterIterations 6    //[6 9 12 15 18 21 24 27 30]
    //#define subsurfaceScatteringEnabled
    #define subsurfaceScatterMode 2     //[0 1 2 3]
    //#define UseLightleakPrevention

    /* --- INDIRECT LIGHT --- */
    #define indirectResReduction 4  //[4 3 2 1]
    #define PT_SPP 1               //[1 2 3 4 5 6]
    //#define PT_GUIDING

    // All-of-Create v12: adaptive temporal GI. Stable pixels reuse validated
    // reprojected history and only a rotating subset casts a fresh PT ray.
    // Invalid/disoccluded/high-variance pixels always trace immediately.
    #define adaptiveGI
    #define adaptiveGIDynamic      // Phase 2.1: half-rate while settling, quarter-rate once history is stable
    #define adaptiveGIRate 2       //[1 2 4]

    #define SSPT_Enabled
    #define labEmissionMode 0      //[0 1 2] 0-hardcoded only, 1-hardcoded+lab, 2-lab only
    #define labEmissionCurve 1.0    //[1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0]
    //#define ConretePowderEmission
    //#define textureAoEnabled

    #define maxFrames 256.0     //[16.0 32.0 64.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0]
    #define minAccumMult 1.0    //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0] Accumulation Weight Mult
    #define ADAPT_STRENGTH 1.0  //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5] Adaptive Strength

    #define SVGF_PREACCUM
    #define SVGF_FILTER
    #define SVGF_RAD 1              //[1 2 3] Filter Radius
    #define SVGF_STRICTNESS 1.0     //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0] Luminance Strictness
    #define SVGF_NORMALEXP 1.0      //[0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0]

    #define VOXEL_COLOR_SAMPLES 2   //[2 3 4 6 8 10 12 14 16]
    //#define LPV_MULTIPASS_PROPAGATION
    //#define USE_FOG_LPV
    #define FOG_LPV_CONTRIBUTION 1.0    //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    #define VOXEL_MULTIBOUNCE

    #define SSAO_Intensity 1.0      //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

    /* --- MODDED LIGHTING COMPATIBILITY --- */
    // Uses the vanilla lightmap only as a minimum floor. This preserves VX lighting
    // while preventing unmapped modded emitters/custom-rendered blocks from becoming
    // unnaturally dark inside the voxel volume.
    #define modCompatLighting
    #define modCompatBlocklightFloor 0.35 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.5 0.6 0.75 1.0]
    #define modCompatSkylightFloor 0.10   //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.4 0.5]

    // Re-enable LabPBR normal/specular decoding specifically for Colorwheel/Flywheel
    // geometry when Create-LabPBR is installed. POM remains disabled on Flywheel geometry.
    #define createLabPBRColorwheel

    // Treat Iris' hardcoded minecraft:name_tag render as UI-like fullbright geometry.
    // This keeps nametag text readable when the entity stands in a dark VX/PT region.
    #define nameTagFullbright

/* ------ TERRAIN ------ */
    #define normalmapEnabled
    #define normalmapFormat 0       //[0 1]
    //#define vertexAttributeFix
    #define wetnessMode 0           //[0 1 2]
    #define puddleRippleSpeed 1.0   //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    #define windEffectsEnabled
    #define windIntensity 1.0  //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

    /* ------ PARALLAX ------ */
    #define pomEnabled
    #define pomSamples 8   //[8 16 32 64 128 256 512]
    //#define ParallaxSelfShadowEnabled
    #define pomShadowSamples 16     //[4 8 16 32 64]
    #define pomDepth 0.25   //[0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

    //#define slopeNormalCalculation
    //#define pomDepthEnabled
    #define slopeNormalStrength 0.024f
    
    /* ------ REFLECTIONS ------ */
    #define reflectionsEnabled
    //#define resourcepackReflectionsEnabled
    #define specularHighlightsEnabled
    #define roughReflectionsEnabled
    #define roughReflectionSamples 1    //[1 2 3 4 5 6 7 8]
    #define SPECULAR_BOUNCES 1          //[1 2 3 4 5 6 7 8]

    #define screenspaceReflectionsEnabled
    //#define voxelPT_ReflectionsEnabled

    #define roughnessThreshold 0.7      //[0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
    #define skyOcclusionThreshold 0.9   //[0.5 0.6 0.7 0.8 0.9 1.0]

    #define reflectionResReduction 3  //[4 3 2 1]

        /* Filter */
        #define SPF_USE_ACCUMULATION
        #define SPF_TEMPORAL_BLUENOISE
        #define SPF_ACCUM_FRAMES 256.0  //[16.0 32.0 64.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0]


        #define reflectionsAtrousEnabled
        #define SPF_LOBE 1.5        //[0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
        #define SPF_SHARPEN 0.4     //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
        #define SPF_KERNEL_MINW 0.1 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
        #define SPF_KERNEL_MAXW 0.5 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]


/* ------ CAMERA ------ */
#define anamorphStretch 1.00    //[0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50]

    /* --- BLOOM --- */
    #define bloomEnabled
    #define bloomIntensity 1.0      //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    #define bloomyFog

    /* --- EXPOSURE --- */
    #define LOCAL_EXPOSURE
    //#define LOCAL_EXPOSURE_DEMO
    #define exposureDecay 1.0           //[0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0]
    #define autoExposureBias 0.0
    #define exposureBias 1.0            //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
    #define exposureDarkClamp 1.0       //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0 3.5 4.0 5.0 6.0 8.0 10.0 15.0 20.0]
    #define exposureBrightClamp 1.0     //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0 3.5 4.0 5.0 6.0]
    
    #define exposureComplexEnabled
    #define exposureBrightPercentage 0.6    //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]
    #define exposureDarkPercentage 0.5      //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]
    #define exposureBrightWeight 0.4        //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]
    #define exposureDarkWeight 0.6          //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9]

    //#define manualExposureEnabled
    #define manualExposureValue 14.0     //[0.1 0.3 0.5 1.0 1.5 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 12.0 14.0 16.0 18.0 20.0 25.0 30.0 40.0 50.0]

    /* --- MOTIONBLUR --- */
    //#define motionblurToggle
    #define motionblurSamples 8     //[4 6 8 10 12 14 16 18 20]
    #define motionblurScale 1.0     //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

    /* --- DOF --- */
    //#define DoFToggle
    #define DoFQuality 2    //[0 1 2]
    #define DoFChromaDispersion

    #define camFocus 0 // [0 1 2 3]
    #define camManFocDis 5 // [0.1 0.2 0.3 0.4 0.5 0.7 0.9 1 1.1 1.2 1.3 1.4 1.5 1.6 1.8 1.9 2 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3 4 5 6 7 8 9 10 12 14 16 24 32 40 48 56 64 72 80 88 96 104 112 120 128 136 144 152 160 168 176 184 192 200 208 216 224 232 240 248 256]
    //#define showFocusPlane

    /* --- LENS FLARE --- */
    //#define lensFlareToggle
    #define lensFlareBokehLod 2
    #define lensFlareThreshold 6   //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1 2 3 4 5 6 8 10 12 14 16 18 20 25 30 35 40 45 50 60 70 80 90]

    //#define legacyFlareToggle
    #define legacyFlareIntensity 1.0     //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

#define taaEnabled
#define imageSharpenEnabled
#define TAAU_FXAA_PostPass