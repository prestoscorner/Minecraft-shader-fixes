#version 430

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

layout(local_size_x = 4, local_size_y = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);

#define RSSBO_ENABLE_COLOR
#include "/lib/head.glsl"
#include "/lib/util/colorspace.glsl"

#define NETHER_UseBiomeColors
#define NETHER_AmbientSaturation 1.00   //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define NETHER_AmbientRed 1.00          //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define NETHER_AmbientGreen 1.00        //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define NETHER_AmbientBlue 1.00         //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

uniform vec3 fogColor;

vec3 blackbody(float temperature){
    vec4 vx = vec4(-0.2661239e9, -0.2343580e6, 0.8776956e3, 0.179910);
    vec4 vy = vec4(-1.1063814, -1.34811020, 2.18555832, -0.20219683);
    float it = rcp(temperature);
    float it2= sqr(it);
    float x = dot(vx, vec4(it * it2, it2, it, 1.0));
    float x2 = sqr(x);
    float y = dot(vy,vec4(x * x2, x2, x, 1.0));
    float z = 1.0 - x - y;
    
    vec3 AP1 = vec3(x * rcp(y), 1.0, z * rcp(y)) * CT_XYZ_AP1;
    return max(AP1, 0.0);
}

void main() {
    uint Index = uint(gl_GlobalInvocationID.x);

    switch (Index) {
        case 0:
            #ifdef NETHER_UseBiomeColors
            vec3 linearFog  = linearToAP1(toLinear(fogColor));
            #else
            vec3 linearFog  = vec3(1.0);
            #endif
                
                linearFog   = colorSaturation(linearFog, NETHER_AmbientSaturation);
                linearFog  *= vec3(NETHER_AmbientRed, NETHER_AmbientGreen, NETHER_AmbientBlue);
                linearFog  *= sqrt3;

            RColorTable.Skylight = linearFog * sqrt3;

        case 1:
            RColorTable.Blocklight = blackbody(float(blocklightBaseTemp)) * blocklightIllum * blocklightBaseMult;
    }

}