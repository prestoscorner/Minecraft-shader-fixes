#version 430 compatibility

/*
 * All of Create / Colorwheel compatibility program for NostalgiaVX 11.15.
 * Flywheel/Create geometry is rendered here without POM. Normal terrain keeps
 * using gbuffers_terrain and therefore retains full AVPBR POM.
 */

#define gTEXTURED
#define gTERRAIN
#define gBLOCK
#define gCOLORWHEEL
#define HAS_COLORWHEEL
#include "/program/gbuffer/colorwheel.fsh"
