#version 430 compatibility

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

/* RENDERTARGETS: 0,5 */
layout(location = 0) out vec3 sceneColor;
layout(location = 1) out vec4 bloomTiles;
//layout(location = 2) out vec4 clear7;

#define DIM -1

#define RSSBO_ENABLE_COLOR
#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"

const bool shadowHardwareFiltering = true;

in vec2 uv;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex7;
uniform sampler2D colortex8;
uniform sampler2D colortex9;
uniform sampler2D colortex10, colortex12;
uniform sampler2D colortex11;

uniform sampler2D depthtex0;
uniform sampler2D depthtex1;

uniform sampler2D noisetex, RSkybox;
uniform sampler3D depthtex2;

uniform sampler2DShadow shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;

uniform int frameCounter;
uniform int isEyeInWater;
uniform int worldTime;

uniform float eyeAltitude;
uniform float far, near;
uniform float frameTimeCounter;
uniform float cloudLightFlip;
uniform float sunAngle;
uniform float lightFlip;
uniform float worldAnimTime;

uniform ivec2 eyeBrightnessSmooth;

uniform vec2 taaOffset;
uniform vec2 viewSize, pixelSize;

uniform vec3 cameraPosition;

uniform vec4 daytime;

uniform mat4 gbufferProjectionInverse, gbufferModelViewInverse;
uniform mat4 gbufferProjection, gbufferModelView;
uniform mat4 shadowModelView, shadowModelViewInverse;
uniform mat4 shadowProjection, shadowProjectionInverse;

#define FUTIL_LINDEPTH
#include "/lib/fUtil.glsl"

#include "/lib/frag/bluenoise.glsl"
#include "/lib/frag/gradnoise.glsl"

#include "/lib/util/bicubic.glsl"
#include "/lib/util/transforms.glsl"
#include "/lib/atmos/project.glsl"
#include "/lib/atmos/phase.glsl"
#include "/lib/atmos/waterConst.glsl"

#ifdef DISTANT_HORIZONS
uniform mat4 dhProjectionInverse, dhProjection;
uniform sampler2D dhDepthTex0, dhDepthTex1;
uniform int dhRenderDistance;
#endif

vec3 getFog(vec3 color, float dist, vec3 skyColor, vec3 sceneDir) {
    #ifdef DISTANT_HORIZONS
        dist = dist / dhRenderDistance;
        dist *= pi;
        dist 	= max((dist - sqr(fogStart)), 0.0);
        dist   /= 1.0 - sqr(fogStart);
    #else
	    dist 	= dist / far;
        dist 	= max((dist - fogStart), 0.0);
        dist   /= 1.0 - fogStart;
    #endif
        
	float alpha = 1.0-exp(-dist * fogFalloff);
        alpha *= alpha;
        alpha  *= cube(1.0 - max0(sceneDir.y));

	color 	= mix(color, skyColor, saturate(alpha));

	return color;
}

vec3 getWaterFog(vec3 SceneColor, float dist, vec3 ScatterColor){
    float density   = max0(dist) * waterDensity;

    vec3 transmittance = expf(-waterAttenCoeff * density);

    const vec3 scatterCoeff = vec3(waterRed, waterGreen, waterBlue);

    vec3 scatter    = 1.0-exp(-density * scatterCoeff);
        scatter    *= max(expf(-waterAttenCoeff * density), expf(-waterAttenCoeff * tau));

    return SceneColor * transmittance + scatter * ScatterColor * rpi;
}

/* ------ FOG ------ */
#include "/lib/offset/gauss.glsl"

ivec2 clampTexelPos_FOG(ivec2 pos) {
    return clamp(pos, ivec2(0.0), ivec2(viewSize));
}

mat2x3 sampleFogSpatial(vec2 coord, const float LOD) {
    ivec2 pixelCoordUnscaled = ivec2(coord * viewSize);

    vec2 newCoord       = coord / LOD;
    ivec2 pixelCoord    = ivec2(newCoord * viewSize);

    ivec2 pos           = ivec2(coord * viewSize);

    vec3 centerScatter  = texelFetch(colortex5, pixelCoord, 0).rgb;
    vec3 centerTransmittance = texelFetch(colortex7, pixelCoord, 0).rgb;

    float centerDepth   = depthLinear(texelFetch(depthtex0, pixelCoordUnscaled, 0).x) * far;

    float totalWeight   = 1.0;
    vec3 totalScatter   = centerScatter * totalWeight;
    vec3 totalTrans     = centerTransmittance * totalWeight;

    for (int i = 0; i<9; i++) {
        ivec2 deltaPos      = kernelO_3x3[i] * 2;
        if (i == 4) continue;

        ivec2 samplePos     = pixelCoordUnscaled + deltaPos;
        ivec2 samplePosScaled = ivec2(vec2(samplePos) / LOD);

        bool valid          = all(greaterThanEqual(samplePos, ivec2(0))) && all(lessThan(samplePos, ivec2(viewSize)));

        if (!valid) continue;

        vec3 currentScatter = texelFetch(colortex5, clampTexelPos_FOG(samplePosScaled), 0).rgb;
        vec3 currentTrans   = texelFetch(colortex7, clampTexelPos_FOG(samplePosScaled), 0).rgb;
        float currentDepth  = depthLinear(texelFetch(depthtex0, samplePos, 0).x) * far;

        float depthDelta    = abs(currentDepth - centerDepth) * 48.0;

        float weight        = exp(-depthDelta);

        //accumulate stuff
        totalScatter   += currentScatter * weight;
        totalTrans     += currentTrans * weight;

        totalWeight    += weight;
    }

    totalScatter   /= max(totalWeight, 1e-16);
    totalTrans     /= max(totalWeight, 1e-16);

    return mat2x3(totalScatter, totalTrans);
}

void applyFogData(inout vec3 color, in mat2x3 data) {
    color = color * data[1] + data[0];
}


/* ------ Reflections ------ */
#include "/lib/frag/reflection.glsl"

vec4 FetchGbuffer(ivec2 UV) {
        UV          = ivec2(vec2(UV) / reflectionResScale);
    vec3 normals    = decodeNormal(texelFetch(colortex1, UV, 0).xy);
    float depth     = depthLinear(texelFetch(depthtex0, UV, 0).x) * far;
    return vec4(normals, depth);
}

float sphericalGaussian(vec3 dir1, vec3 dir2, float lambda) {
    float w = exp(lambda * (saturate(dot(dir1, dir2)) - 1.0));
    return w > 1e-8 ? w : exp(-saturate(1-dot(dir1, dir2)) * 16.0);
}

float lobeSharpness(float roughness) {
    return 2.0 / sqr(max(roughness, 1e-5));
}

float specularLobeWeight(vec3 centerNorm, vec3 norm, float centerRoughness, float roughness, float beta) {
    //if (maxOf(vec2(centerRoughness, roughness)) < 1e-2) return pow8(saturate(dot(centerNorm, norm) * 1.05));

    float lambaCenter = lobeSharpness(centerRoughness);
    float lambaSample = lobeSharpness(roughness);
    return pow(2.0 * sqrt(lambaCenter*lambaSample) / max(lambaCenter + lambaSample, 1e-5), beta) 
        * sphericalGaussian(centerNorm, norm, beta * lambaCenter * lambaSample / max(lambaCenter + lambaSample, 1e-5));
}

const float lobeFactor = 1.0;
const float sharpenWeight = 0.4;

vec4 modifySpecularColor(vec4 color) {
    return vec4(pow(length(color.rgb), sharpenWeight) * normalizeSafe(color.rgb), color.a);
}
vec4 inverseModifySpecularColor(vec4 color) {
    return vec4(pow(length(color.rgb), 1.0 / sharpenWeight) * normalizeSafe(color.rgb), saturate(color.a));
}

uniform sampler3D RBluenoise3D;
vec3 ditherBluenoiseF3() {
    ivec2 coord = ivec2(gl_FragCoord.xy);

    vec3 noise  = texelFetch(RBluenoise3D, ivec3(coord & 255, 0), 0).xyz;
        noise   = fract(noise + torroidalShift.xyz * frameCounter);

    return noise;
}

mat2x4 ReadReflectionResult(vec2 ViewUV) {
    ivec2 PixelIndex = ivec2((ViewUV / REF_VIEWPORT) * viewSize);

    return mat2x4(
        texelFetch(colortex12, PixelIndex, 0),
        texelFetch(colortex12, PixelIndex + ivec2(viewSize.x * 0.5, 0.0), 0)
    );
}

mat2x4 ReadReflectionData(ivec2 PixelIndex) {
    return mat2x4(
        texelFetch(colortex12, PixelIndex, 0),
        texelFetch(colortex12, PixelIndex + ivec2(viewSize.x * 0.5, 0.0), 0)
    );
}

ivec2 clampTexelPos(ivec2 pos) {
    return clamp(pos, ivec2(0), ivec2(viewSize / REF_VIEWPORT) - ivec2(1));
}

vec4 FetchReflectionGbuffer(ivec2 UV) {
    vec4 Val  = texelFetch(colortex10, clampTexelPos(UV), 0);
    return vec4(Val.rgb * 2.0 - 1.0, sqr(Val.w) * far);
}
float ReadCurrentRoughness(ivec2 Position) {
    return texelFetch(colortex12, Position + ivec2(viewSize.x * 0.5, 0.0), 0).a;
}


mat2x4 ReadReflectionUpscaled(vec2 uv, vec4 centerData, float centerRoughness) {
    ivec2 UV    = ivec2((uv * viewSize / ResolutionScale)/ REF_VIEWPORT);

    //return ReadReflectionData(UV);

    mat2x4 totalColor = mat2x4(0);
    float totalWeight = 0.0;

    const float normalExp = 256.0;

    ivec2 jitter        = ivec2((ditherBluenoiseF3().xy - 0.5));

    float specularWaveletWeight = mix(0.3, 1.0, sqrt(centerRoughness));
    float specularKernel[3][3] = {
		{ 1.0,                        specularWaveletWeight,       sqr(specularWaveletWeight) },
		{ specularWaveletWeight,      sqr(specularWaveletWeight),  pow4(specularWaveletWeight) },
        { sqr(specularWaveletWeight), pow4(specularWaveletWeight), pow8(specularWaveletWeight) }
        };

    const int r = 2;
	for(int y = -r; y <= r; ++y) {
		for(int x = -r; x <= r; ++x) {
			ivec2 TapUV = UV + ivec2(x, y) + jitter;

            bool valid          = all(greaterThanEqual(TapUV, ivec2(0))) && all(lessThan(TapUV, ivec2(viewSize / REF_VIEWPORT)));

            if (!valid) continue;

            vec4 currentData    = FetchReflectionGbuffer(TapUV);

            mat2x4 CurrentColor = ReadReflectionData(TapUV);

            float weight         = specularKernel[abs(x)][abs(y)];

            float distDepth = abs(centerData.a - currentData.a) * 4.0;

                weight *= exp(-distDepth);
                weight *= max0(specularLobeWeight(centerData.xyz, currentData.xyz, centerRoughness, CurrentColor[1].a, lobeFactor));
                //weight = max(weight, 1e-16);
            

            totalColor[0] += modifySpecularColor(CurrentColor[0]) * weight;
            totalColor[1] += CurrentColor[1] * weight;
            totalWeight   += weight;
        }
    }
    totalWeight     = max(totalWeight, 1e-16);

    totalColor[0] /= totalWeight;
    totalColor[1] /= totalWeight;
    totalColor[0] = inverseModifySpecularColor(totalColor[0]);

    return totalColor;
}

vec3 lavaFog(vec3 scene, float d) {
    float density   = max(0.0, d);

    float transmittance = expf(-1.0 * density);

    return mix(vec3(1.0, 0.2, 0.02), scene, transmittance);
}

uniform float blindness;
uniform float darknessFactor;

vec3 blindnessFog(vec3 SceneColor, float SceneDistance) {
    if (blindness < 1e-2) return SceneColor;
    float maxDistance = mix(16.0 / saturate(1.0 - darknessFactor * 0.9), tau, saturate(blindness));

    return mix(SceneColor, minimumAmbientColor * minimumAmbientMult * rpi, saturate(sqrt(sstep(SceneDistance, 0.0, maxDistance)) * max(darknessFactor * rpi, blindness)));
}

void main() {
    sceneColor  = texture(colortex0, uv).rgb;

    vec4 GBuffer0       = texture(colortex1, uv);

    vec4 GBuffer1       = texture(colortex2, uv);
    int matID           = int(unpack2x8(GBuffer1.y).x * 255.0);

#ifdef DISTANT_HORIZONS
    vec2 dhDepth = vec2(stex(dhDepthTex0).x, stex(dhDepthTex1).x);
    bvec2 isDH = bvec2(landMask(dhDepth.x), landMask(dhDepth.y));
#else
    const bvec2 isDH = bvec2(false, false);
#endif

    vec2 sceneDepth     = vec2(texture(depthtex0, uv).x, texture(depthtex1, uv).x);
    bvec2 isTerrain = bvec2(landMask(sceneDepth.x), landMask(sceneDepth.y));
    bool translucent    = sceneDepth.x < sceneDepth.y;
#ifdef DISTANT_HORIZONS
        if (!isTerrain.x) translucent = translucent || (dhDepth.x < dhDepth.y);
#endif

    vec3 position0      = vec3(uv / ResolutionScale, sceneDepth.x);
        position0       = screenToViewSpace(position0);
#ifdef DISTANT_HORIZONS
        if (!isTerrain.x) position0 = screenToViewSpace(vec3(uv / ResolutionScale, dhDepth.x), dhProjectionInverse);
#endif

    vec3 position1      = vec3(uv / ResolutionScale, sceneDepth.y);
        position1       = screenToViewSpace(position1);
#ifdef DISTANT_HORIZONS
        if (!isTerrain.y) position1 = screenToViewSpace(vec3(uv / ResolutionScale, dhDepth.y), dhProjectionInverse);
#endif

    mat2x3 scenePos     = mat2x3(viewToSceneSpace(position0), viewToSceneSpace(position1));

    vec3 worldDir       = mat3(gbufferModelViewInverse) * normalize(position0);

    vec3 skyColor       = RColorTable.Skylight / sqrt3 / tau;

    mat2x3 reflectionAux = unpackReflectionAux(texture(colortex3, uv));
        reflectionAux[1] = saturate(reflectionAux[1]);
    
    #ifdef reflectionsEnabled
    if ((isTerrain.x || isDH.x) && matID != 201) {
        vec3 sceneNormal = decodeNormal(GBuffer0.xy);
        vec3 viewNormal = mat3(gbufferModelView) * sceneNormal;

        vec3 viewDir    = normalize(position0);

        bool water      = matID == 102;

        materialProperties material = materialProperties(1.0, 0.02, false, false, mat2x3(0.0));
        if (water) material = materialProperties(0.01, 0.02, false, false, mat2x3(0.0));
        else material   = decodeLabBasic(unpack2x8(GBuffer1.x));
        float groundWetness = unpack2x8(GBuffer1.z).y;

        mat2x4 ReflectionData = ReadReflectionUpscaled(uv, vec4(sceneNormal, depthLinear(sceneDepth.x) * far), material.roughness);
        
        vec4 reflection = ReflectionData[0];
        vec3 fresnel    = ReflectionData[1].xyz;

        if (material.conductorComplex && material.conductor) fresnel *= sqrt(reflectionAux[1]) * pi;

        #ifdef resourcepackReflectionsEnabled
            if (material.conductor) sceneColor.rgb = mix(sceneColor.rgb, reflection.rgb * fresnel, reflection.a);
            else sceneColor.rgb = mix(sceneColor.rgb, reflection.rgb, fresnel * reflection.a);            
        #else
            // --- WATER REFLECTIONS --- //
            if (water || groundWetness > 1e-2) {
                sceneColor.rgb = mix(sceneColor.rgb, reflection.rgb, fresnel * reflection.a);
            }
        #endif

    }
    #endif
    

    #ifdef fogEnabled
        if (isEyeInWater == 0 && (isTerrain.x || isDH.x)) sceneColor  = getFog(sceneColor, length(position0), skyColor, worldDir);
    #endif

    #ifdef waterFogEnabled
    if (isEyeInWater == 1) {
        vec3 fogScatterColor = skyColor;

        sceneColor = getWaterFog(sceneColor, length(position0), fogScatterColor);
    }
    #endif

    #ifdef fogVolumeEnabled
        #ifdef fogSmoothingEnabled
            mat2x3 fogData      = sampleFogSpatial(uv, 1.0);
        #else
            mat2x3 fogData      = mat2x3(texture(colortex5, uv).rgb, texture(colortex7, uv).rgb);
        #endif

        applyFogData(sceneColor, fogData);
    #endif

    if (isEyeInWater == 2) sceneColor.rgb = lavaFog(sceneColor.rgb, length(position0));
    sceneColor.rgb = blindnessFog(sceneColor.rgb, length(position0));

    bloomTiles = vec4(0, 0, 0, 1);
    //clear7  = vec4(0);
}