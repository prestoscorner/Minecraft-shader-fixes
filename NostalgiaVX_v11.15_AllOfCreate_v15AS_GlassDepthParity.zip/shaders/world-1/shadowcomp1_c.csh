#version 430

#include "/program/lpv/propagate.comp"