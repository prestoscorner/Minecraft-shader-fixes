#version 430 compatibility

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/

#define RSSBO_ENABLE_COLOR
#include "/lib/head.glsl"

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 sceneColor;

void main() {
    sceneColor  = clamp16F(vec4(RColorTable.Skylight / sqrt3 / tau, 1.0));
}