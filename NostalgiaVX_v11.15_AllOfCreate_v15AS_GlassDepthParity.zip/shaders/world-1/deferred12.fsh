#version 430 compatibility

/*
====================================================================================================

    Copyright (C) 2023 RRe36

    All Rights Reserved unless otherwise explicitly stated.


    By downloading this you have agreed to the license and terms of use.
    These can be found inside the included license-file
    or here: https://rre36.com/copyright-license

    Violating these terms may be penalized with actions according to the Digital Millennium
    Copyright Act (DMCA), the Information Society Directive and/or similar laws
    depending on your country.

====================================================================================================
*/


/* RENDERTARGETS: 0,3,5 */
layout(location = 0) out vec4 sceneColor;
layout(location = 1) out vec4 lightingData;
layout(location = 2) out vec4 translucentColor;

#define RSSBO_ENABLE_COLOR
#include "/lib/head.glsl"
#include "/lib/util/encoders.glsl"

in vec2 uv;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex7;

uniform sampler2D depthtex0;
uniform sampler2D depthtex2;

uniform float lightFlip;
uniform float sunAngle;
uniform float near, far;

uniform vec2 pixelSize, viewSize;

#define FUTIL_LINDEPTH
#include "/lib/fUtil.glsl"

#include "/lib/light/SVGF_Upscaler.glsl"

vec4 packReflectionAux(vec3 directLight, vec3 albedo) {
    vec4 lightRGBE  = encodeRGBE8(directLight);
    vec4 albedoRGBE = encodeRGBE8(albedo);

    return vec4(pack2x8(lightRGBE.xy),
                pack2x8(lightRGBE.zw),
                pack2x8(albedoRGBE.xy),
                pack2x8(albedoRGBE.zw));
}

uniform int heldItemId, heldItemId2;
uniform int heldBlockLightValue, heldBlockLightValue2;

#include "/lib/light/emission.glsl"

void main() {
    sceneColor          = stex(colortex0);
    float sceneDepth    = stex(depthtex0).x;
    vec3 albedo         = vec3(1.0);
    vec3 directLight    = vec3(1.0);
    //indirectLuma        = 0.0;

    if (landMask(sceneDepth)) {
        vec4 tex1       = stex(colortex1);
        vec3 sceneNormal = decodeNormal(tex1.xy);

        bool hand   = sceneDepth < stex(depthtex2).x;

            albedo          = sceneColor.rgb;

        float SSAO = ReadLightAux(colortex5, ivec2(gl_FragCoord.xy)).y;

        //SphericalHarmonics indirectLightSH = ResolutionScale != 0.5 ? atrousSVGF(colortex5, colortex3, uv, sceneNormal, sceneDepth, SSAO) : ReadLightSH(colortex5, ivec2(gl_FragCoord.xy));
        vec3 indirectLight = atrousSVGF(colortex5, colortex3, uv, sceneNormal, sceneDepth, SSAO);

        vec4 tex2       = stex(colortex2);
        ivec2 matID     = unpack2x8I(tex2.y);
        bool stableHandMaterial = matID.x == 201;
        bool isSSS          = matID.x == 2 || matID.x == 4;
        
        //vec3 indirectLight = ProjectIrradiance(indirectLightSH, matID.x == 2 ? normalize(mix(sceneNormal, vec3(0,1,0), 0.5)) : sceneNormal) * SSAO;
        indirectLight *= SSAO;

        if (stableHandMaterial) {
            // The world GI buffer is Monte-Carlo/SVGF data and is intentionally unsuitable
            // for a camera-relative held object. Use deterministic lightmap ambient instead.
            vec2 handLightmap = saturate(unpack2x8(tex1.z));
            vec3 handBlockAmbient = pow5(handLightmap.x) * RColorTable.Blocklight;
            vec3 handSkyAmbient = cube(handLightmap.y) * RColorTable.Skylight * rpi;
            indirectLight = max(handBlockAmbient, handSkyAmbient);
            indirectLight = max(indirectLight, minimumAmbientColor * minimumAmbientMult * minimumAmbientIllum);
            SSAO = 1.0;
        }

        #ifdef textureAoEnabled
            indirectLight  *= saturate(stex(colortex2).w);
        #endif
        

        #ifdef textureAoEnabled
            indirectLight  *= saturate(stex(colortex2).w);
        #endif


        vec3 emission       = (normalizeSafe(albedo)) * sceneColor.a * rpi;
        if (stableHandMaterial || hand) {
            // Never infer emission from the rendered hand surface itself. Only explicitly
            // mapped held lights (item.properties) or a non-zero vanilla held-light value
            // are allowed to contribute. This makes ordinary blocks deterministic.
            bool primaryHandSide = uv.x > (0.5 * ResolutionScale);
            int selectedHeldID = primaryHandSide ? heldItemId : heldItemId2;
            int selectedHeldLight = primaryHandSide ? heldBlockLightValue : heldBlockLightValue2;
            emission = vec3(0.0);
            if (selectedHeldID > 0 || selectedHeldLight > 0) {
                bool AnyEmitterMain = false;
                vec3 EmissionColorMain = GetEmission_Handheld(selectedHeldID, float(selectedHeldLight) / 15.0, AnyEmitterMain);
                emission = EmissionColorMain * rpi / euler;
            }
        }

        // Entity name tags are screen-facing UI-like text. Keep their albedo intact and
        // bypass scene irradiance so VX/PBR lighting cannot randomly black them out.
        #ifdef nameTagFullbright
            if (matID.x == 200) {
                indirectLight = vec3(1.0);
                emission = vec3(0.0);
            }
        #endif

        sceneColor.rgb     *= indirectLight.rgb + emission;
        //sceneColor.rgb      = directLight + indirectLight;

        #if DEBUG_VIEW == 2
            sceneColor.rgb      = indirectLight.rgb;
        #endif
        //indirectLuma        = avgOf(indirectLight);
    }

    sceneColor          = drawbufferClamp(sceneColor);
    translucentColor    = vec4(0.0);
    lightingData        = packReflectionAux(directLight, albedo);
}